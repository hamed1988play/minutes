/*
# Meeting Minutes & Resolutions Management System

## Overview
Complete system for managing meeting minutes (صورتجلسات) and resolutions (مصوبات)
with approval workflows, follow-up tracking, and obstacle management.

## New Tables (12 tables)

### Supporting tables
- `org_units` — organizational units
- `profiles` — application users (secretaries, managers, participants, executors)
- `meetings` — meetings (referenced by minutes)
- `meeting_agenda_items` — agenda items for meetings

### Core tables (8 from spec)
- `minutes` — meeting minutes with snapshot info, versioning, approval workflow
- `minutes_participants` — participants with invite/attendance/approval status
- `decisions` — resolutions with progress tracking, priority, deadlines
- `decision_assignees` — executors with primary/collaborator/external roles
- `decision_followups` — progress follow-up entries
- `decision_obstacles` — obstacles with types and resolution tracking
- `decision_attachments` — file attachments for decisions
- `agenda_results` — discussion results per agenda item

## Security
- RLS enabled on all tables
- Single-tenant (no auth): anon + authenticated can CRUD all tables
- Data is intentionally shared for demo purposes

## Seed Data
- 3 org_units, 5 profiles, 3 meetings, 6 agenda items
- 3 minutes (pending, published, rejected)
- 5 decisions, 6 assignees, 2 followups, 1 obstacle, 2 agenda results
*/

-- ============================================================
-- SUPPORTING TABLES (order matters: org_units before profiles)
-- ============================================================

CREATE TABLE IF NOT EXISTS org_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50),
  parent_id UUID REFERENCES org_units(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profiles (
  user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  position VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(20),
  role VARCHAR(30) DEFAULT 'participant'
    CHECK (role IN ('secretary', 'manager', 'participant', 'executor')),
  unit_id UUID REFERENCES org_units(id),
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  meeting_date DATE NOT NULL,
  meeting_time VARCHAR(50),
  location VARCHAR(255),
  representative VARCHAR(255),
  phone VARCHAR(20),
  priority VARCHAR(20) DEFAULT 'medium'
    CHECK (priority IN ('critical', 'high', 'medium', 'low')),
  notes TEXT,
  organizer_id UUID REFERENCES profiles(user_id),
  status VARCHAR(20) DEFAULT 'scheduled'
    CHECK (status IN ('scheduled', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS meeting_agenda_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  number VARCHAR(20) NOT NULL,
  title VARCHAR(255) NOT NULL,
  presenter VARCHAR(255),
  duration VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- CORE TABLE 1: minutes
-- ============================================================

CREATE TABLE IF NOT EXISTS minutes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,

  snapshot_title VARCHAR(255) NOT NULL,
  snapshot_date DATE NOT NULL,
  snapshot_time VARCHAR(50),
  snapshot_location VARCHAR(255),
  snapshot_representative VARCHAR(255),
  snapshot_phone VARCHAR(20),
  snapshot_notes TEXT,
  snapshot_organizer_id UUID REFERENCES profiles(user_id),

  title VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft', 'pending', 'approved', 'rejected', 'published')),
  approval_type VARCHAR(20) DEFAULT 'systemic'
    CHECK (approval_type IN ('systemic', 'in_person')),
  security_level VARCHAR(20) DEFAULT 'general'
    CHECK (security_level IN ('general', 'organization', 'restricted', 'confidential')),

  version INTEGER DEFAULT 1,
  previous_version_id UUID REFERENCES minutes(id),
  change_reason TEXT,
  replaces_version_id UUID REFERENCES minutes(id),

  created_by UUID NOT NULL REFERENCES profiles(user_id),
  approved_by UUID REFERENCES profiles(user_id),
  approved_at TIMESTAMP,
  published_at TIMESTAMP,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  deleted_at TIMESTAMP WITH TIME ZONE,
  metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_minutes_meeting ON minutes(meeting_id);
CREATE INDEX IF NOT EXISTS idx_minutes_status ON minutes(status);
CREATE INDEX IF NOT EXISTS idx_minutes_created_by ON minutes(created_by);

-- ============================================================
-- CORE TABLE 2: minutes_participants
-- ============================================================

CREATE TABLE IF NOT EXISTS minutes_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  minutes_id UUID NOT NULL REFERENCES minutes(id) ON DELETE CASCADE,

  user_id UUID REFERENCES profiles(user_id),
  name VARCHAR(255) NOT NULL,
  is_external BOOLEAN DEFAULT false,
  position VARCHAR(255),
  company VARCHAR(255),
  phone VARCHAR(20),
  email VARCHAR(255),

  invite_status VARCHAR(20) NOT NULL DEFAULT 'invited'
    CHECK (invite_status IN ('invited', 'accepted', 'declined', 'delegated', 'no_response')),
  invite_response_date TIMESTAMP,
  delegate_user_id UUID REFERENCES profiles(user_id),
  delegate_name VARCHAR(255),

  attendance_status VARCHAR(20) DEFAULT 'unknown'
    CHECK (attendance_status IN ('present', 'absent', 'online', 'delegated', 'unknown')),
  attendance_note TEXT,
  attendance_updated_by UUID REFERENCES profiles(user_id),
  attendance_updated_at TIMESTAMP,

  approval_status VARCHAR(20) DEFAULT 'pending'
    CHECK (approval_status IN ('pending', 'approved', 'rejected')),
  approval_comment TEXT,
  approval_comments JSONB DEFAULT '{}'::jsonb,
  approved_at TIMESTAMP,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_minutes_participants_minutes ON minutes_participants(minutes_id);
CREATE INDEX IF NOT EXISTS idx_minutes_participants_user ON minutes_participants(user_id);

-- ============================================================
-- CORE TABLE 3: decisions
-- ============================================================

CREATE TABLE IF NOT EXISTS decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  minutes_id UUID NOT NULL REFERENCES minutes(id) ON DELETE CASCADE,
  agenda_item_id UUID REFERENCES meeting_agenda_items(id),

  number VARCHAR(20) NOT NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,

  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'in_progress', 'completed', 'rejected', 'overdue', 'cancelled')),
  priority VARCHAR(20) DEFAULT 'medium'
    CHECK (priority IN ('critical', 'high', 'medium', 'low')),

  progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  progress_status VARCHAR(20) DEFAULT 'not_started'
    CHECK (progress_status IN ('not_started', 'planned', 'in_progress', 'waiting_coordination', 'waiting_approval', 'completed', 'stopped')),

  deadline DATE,
  execution_start_date DATE,
  execution_due_date DATE,

  owner_unit_id UUID REFERENCES org_units(id),
  owner_user_id UUID REFERENCES profiles(user_id),
  owner_name VARCHAR(255),

  parent_decision_id UUID REFERENCES decisions(id),
  related_decisions UUID[] DEFAULT '{}',

  security_level VARCHAR(20) DEFAULT 'general'
    CHECK (security_level IN ('general', 'organization', 'restricted', 'confidential')),
  publish_status VARCHAR(20) DEFAULT 'draft'
    CHECK (publish_status IN ('draft', 'pending_publish', 'published')),

  created_by UUID REFERENCES profiles(user_id),
  completed_by UUID REFERENCES profiles(user_id),
  completed_at TIMESTAMP,
  rejected_by UUID REFERENCES profiles(user_id),
  rejected_at TIMESTAMP,
  rejected_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  deleted_at TIMESTAMP WITH TIME ZONE,
  metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_decisions_minutes ON decisions(minutes_id);
CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status);
CREATE INDEX IF NOT EXISTS idx_decisions_owner ON decisions(owner_user_id);

-- ============================================================
-- CORE TABLE 4: decision_assignees
-- ============================================================

CREATE TABLE IF NOT EXISTS decision_assignees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,

  unit_id UUID REFERENCES org_units(id),
  user_id UUID REFERENCES profiles(user_id),
  name VARCHAR(255),

  is_primary BOOLEAN DEFAULT false,
  is_proposer BOOLEAN DEFAULT false,
  is_collaborator BOOLEAN DEFAULT false,

  external_company VARCHAR(255),
  external_contact VARCHAR(255),
  external_phone VARCHAR(20),
  external_email VARCHAR(255),
  sms_sent BOOLEAN DEFAULT false,
  sms_sent_at TIMESTAMP,

  execution_delegate_user_id UUID REFERENCES profiles(user_id),
  execution_delegate_name VARCHAR(255),
  delegate_effective_from DATE,
  delegate_effective_to DATE,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_decision_assignees_decision ON decision_assignees(decision_id);

-- ============================================================
-- CORE TABLE 5: decision_followups
-- ============================================================

CREATE TABLE IF NOT EXISTS decision_followups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(user_id),

  content TEXT NOT NULL,
  progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),

  status VARCHAR(20) DEFAULT 'pending'
    CHECK (status IN ('pending', 'in_progress', 'resolved')),

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_decision_followups_decision ON decision_followups(decision_id);

-- ============================================================
-- CORE TABLE 6: decision_obstacles
-- ============================================================

CREATE TABLE IF NOT EXISTS decision_obstacles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,

  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  obstacle_type VARCHAR(30) NOT NULL
    CHECK (obstacle_type IN ('budget', 'coordination', 'approval', 'technical', 'supplier', 'priority_change', 'resource', 'other')),

  status VARCHAR(20) DEFAULT 'open'
    CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),

  assigned_to UUID REFERENCES profiles(user_id),

  due_date DATE,
  resolved_date DATE,
  resolved_by UUID REFERENCES profiles(user_id),
  resolution_notes TEXT,

  depends_on_decision_id UUID REFERENCES decisions(id),
  depends_on_obstacle_id UUID REFERENCES decision_obstacles(id),

  created_by UUID REFERENCES profiles(user_id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_decision_obstacles_decision ON decision_obstacles(decision_id);

-- ============================================================
-- CORE TABLE 7: decision_attachments
-- ============================================================

CREATE TABLE IF NOT EXISTS decision_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,

  file_url TEXT NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_type VARCHAR(50),
  file_size INTEGER,
  mime_type VARCHAR(100),

  uploaded_by UUID REFERENCES profiles(user_id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_decision_attachments_decision ON decision_attachments(decision_id);

-- ============================================================
-- CORE TABLE 8: agenda_results
-- ============================================================

CREATE TABLE IF NOT EXISTS agenda_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  minutes_id UUID NOT NULL REFERENCES minutes(id) ON DELETE CASCADE,
  agenda_item_id UUID NOT NULL REFERENCES meeting_agenda_items(id) ON DELETE CASCADE,

  discussion_summary TEXT NOT NULL,
  key_points TEXT,
  opinions_for TEXT,
  opinions_against TEXT,
  opinions_neutral TEXT,
  documents_presented TEXT[],

  result_type VARCHAR(30) NOT NULL
    CHECK (result_type IN ('discussion', 'action', 'decision', 'deferred', 'no_result')),

  decision_id UUID REFERENCES decisions(id),

  action_text TEXT,
  action_assignee UUID REFERENCES profiles(user_id),
  action_deadline DATE,

  next_meeting_date DATE,
  next_meeting_notes TEXT,

  created_by UUID REFERENCES profiles(user_id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_agenda_results_minutes ON agenda_results(minutes_id);

-- ============================================================
-- ROW LEVEL SECURITY — single-tenant, no auth
-- ============================================================

ALTER TABLE org_units ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE meeting_agenda_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE minutes ENABLE ROW LEVEL SECURITY;
ALTER TABLE minutes_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE decision_assignees ENABLE ROW LEVEL SECURITY;
ALTER TABLE decision_followups ENABLE ROW LEVEL SECURITY;
ALTER TABLE decision_obstacles ENABLE ROW LEVEL SECURITY;
ALTER TABLE decision_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE agenda_results ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'org_units','profiles','meetings','meeting_agenda_items',
    'minutes','minutes_participants','decisions','decision_assignees',
    'decision_followups','decision_obstacles','decision_attachments','agenda_results'
  ] LOOP
    EXECUTE format('DROP POLICY IF EXISTS "anon_select_%s" ON %I;', t, t);
    EXECUTE format('CREATE POLICY "anon_select_%s" ON %I FOR SELECT TO anon, authenticated USING (true);', t, t);

    EXECUTE format('DROP POLICY IF EXISTS "anon_insert_%s" ON %I;', t, t);
    EXECUTE format('CREATE POLICY "anon_insert_%s" ON %I FOR INSERT TO anon, authenticated WITH CHECK (true);', t, t);

    EXECUTE format('DROP POLICY IF EXISTS "anon_update_%s" ON %I;', t, t);
    EXECUTE format('CREATE POLICY "anon_update_%s" ON %I FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);', t, t);

    EXECUTE format('DROP POLICY IF EXISTS "anon_delete_%s" ON %I;', t, t);
    EXECUTE format('CREATE POLICY "anon_delete_%s" ON %I FOR DELETE TO anon, authenticated USING (true);', t, t);
  END LOOP;
END $$;

-- ============================================================
-- SEED DATA
-- ============================================================

INSERT INTO org_units (id, name, code) VALUES
  ('a0000000-0000-0000-0000-000000000001', 'واحد فناوری اطلاعات', 'IT'),
  ('a0000000-0000-0000-0000-000000000002', 'واحد مالی', 'FIN'),
  ('a0000000-0000-0000-0000-000000000003', 'واحد منابع انسانی', 'HR')
ON CONFLICT (id) DO NOTHING;

INSERT INTO profiles (user_id, name, position, email, phone, role, unit_id) VALUES
  ('b0000000-0000-0000-0000-000000000001', 'علی محمدی', 'مدیر پروژه', 'ali@example.com', '09121234567', 'secretary', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000002', 'سارا احمدی', 'کارشناس ارشد', 'sara@example.com', '09121234568', 'executor', 'a0000000-0000-0000-0000-000000000002'),
  ('b0000000-0000-0000-0000-000000000003', 'رضا کریمی', 'مدیر فنی', 'reza@example.com', '09121234569', 'manager', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000004', 'مهدی رضایی', 'کارشناس فنی', 'mehdi@example.com', '09121234570', 'participant', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000005', 'نرگس حسینی', 'کارشناس مالی', 'narges@example.com', '09121234571', 'participant', 'a0000000-0000-0000-0000-000000000002')
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO meetings (id, title, meeting_date, meeting_time, location, representative, phone, priority, notes, organizer_id) VALUES
  ('c0000000-0000-0000-0000-000000000001', 'بررسی پروژه توسعه نرم‌افزار', '2024-04-04', '۱۰:۰۰ - ۱۲:۰۰', 'سالن کنفرانس اصلی', 'علی محمدی', '09121234567', 'high', 'جلسه بررسی وضعیت پروژه', 'b0000000-0000-0000-0000-000000000001'),
  ('c0000000-0000-0000-0000-000000000002', 'جلسه بودجه سالانه', '2024-04-09', '۰۹:۰۰ - ۱۱:۰۰', 'سالن جلسات مدیریت', 'سارا احمدی', '09121234568', 'critical', 'بررسی بودجه سال مالی جدید', 'b0000000-0000-0000-0000-000000000002'),
  ('c0000000-0000-0000-0000-000000000003', 'بررسی عملکرد واحد فناوری اطلاعات', '2024-04-14', '۱۴:۰۰ - ۱۶:۰۰', 'سالن کنفرانس فرعی', 'رضا کریمی', '09121234569', 'medium', 'ارزیابی عملکرد فصلی', 'b0000000-0000-0000-0000-000000000003')
ON CONFLICT (id) DO NOTHING;

INSERT INTO meeting_agenda_items (id, meeting_id, number, title, presenter, duration) VALUES
  ('d0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', '۱', 'بررسی وضعیت پروژه', 'علی محمدی', '۲۰ دقیقه'),
  ('d0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000001', '۲', 'بررسی بودجه و منابع', 'سارا احمدی', '۱۵ دقیقه'),
  ('d0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000001', '۳', 'برنامه زمان‌بندی فاز دوم', 'رضا کریمی', '۳۰ دقیقه'),
  ('d0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000001', '۴', 'تصمیم‌گیری درباره تأمین', 'همه', '۱۰ دقیقه'),
  ('d0000000-0000-0000-0000-000000000005', 'c0000000-0000-0000-0000-000000000002', '۱', 'بررسی بودجه سالانه', 'سارا احمدی', '۴۵ دقیقه'),
  ('d0000000-0000-0000-0000-000000000006', 'c0000000-0000-0000-0000-000000000002', '۲', 'تخصیص بودجه به واحدها', 'رضا کریمی', '۳۰ دقیقه')
ON CONFLICT (id) DO NOTHING;

INSERT INTO minutes (id, meeting_id, snapshot_title, snapshot_date, snapshot_time, snapshot_location, snapshot_representative, snapshot_phone, snapshot_notes, snapshot_organizer_id, title, status, approval_type, version, created_by, created_at) VALUES
  ('e0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', 'بررسی پروژه توسعه نرم‌افزار', '2024-04-04', '۱۰:۰۰ - ۱۲:۰۰', 'سالن کنفرانس اصلی', 'علی محمدی', '09121234567', 'جلسه بررسی وضعیت پروژه', 'b0000000-0000-0000-0000-000000000001', 'صورتجلسه: بررسی پروژه توسعه نرم‌افزار', 'pending', 'systemic', 1, 'b0000000-0000-0000-0000-000000000001', '2024-04-04 10:00:00+00'),
  ('e0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000002', 'جلسه بودجه سالانه', '2024-04-09', '۰۹:۰۰ - ۱۱:۰۰', 'سالن جلسات مدیریت', 'سارا احمدی', '09121234568', 'بررسی بودجه سال مالی جدید', 'b0000000-0000-0000-0000-000000000002', 'صورتجلسه: جلسه بودجه سالانه', 'published', 'systemic', 1, 'b0000000-0000-0000-0000-000000000002', '2024-04-09 09:00:00+00'),
  ('e0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000003', 'بررسی عملکرد واحد فناوری اطلاعات', '2024-04-14', '۱۴:۰۰ - ۱۶:۰۰', 'سالن کنفرانس فرعی', 'رضا کریمی', '09121234569', 'ارزیابی عملکرد فصلی', 'b0000000-0000-0000-0000-000000000003', 'صورتجلسه: بررسی عملکرد واحد فناوری اطلاعات', 'rejected', 'systemic', 1, 'b0000000-0000-0000-0000-000000000003', '2024-04-14 14:00:00+00')
ON CONFLICT (id) DO NOTHING;

UPDATE minutes SET published_at = '2024-04-10 10:00:00+00' WHERE id = 'e0000000-0000-0000-0000-000000000002';

INSERT INTO minutes_participants (minutes_id, user_id, name, is_external, position, invite_status, attendance_status, approval_status) VALUES
  ('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'علی محمدی', false, 'مدیر پروژه', 'accepted', 'present', 'pending'),
  ('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', false, 'کارشناس ارشد', 'accepted', 'absent', 'pending'),
  ('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000003', 'رضا کریمی', false, 'مدیر فنی', 'delegated', 'delegated', 'pending'),
  ('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000004', 'مهدی رضایی', false, 'کارشناس فنی', 'accepted', 'present', 'pending'),
  ('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000005', 'نرگس حسینی', false, 'کارشناس مالی', 'no_response', 'unknown', 'pending')
ON CONFLICT DO NOTHING;

INSERT INTO decisions (id, minutes_id, agenda_item_id, number, title, content, status, priority, progress, progress_status, deadline, owner_user_id, owner_name, owner_unit_id, created_by, created_at) VALUES
  ('f0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', '۱', 'تأمین بودجه فاز دوم', 'تصویب می‌گردد مبلغ ۵۰۰ میلیون تومان برای تأمین بودجه فاز دوم پروژه اختصاص یابد.', 'in_progress', 'high', 70, 'in_progress', '2024-05-05', 'b0000000-0000-0000-0000-000000000001', 'علی محمدی', 'a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', '2024-04-04 11:00:00+00'),
  ('f0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004', '۲', 'استخدام نیروی جدید', 'تصویب می‌گردد استخدام ۳ نفر نیروی جدید فنی برای پروژه فاز دوم صورت گیرد.', 'overdue', 'high', 30, 'waiting_approval', '2024-04-20', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', 'a0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', '2024-04-04 11:30:00+00'),
  ('f0000000-0000-0000-0000-000000000003', 'e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', '۳', 'تهیه زیرساخت نرم‌افزاری', 'تصویب می‌گردد زیرساخت نرم‌افزاری لازم برای فاز دوم پروژه تهیه و راه‌اندازی شود.', 'completed', 'medium', 100, 'completed', '2024-04-30', 'b0000000-0000-0000-0000-000000000003', 'رضا کریمی', 'a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', '2024-04-04 11:45:00+00'),
  ('f0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000005', '۱', 'تأیید بودجه سالانه ۱۴۰۳', 'مجموع بودجه سالانه شرکت به مبلغ ۲۰۰ میلیارد تومان تصویب می‌گردد.', 'completed', 'critical', 100, 'completed', '2024-04-30', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', 'a0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', '2024-04-09 10:00:00+00'),
  ('f0000000-0000-0000-0000-000000000005', 'e0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000006', '۲', 'تخصیص بودجه واحد فناوری', 'مبلغ ۳۰ میلیارد تومان به واحد فناوری اطلاعات برای توسعه زیرساخت تخصیص یابد.', 'in_progress', 'high', 50, 'in_progress', '2024-05-15', 'b0000000-0000-0000-0000-000000000003', 'رضا کریمی', 'a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', '2024-04-09 10:30:00+00')
ON CONFLICT (id) DO NOTHING;

INSERT INTO decision_assignees (decision_id, user_id, name, is_primary, is_collaborator) VALUES
  ('f0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'علی محمدی', true, false),
  ('f0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', false, true),
  ('f0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', true, false),
  ('f0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 'رضا کریمی', true, false),
  ('f0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000002', 'سارا احمدی', true, false),
  ('f0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000003', 'رضا کریمی', true, false)
ON CONFLICT DO NOTHING;

INSERT INTO decision_followups (decision_id, user_id, content, progress, status, created_at) VALUES
  ('f0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'بودجه تأمین شده و در حال انتقال به حساب پروژه', 70, 'in_progress', '2024-04-25 10:00:00+00'),
  ('f0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'بودجه به حساب پروژه واریز شد. فرآیند خرید آغاز شده است.', 85, 'in_progress', '2024-05-01 10:00:00+00')
ON CONFLICT DO NOTHING;

INSERT INTO decision_obstacles (decision_id, title, description, obstacle_type, status, assigned_to, due_date, created_by, created_at) VALUES
  ('f0000000-0000-0000-0000-000000000002', 'عدم تأیید بودجه استخدام', 'با وجود تأمین نیروی مناسب، مدیریت ارشد هنوز بودجه استخدام را تأیید نکرده است.', 'approval', 'open', 'b0000000-0000-0000-0000-000000000001', '2024-04-30', 'b0000000-0000-0000-0000-000000000002', '2024-04-20 10:00:00+00')
ON CONFLICT DO NOTHING;

INSERT INTO agenda_results (minutes_id, agenda_item_id, discussion_summary, key_points, result_type, created_by, created_at) VALUES
  ('e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', 'برنامه زمان‌بندی فاز دوم مورد بحث قرار گرفت و مورد تأیید قرار گرفت.', 'زمان‌بندی قابل قبول است', 'decision', 'b0000000-0000-0000-0000-000000000001', '2024-04-04 11:00:00+00'),
  ('e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004', 'تصمیم‌گیری درباره تأمین منابع پروژه', 'نیاز به تأمین بودجه و نیروی جدید', 'decision', 'b0000000-0000-0000-0000-000000000001', '2024-04-04 11:30:00+00')
ON CONFLICT DO NOTHING;