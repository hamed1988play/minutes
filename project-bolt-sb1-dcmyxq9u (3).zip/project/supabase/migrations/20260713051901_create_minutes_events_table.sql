/*
# Create minutes_events table for workflow tracking

1. New Tables
- `minutes_events`: Tracks every event/action that happens to a minutes document
  - `id` (uuid, primary key)
  - `minutes_id` (uuid, FK to minutes)
  - `event_type` (text): 'created', 'updated', 'sent_for_approval', 'approved', 'rejected', 'published', 'shared', 'edited', 'participant_added', 'participant_removed', 'decision_added', 'decision_updated', 'attachment_added', 'signed', 'resend'
  - `event_title` (text): human-readable title in Persian
  - `event_description` (text): optional detailed description
  - `event_data` (jsonb): optional structured data about the event
  - `user_id` (text): who performed the action
  - `user_name` (text): name of the user
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `minutes_events`.
- Allow anon + authenticated CRUD (single-tenant app, no sign-in).
*/

CREATE TABLE IF NOT EXISTS minutes_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  minutes_id uuid NOT NULL REFERENCES minutes(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  event_title text NOT NULL,
  event_description text,
  event_data jsonb,
  user_id text,
  user_name text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE minutes_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_minutes_events" ON minutes_events;
CREATE POLICY "anon_select_minutes_events" ON minutes_events FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_minutes_events" ON minutes_events;
CREATE POLICY "anon_insert_minutes_events" ON minutes_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_minutes_events" ON minutes_events;
CREATE POLICY "anon_update_minutes_events" ON minutes_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_minutes_events" ON minutes_events;
CREATE POLICY "anon_delete_minutes_events" ON minutes_events FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_minutes_events_minutes_id ON minutes_events(minutes_id);
CREATE INDEX IF NOT EXISTS idx_minutes_events_created_at ON minutes_events(created_at DESC);
