/*
# Add attachments, signed minutes, secretary/chairperson to minutes

1. Modified Tables
- `minutes`: add `secretary_id` (uuid, nullable, references profiles) — meeting secretary responsible for follow-up of decisions.
- `minutes`: add `chairperson_id` (uuid, nullable, references profiles) — meeting chair responsible for approving/closing decisions.
- `minutes`: add `signed_minutes_url` (text, nullable) — URL of the uploaded signed minutes file.
2. New Tables
- `minutes_attachments`: stores files/images attached to a minutes document.
  - `id` (uuid PK)
  - `minutes_id` (uuid FK to minutes, cascade delete)
  - `file_url` (text, not null) — public URL of the file in Supabase Storage
  - `file_name` (text, not null)
  - `file_type` (text, nullable) — e.g. 'image', 'pdf', 'doc'
  - `file_size` (bigint, nullable) — size in bytes
  - `mime_type` (text, nullable)
  - `uploaded_by` (uuid, nullable, references profiles)
  - `created_at` (timestamptz, default now())
3. Security
- Enable RLS on `minutes_attachments`.
- Allow anon + authenticated full CRUD (single-tenant app, no sign-in).
4. Notes
- All new columns are nullable so existing rows remain valid.
- A Supabase Storage bucket named `minutes-attachments` should be created for file uploads.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'minutes' AND column_name = 'secretary_id'
  ) THEN
    ALTER TABLE minutes ADD COLUMN secretary_id UUID REFERENCES profiles(user_id);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'minutes' AND column_name = 'chairperson_id'
  ) THEN
    ALTER TABLE minutes ADD COLUMN chairperson_id UUID REFERENCES profiles(user_id);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'minutes' AND column_name = 'signed_minutes_url'
  ) THEN
    ALTER TABLE minutes ADD COLUMN signed_minutes_url TEXT;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS minutes_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  minutes_id UUID NOT NULL REFERENCES minutes(id) ON DELETE CASCADE,
  file_url TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT,
  file_size BIGINT,
  mime_type TEXT,
  uploaded_by UUID REFERENCES profiles(user_id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE minutes_attachments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_minutes_attachments" ON minutes_attachments;
CREATE POLICY "anon_select_minutes_attachments" ON minutes_attachments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_minutes_attachments" ON minutes_attachments;
CREATE POLICY "anon_insert_minutes_attachments" ON minutes_attachments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_minutes_attachments" ON minutes_attachments;
CREATE POLICY "anon_update_minutes_attachments" ON minutes_attachments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_minutes_attachments" ON minutes_attachments;
CREATE POLICY "anon_delete_minutes_attachments" ON minutes_attachments FOR DELETE
  TO anon, authenticated USING (true);
