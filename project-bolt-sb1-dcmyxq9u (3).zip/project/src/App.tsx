import { useState } from 'react';
import Layout, { type PageKey } from './components/Layout';
import MinutesPage from './pages/MinutesPage';
import MinutesForm from './pages/MinutesForm';
import MinutesDetail from './pages/MinutesDetail';
import ApprovalPanel from './pages/ApprovalPanel';
import MyDecisions from './pages/MyDecisions';
import FollowupTracking from './pages/FollowupTracking';
import DashboardPersonal from './pages/DashboardPersonal';
import ReportsPage from './pages/ReportsPage';

type View =
  | { name: 'page'; page: PageKey }
  | { name: 'minutes-list' }
  | { name: 'minutes-new' }
  | { name: 'minutes-edit'; id: string }
  | { name: 'minutes-detail'; id: string }
  | { name: 'followup-detail'; decisionId: string };

export default function App() {
  const [activePage, setActivePage] = useState<PageKey>('minutes');
  const [view, setView] = useState<View>({ name: 'page', page: 'minutes' });

  const handleNavigate = (page: PageKey) => {
    setActivePage(page);
    setView({ name: 'page', page });
  };

  const renderView = () => {
    switch (view.name) {
      case 'page':
        switch (view.page) {
          case 'minutes':
            return (
              <MinutesPage
                onView={(id) => setView({ name: 'minutes-detail', id })}
                onEdit={(id) => setView({ name: 'minutes-edit', id })}
                onNew={() => setView({ name: 'minutes-new' })}
              />
            );
          case 'approval':
            return <ApprovalPanel onView={(id) => setView({ name: 'minutes-detail', id })} />;
          case 'my-decisions':
            return (
              <MyDecisions onView={(minutesId) => setView({ name: 'minutes-detail', id: minutesId })} />
            );
          case 'followup':
            return (
              <FollowupTracking
                onView={(minutesId) => setView({ name: 'minutes-detail', id: minutesId })}
              />
            );
          case 'dashboard':
            return <DashboardPersonal onView={(id) => setView({ name: 'minutes-detail', id })} />;
          case 'reports':
            return <ReportsPage />;
        }
        break;

      case 'minutes-new':
        return (
          <MinutesForm
            minutesId={null}
            onSaved={() => setView({ name: 'page', page: 'minutes' })}
            onCancel={() => setView({ name: 'page', page: 'minutes' })}
          />
        );

      case 'minutes-edit':
        return (
          <MinutesForm
            minutesId={view.id}
            onSaved={() => setView({ name: 'minutes-detail', id: view.id })}
            onCancel={() => setView({ name: 'page', page: 'minutes' })}
          />
        );

      case 'minutes-detail':
        return (
          <MinutesDetail
            minutesId={view.id}
            onEdit={(id) => setView({ name: 'minutes-edit', id })}
            onBack={() => setView({ name: 'page', page: 'minutes' })}
          />
        );

      case 'followup-detail':
        return (
          <FollowupTracking onView={(minutesId) => setView({ name: 'minutes-detail', id: minutesId })} />
        );
    }
  };

  return (
    <Layout activePage={activePage} onNavigate={handleNavigate}>
      {renderView()}
    </Layout>
  );
}
