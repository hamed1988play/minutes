import type {
  MinutesStatus,
  DecisionStatus,
  Priority,
  ProgressStatus,
  InviteStatus,
  AttendanceStatus,
  ObstacleType,
  ResultType,
} from './types';

export const MINUTES_STATUS: Record<MinutesStatus, { label: string; color: string; bg: string; text: string; dot: string }> = {
  draft: { label: 'پیش‌نویس', color: 'gray', bg: 'bg-gray-100', text: 'text-gray-700', dot: 'bg-gray-400' },
  pending: { label: 'در انتظار تأیید', color: 'yellow', bg: 'bg-yellow-100', text: 'text-yellow-700', dot: 'bg-yellow-500' },
  approved: { label: 'تأییدشده', color: 'green', bg: 'bg-green-100', text: 'text-green-700', dot: 'bg-green-500' },
  rejected: { label: 'ردشده', color: 'red', bg: 'bg-red-100', text: 'text-red-700', dot: 'bg-red-500' },
  published: { label: 'منتشرشده', color: 'blue', bg: 'bg-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
};

export const DECISION_STATUS: Record<DecisionStatus, { label: string; bg: string; text: string; dot: string }> = {
  pending: { label: 'در انتظار', bg: 'bg-yellow-100', text: 'text-yellow-700', dot: 'bg-yellow-500' },
  in_progress: { label: 'در حال انجام', bg: 'bg-blue-100', text: 'text-blue-700', dot: 'bg-blue-500' },
  completed: { label: 'تکمیل‌شده', bg: 'bg-green-100', text: 'text-green-700', dot: 'bg-green-500' },
  rejected: { label: 'ردشده', bg: 'bg-red-100', text: 'text-red-700', dot: 'bg-red-500' },
  overdue: { label: 'معوق', bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-red-600' },
  cancelled: { label: 'لغو‌شده', bg: 'bg-gray-200', text: 'text-gray-600', dot: 'bg-gray-700' },
};

export const PRIORITY: Record<Priority, { label: string; bg: string; text: string; icon: string }> = {
  critical: { label: 'بحرانی', bg: 'bg-red-100', text: 'text-red-700', icon: '🔴' },
  high: { label: 'بالا', bg: 'bg-orange-100', text: 'text-orange-700', icon: '🟠' },
  medium: { label: 'متوسط', bg: 'bg-blue-100', text: 'text-blue-700', icon: '🔵' },
  low: { label: 'پایین', bg: 'bg-gray-100', text: 'text-gray-600', icon: '⚪' },
};

export const PROGRESS_STATUS: Record<ProgressStatus, { label: string; pct: number }> = {
  not_started: { label: 'شروع نشده', pct: 0 },
  planned: { label: 'برنامه‌ریزی‌شده', pct: 10 },
  in_progress: { label: 'در حال اجرا', pct: 50 },
  waiting_coordination: { label: 'در انتظار همکاری', pct: 50 },
  waiting_approval: { label: 'در انتظار تأیید', pct: 70 },
  completed: { label: 'تکمیل‌شده', pct: 100 },
  stopped: { label: 'متوقف', pct: 0 },
};

export const INVITE_STATUS: Record<InviteStatus, { label: string; icon: string; color: string }> = {
  invited: { label: 'دعوت‌شده', icon: '📧', color: 'text-gray-600' },
  accepted: { label: 'پذیرفته', icon: '✅', color: 'text-green-600' },
  declined: { label: 'ردشده', icon: '❌', color: 'text-red-600' },
  delegated: { label: 'تفویض‌شده', icon: '🔄', color: 'text-blue-600' },
  no_response: { label: 'بدون پاسخ', icon: '⏳', color: 'text-yellow-600' },
};

export const ATTENDANCE_STATUS: Record<AttendanceStatus, { label: string; dot: string; bg: string; text: string }> = {
  present: { label: 'حاضر', dot: 'bg-green-500', bg: 'bg-green-100', text: 'text-green-700' },
  absent: { label: 'غایب', dot: 'bg-yellow-500', bg: 'bg-yellow-100', text: 'text-yellow-700' },
  online: { label: 'حضور آنلاین', dot: 'bg-purple-500', bg: 'bg-purple-100', text: 'text-purple-700' },
  delegated: { label: 'حضور با جانشین', dot: 'bg-blue-500', bg: 'bg-blue-100', text: 'text-blue-700' },
  unknown: { label: 'نامشخص', dot: 'bg-gray-400', bg: 'bg-gray-100', text: 'text-gray-600' },
};

export const OBSTACLE_TYPES: Record<ObstacleType, { label: string; icon: string }> = {
  budget: { label: 'بودجه', icon: '💰' },
  coordination: { label: 'همکاری واحد دیگر', icon: '🤝' },
  approval: { label: 'تأیید مدیریت', icon: '📋' },
  technical: { label: 'مشکل فنی', icon: '🔧' },
  supplier: { label: 'تأمین‌کننده', icon: '📦' },
  priority_change: { label: 'تغییر اولویت', icon: '🔄' },
  resource: { label: 'منابع', icon: '👤' },
  other: { label: 'سایر', icon: '📌' },
};

export const RESULT_TYPES: Record<ResultType, { label: string; color: string }> = {
  discussion: { label: 'بحث و تبادل نظر', color: 'text-gray-600' },
  action: { label: 'اقدام', color: 'text-blue-600' },
  decision: { label: 'مصوبه', color: 'text-green-600' },
  deferred: { label: 'ارجاع به جلسه بعد', color: 'text-yellow-600' },
  no_result: { label: 'بدون نتیجه', color: 'text-red-600' },
};

export const CURRENT_USER_ID = 'b0000000-0000-0000-0000-000000000001';
export const CURRENT_USER_NAME = 'علی محمدی';
