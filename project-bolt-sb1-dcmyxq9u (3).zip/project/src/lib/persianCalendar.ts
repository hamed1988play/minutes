// Persian (Shamsi/Jalali) calendar utilities — no external dependency
// Based on the algorithm by Kazimierz M. Borkowski and the JPL method.

const PERSIAN_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

const PERSIAN_WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

function mod(a: number, b: number): number {
  return a - Math.floor(a / b) * b;
}

// Convert Gregorian date to Jalali (Shamsi)
export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
  let jy = -1595 + 33 * Math.floor(days / 12053);
  days = mod(days, 12053);
  let jm: number;
  for (let i = 0; i < 4; i++) {
    if (days < 1461) break;
    days -= 1461;
    jy += 33;
  }
  const leap = Math.floor((days - 1) / 365);
  if (leap > 0) {
    days -= 1 + leap * 365;
  }
  jy += leap;
  if (days < 186) {
    jm = 1 + Math.floor(days / 31);
    days = mod(days, 31);
  } else {
    jm = 7 + Math.floor((days - 186) / 30);
    days = mod(days - 186, 30);
  }
  return [jy, jm, days + 1];
}

// Convert Jalali to Gregorian
export function jalaliToGregorian(jy: number, jm: number, jd: number): [number, number, number] {
  let gy = (jy <= 979) ? 621 : 1600;
  jy -= jy <= 979 ? 0 : 979;
  let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor((mod(jy, 33) + 3) / 4) + 78 + jd;
  for (let i = 0; i < jm; i++) {
    days += i < 6 ? 31 : 30;
  }
  gy += Math.floor(days / 1461);
  days = mod(days, 1461);
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = mod(days - 1, 365);
  }
  const sal_a = [0, 31, 29 + (mod(gy, 4) === 0 && (mod(gy, 100) !== 0 || mod(gy, 400) === 0) ? 1 : 0), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gd = days + 1;
  let gm = 0;
  for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) {
    gd -= sal_a[gm];
  }
  return [gy, gm, gd];
}

// Check if a Jalali year is leap
export function isLeapJalali(jy: number): boolean {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  let jp = breaks[0];
  let jump = 0;
  for (let i = 1; i <= 19; i++) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    jp = jm;
  }
  let n = jy - jp;
  if (n < jump) {
    if (mod(jump - n, 33) === 0) return true;
    if (mod(n, 4) === 0 && n + 1 !== jump) return true;
  }
  return false;
}

// Get days in a Jalali month
export function getDaysInJalaliMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalali(jy) ? 30 : 29;
}

// Convert a Date object to a Jalali date string "YYYY/MM/DD" (Persian digits)
export function toJalaliString(date: Date | string | null): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const [jy, jm, jd] = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return `${toPersianDigits(jy)}/${toPersianDigits(jm).padStart(2, '۰')}/${toPersianDigits(jd).padStart(2, '۰')}`;
}

// Convert a Jalali date string "YYYY/MM/DD" (Persian or English digits) to ISO Gregorian string
export function jalaliToISO(jalaliStr: string): string | null {
  if (!jalaliStr) return null;
  const parts = jalaliStr.split('/').map((p) => fromPersianDigits(p.trim()));
  if (parts.length !== 3 || parts.some(p => isNaN(Number(p)))) return null;
  const [jy, jm, jd] = parts.map(Number);
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
  const d = new Date(gy, gm - 1, gd);
  return d.toISOString().split('T')[0];
}

// Check if a string is a Jalali date (YYYY/MM/DD with Persian or English digits)
export function isJalaliDate(str: string): boolean {
  if (!str) return false;
  const cleaned = str.split('/').map((p) => fromPersianDigits(p.trim()));
  if (cleaned.length !== 3) return false;
  return !cleaned.some(p => isNaN(Number(p)));
}

// Format a date for display — handles both ISO dates and Jalali text dates
export function formatPersianDate(dateStr: string | null): string {
  if (!dateStr) return '-';
  // If it's already a Jalali date string (YYYY/MM/DD)
  if (isJalaliDate(dateStr)) {
    return dateStr;
  }
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return toJalaliString(d);
  } catch {
    return dateStr;
  }
}

// Convert English digits to Persian digits
export function toPersianDigits(n: number | string): string {
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(n).replace(/\d/g, (d) => persian[Number(d)]);
}

// Convert Persian digits to English digits
export function fromPersianDigits(str: string): string {
  return str
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

export { PERSIAN_MONTH_NAMES, PERSIAN_WEEKDAYS };
