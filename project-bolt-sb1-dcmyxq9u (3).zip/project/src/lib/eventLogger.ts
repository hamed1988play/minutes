import { supabase } from './supabase';
import { CURRENT_USER_ID, CURRENT_USER_NAME } from './constants';

export async function logMinutesEvent(
  minutesId: string,
  eventType: string,
  eventTitle: string,
  eventDescription?: string,
  eventData?: Record<string, unknown>,
) {
  await supabase.from('minutes_events').insert({
    minutes_id: minutesId,
    event_type: eventType,
    event_title: eventTitle,
    event_description: eventDescription || null,
    event_data: eventData || null,
    user_id: CURRENT_USER_ID,
    user_name: CURRENT_USER_NAME,
  });
}
