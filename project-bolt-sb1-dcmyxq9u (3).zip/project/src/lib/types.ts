export type MinutesStatus = 'draft' | 'pending' | 'approved' | 'rejected' | 'published';
export type ApprovalType = 'systemic' | 'in_person';
export type SecurityLevel = 'general' | 'organization' | 'restricted' | 'confidential';

export type DecisionStatus = 'pending' | 'in_progress' | 'completed' | 'rejected' | 'overdue' | 'cancelled';
export type Priority = 'critical' | 'high' | 'medium' | 'low';
export type ProgressStatus = 'not_started' | 'planned' | 'in_progress' | 'waiting_coordination' | 'waiting_approval' | 'completed' | 'stopped';

export type InviteStatus = 'invited' | 'accepted' | 'declined' | 'delegated' | 'no_response';
export type AttendanceStatus = 'present' | 'absent' | 'online' | 'delegated' | 'unknown';
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export type ObstacleType = 'budget' | 'coordination' | 'approval' | 'technical' | 'supplier' | 'priority_change' | 'resource' | 'other';
export type ObstacleStatus = 'open' | 'in_progress' | 'resolved' | 'closed';

export type ResultType = 'discussion' | 'action' | 'decision' | 'deferred' | 'no_result';

export interface Profile {
  user_id: string;
  name: string;
  position: string | null;
  email: string | null;
  phone: string | null;
  role: string;
  unit_id: string | null;
}

export interface OrgUnit {
  id: string;
  name: string;
  code: string | null;
}

export interface Meeting {
  id: string;
  title: string;
  meeting_date: string;
  meeting_time: string | null;
  location: string | null;
  representative: string | null;
  phone: string | null;
  priority: Priority;
  notes: string | null;
  organizer_id: string | null;
}

export interface MeetingAgendaItem {
  id: string;
  meeting_id: string;
  number: string;
  title: string;
  presenter: string | null;
  duration: string | null;
}

export interface Minutes {
  id: string;
  meeting_id: string;
  snapshot_title: string;
  snapshot_date: string;
  snapshot_time: string | null;
  snapshot_location: string | null;
  snapshot_representative: string | null;
  snapshot_phone: string | null;
  snapshot_notes: string | null;
  snapshot_organizer_id: string | null;
  title: string;
  status: MinutesStatus;
  approval_type: ApprovalType;
  security_level: SecurityLevel;
  version: number;
  created_by: string;
  approved_by: string | null;
  approved_at: string | null;
  published_at: string | null;
  secretary_id: string | null;
  chairperson_id: string | null;
  signed_minutes_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface MinutesAttachment {
  id: string;
  minutes_id: string;
  file_url: string;
  file_name: string;
  file_type: string | null;
  file_size: number | null;
  mime_type: string | null;
  uploaded_by: string | null;
  created_at: string;
}

export interface MinutesParticipant {
  id: string;
  minutes_id: string;
  user_id: string | null;
  name: string;
  is_external: boolean;
  position: string | null;
  company: string | null;
  phone: string | null;
  email: string | null;
  invite_status: InviteStatus;
  delegate_name: string | null;
  attendance_status: AttendanceStatus;
  attendance_note: string | null;
  approval_status: ApprovalStatus;
  approval_comment: string | null;
  approved_at: string | null;
}

export interface Decision {
  id: string;
  minutes_id: string;
  agenda_item_id: string | null;
  number: string;
  title: string;
  content: string;
  status: DecisionStatus;
  priority: Priority;
  progress: number;
  progress_status: ProgressStatus;
  deadline: string | null;
  owner_user_id: string | null;
  owner_name: string | null;
  owner_unit_id: string | null;
  created_by: string | null;
  completed_at: string | null;
  created_at: string;
}

export interface DecisionAssignee {
  id: string;
  decision_id: string;
  user_id: string | null;
  name: string | null;
  is_primary: boolean;
  is_proposer: boolean;
  is_collaborator: boolean;
  external_company: string | null;
  external_contact: string | null;
  external_phone: string | null;
}

export interface DecisionFollowup {
  id: string;
  decision_id: string;
  user_id: string;
  content: string;
  progress: number;
  status: string;
  created_at: string;
}

export interface DecisionObstacle {
  id: string;
  decision_id: string;
  title: string;
  description: string;
  obstacle_type: ObstacleType;
  status: ObstacleStatus;
  assigned_to: string | null;
  due_date: string | null;
  resolved_date: string | null;
  resolution_notes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface DecisionAttachment {
  id: string;
  decision_id: string;
  file_url: string;
  file_name: string;
  file_type: string | null;
  file_size: number | null;
  mime_type: string | null;
  uploaded_by: string | null;
  created_at: string;
}

export interface MinutesEvent {
  id: string;
  minutes_id: string;
  event_type: string;
  event_title: string;
  event_description: string | null;
  event_data: Record<string, unknown> | null;
  user_id: string | null;
  user_name: string | null;
  created_at: string;
}

export interface AgendaResult {
  id: string;
  minutes_id: string;
  agenda_item_id: string;
  discussion_summary: string;
  key_points: string | null;
  opinions_for: string | null;
  opinions_against: string | null;
  result_type: ResultType;
  decision_id: string | null;
  action_text: string | null;
  next_meeting_date: string | null;
  created_at: string;
}
