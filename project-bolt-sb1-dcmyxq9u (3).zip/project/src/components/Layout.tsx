import { useState, type ReactNode } from 'react';
import {
  FileText,
  CheckSquare,
  ClipboardList,
  TrendingUp,
  LayoutDashboard,
  Menu,
  X,
  Bell,
  Search,
  BarChart3,
} from 'lucide-react';
import { CURRENT_USER_NAME } from '../lib/constants';

export type PageKey =
  | 'minutes'
  | 'approval'
  | 'my-decisions'
  | 'followup'
  | 'reports'
  | 'dashboard';

interface NavItem {
  key: PageKey;
  label: string;
  icon: typeof FileText;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'minutes', label: 'لیست صورتجلسات', icon: FileText },
  { key: 'approval', label: 'کارتابل تأیید', icon: CheckSquare },
  { key: 'my-decisions', label: 'کارتابل مصوبات من', icon: ClipboardList },
  { key: 'followup', label: 'پیگیری مصوبات', icon: TrendingUp },
  { key: 'reports', label: 'گزارش‌ساز', icon: BarChart3 },
  { key: 'dashboard', label: 'داشبورد شخصی', icon: LayoutDashboard },
];

interface LayoutProps {
  activePage: PageKey;
  onNavigate: (page: PageKey) => void;
  children: ReactNode;
}

export default function Layout({ activePage, onNavigate, children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const activeItem = NAV_ITEMS.find((item) => item.key === activePage);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 right-0 h-screen w-72 bg-white border-l border-slate-200 z-40 transition-transform duration-300 flex flex-col ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="h-16 flex items-center justify-between px-5 border-b border-slate-200 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-800 leading-tight">سیستم صورتجلسات</h1>
              <p className="text-xs text-slate-500">و مصوبات</p>
            </div>
          </div>
          <button
            className="lg:hidden text-slate-500 hover:text-slate-700"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <div className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => {
                    onNavigate(item.key);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-slate-800 text-white shadow-sm'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="flex-1 text-right">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>

        <div className="p-4 border-t border-slate-200 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center text-white font-bold text-sm">
              ع
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800 truncate">{CURRENT_USER_NAME}</p>
              <p className="text-xs text-slate-500">دبیر جلسه</p>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-20 flex items-center justify-between px-4 lg:px-6">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden text-slate-600 hover:text-slate-800"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-6 h-6" />
            </button>
            <h2 className="text-base font-bold text-slate-800">{activeItem?.label}</h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="جستجو..."
                className="bg-transparent text-sm outline-none w-40 text-slate-700 placeholder:text-slate-400"
              />
            </div>
            <button className="relative p-2 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 left-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          <div className="animate-fadeIn">{children}</div>
        </main>
      </div>
    </div>
  );
}
