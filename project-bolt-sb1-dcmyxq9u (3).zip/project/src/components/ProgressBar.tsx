interface ProgressBarProps {
  value: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function ProgressBar({ value, showLabel = true, size = 'md' }: ProgressBarProps) {
  const height = size === 'sm' ? 'h-1.5' : size === 'lg' ? 'h-3' : 'h-2';
  const colorClass =
    value >= 100 ? 'bg-green-500' : value >= 70 ? 'bg-blue-500' : value >= 30 ? 'bg-amber-500' : value > 0 ? 'bg-orange-500' : 'bg-slate-300';

  return (
    <div className="flex items-center gap-2">
      <div className={`flex-1 ${height} bg-slate-200 rounded-full overflow-hidden`}>
        <div
          className={`${height} ${colorClass} rounded-full transition-all duration-500`}
          style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
        />
      </div>
      {showLabel && (
        <span className="text-xs font-medium text-slate-600 min-w-[3rem] text-left">{value}%</span>
      )}
    </div>
  );
}
