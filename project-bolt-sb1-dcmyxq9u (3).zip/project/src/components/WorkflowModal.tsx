import { useState, useEffect } from 'react';
import {
  FileText,
  Send,
  CheckCircle,
  XCircle,
  Share2,
  Pencil,
  Users,
  CheckSquare,
  Paperclip,
  PenTool,
  RefreshCw,
  Clock,
  GitBranch,
  MessageSquare,
  AlertCircle,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPersianDate } from '../lib/persianCalendar';
import type { MinutesEvent, Decision } from '../lib/types';
import Modal from './Modal';

const EVENT_ICONS: Record<string, typeof FileText> = {
  created: FileText,
  updated: Pencil,
  sent_for_approval: Send,
  approved: CheckCircle,
  rejected: XCircle,
  published: Share2,
  shared: Share2,
  edited: Pencil,
  participant_added: Users,
  participant_removed: Users,
  decision_added: CheckSquare,
  decision_updated: Pencil,
  attachment_added: Paperclip,
  signed: PenTool,
  resend: RefreshCw,
  review_comment: MessageSquare,
  decision_comment: AlertCircle,
};

const EVENT_COLORS: Record<string, string> = {
  created: 'bg-slate-100 text-slate-600',
  updated: 'bg-blue-100 text-blue-600',
  sent_for_approval: 'bg-yellow-100 text-yellow-600',
  approved: 'bg-green-100 text-green-600',
  rejected: 'bg-red-100 text-red-600',
  published: 'bg-green-100 text-green-600',
  shared: 'bg-purple-100 text-purple-600',
  edited: 'bg-blue-100 text-blue-600',
  participant_added: 'bg-blue-100 text-blue-600',
  participant_removed: 'bg-slate-100 text-slate-500',
  decision_added: 'bg-green-100 text-green-600',
  decision_updated: 'bg-blue-100 text-blue-600',
  attachment_added: 'bg-orange-100 text-orange-600',
  signed: 'bg-green-100 text-green-600',
  resend: 'bg-yellow-100 text-yellow-600',
  review_comment: 'bg-amber-100 text-amber-600',
  decision_comment: 'bg-amber-100 text-amber-600',
};

interface WorkflowModalProps {
  minutesId: string;
  minutesTitle: string;
  open: boolean;
  onClose: () => void;
}

interface ReviewEntry {
  action: string;
  general_comment?: string;
  decision_comments?: Record<string, string>;
  reviewed_at?: string;
  reviewer_id?: string;
}

export default function WorkflowModal({ minutesId, minutesTitle, open, onClose }: WorkflowModalProps) {
  const [events, setEvents] = useState<MinutesEvent[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open || !minutesId) return;
    setLoading(true);

    (async () => {
      const [{ data: evData }, { data: decData }, { data: minData }] = await Promise.all([
        supabase.from('minutes_events').select('*').eq('minutes_id', minutesId).order('created_at', { ascending: true }),
        supabase.from('decisions').select('*').eq('minutes_id', minutesId).order('number'),
        supabase.from('minutes').select('metadata').eq('id', minutesId).maybeSingle(),
      ]);

      const allEvents: MinutesEvent[] = [...((evData as MinutesEvent[]) || [])];
      const decMap = new Map<string, Decision>();
      (decData as Decision[] | null)?.forEach((d) => decMap.set(d.id, d));

      // Extract review comments from metadata and convert to events
      const meta = minData?.metadata as Record<string, unknown> | null;
      const reviews = (meta?.reviews as ReviewEntry[]) || [];
      reviews.forEach((r) => {
        const ts = r.reviewed_at || new Date().toISOString();
        allEvents.push({
          id: `review-${ts}`,
          minutes_id: minutesId,
          event_type: 'review_comment',
          event_title: r.action === 'approved' ? 'تأیید با نظر' : 'رد با نظر',
          event_description: r.general_comment || 'بدون نظر کلی',
          event_data: { decision_comments: r.decision_comments },
          user_id: r.reviewer_id || null,
          user_name: null,
          created_at: ts,
        });
      });

      allEvents.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
      setDecisions(Array.from(decMap.values()));
      setEvents(allEvents);
      setLoading(false);
    })();
  }, [open, minutesId]);

  return (
    <Modal open={open} onClose={onClose} title={`گردش کار: ${minutesTitle}`} size="lg">
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-slate-500 bg-slate-50 rounded-lg p-3">
          <GitBranch className="w-4 h-4" />
          تمام اتفاقات و تغییرات صورتجلسه از زمان ایجاد تاکنون
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="w-5 h-5 text-slate-400 animate-spin" />
          </div>
        ) : events.length === 0 ? (
          <div className="flex flex-col items-center py-8 text-center">
            <Clock className="w-10 h-10 text-slate-300 mb-2" />
            <p className="text-sm text-slate-500">رویدادی ثبت نشده است</p>
          </div>
        ) : (
          <div className="relative pr-6 max-h-[60vh] overflow-y-auto">
            {/* Vertical line */}
            <div className="absolute right-2.5 top-2 bottom-2 w-0.5 bg-slate-200" />

            <div className="space-y-4">
              {events.map((ev, idx) => {
                const Icon = EVENT_ICONS[ev.event_type] || FileText;
                const color = EVENT_COLORS[ev.event_type] || 'bg-slate-100 text-slate-600';
                const decComments = ev.event_data?.decision_comments as Record<string, string> | undefined;
                return (
                  <div key={ev.id} className="relative pr-6 animate-fadeIn" style={{ animationDelay: `${idx * 30}ms` }}>
                    {/* Dot on the line */}
                    <div className={`absolute right-0 top-1 w-5 h-5 rounded-full ${color} flex items-center justify-center ring-4 ring-white`}>
                      <Icon className="w-3 h-3" />
                    </div>

                    <div className="bg-white border border-slate-200 rounded-lg p-3">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h4 className="text-sm font-semibold text-slate-800">{ev.event_title}</h4>
                        <span className="text-xs text-slate-400 shrink-0">{formatPersianDate(ev.created_at)}</span>
                      </div>
                      {ev.event_description && (
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed whitespace-pre-wrap">{ev.event_description}</p>
                      )}
                      {decComments && Object.keys(decComments).length > 0 && (
                        <div className="mt-2 space-y-1 border-t border-slate-100 pt-2">
                          <p className="text-xs font-medium text-slate-500">نظرات روی بندها:</p>
                          {Object.entries(decComments).map(([decId, comment]) => {
                            const dec = decisions.find((d) => d.id === decId);
                            return (
                              <div key={decId} className="text-xs text-slate-600 bg-amber-50 rounded p-1.5">
                                <span className="font-medium">بند {dec?.number || '?'}:</span> {comment}
                              </div>
                            );
                          })}
                        </div>
                      )}
                      {ev.user_name && (
                        <div className="flex items-center gap-1 mt-2 text-xs text-slate-400">
                          <Users className="w-3 h-3" />
                          {ev.user_name}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
