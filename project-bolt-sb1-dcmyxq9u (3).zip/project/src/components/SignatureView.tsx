import { useState, useEffect, useRef } from 'react';
import { Printer, X, FileText, FileDown, Upload, FileSignature } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPersianDate } from '../lib/persianCalendar';
import type { Minutes, MinutesParticipant, Decision, MeetingAgendaItem, Profile } from '../lib/types';

interface SignatureViewProps {
  minutesId: string;
  onClose: () => void;
}

export default function SignatureView({ minutesId, onClose }: SignatureViewProps) {
  const [minutes, setMinutes] = useState<Minutes | null>(null);
  const [participants, setParticipants] = useState<MinutesParticipant[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [agendaItems, setAgendaItems] = useState<MeetingAgendaItem[]>([]);
  const [creator, setCreator] = useState<Profile | null>(null);
  const [secretary, setSecretary] = useState<Profile | null>(null);
  const [chairperson, setChairperson] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: min } = await supabase.from('minutes').select('*').eq('id', minutesId).maybeSingle();
      if (!min) { setLoading(false); return; }
      const m = min as Minutes;
      setMinutes(m);
      setSignedUrl(m.signed_minutes_url);

      const { data: prof } = await supabase.from('profiles').select('*').eq('user_id', m.created_by).maybeSingle();
      setCreator(prof as Profile);

      if (m.secretary_id) {
        const { data: sec } = await supabase.from('profiles').select('*').eq('user_id', m.secretary_id).maybeSingle();
        setSecretary(sec as Profile);
      }
      if (m.chairperson_id) {
        const { data: ch } = await supabase.from('profiles').select('*').eq('user_id', m.chairperson_id).maybeSingle();
        setChairperson(ch as Profile);
      }

      const { data: parts } = await supabase.from('minutes_participants').select('*').eq('minutes_id', minutesId).order('created_at');
      setParticipants((parts as MinutesParticipant[]) || []);

      const { data: decs } = await supabase.from('decisions').select('*').eq('minutes_id', minutesId).order('number');
      setDecisions((decs as Decision[]) || []);

      const { data: meeting } = await supabase.from('meetings').select('*').eq('id', m.meeting_id).maybeSingle();
      if (meeting) {
        const { data: agenda } = await supabase.from('meeting_agenda_items').select('*').eq('meeting_id', (meeting as { id: string }).id).order('number');
        setAgendaItems((agenda as MeetingAgendaItem[]) || []);
      }

      setLoading(false);
    };
    fetchData();
  }, [minutesId]);

  const signatories = participants.filter((p) => p.attendance_status === 'present' || p.attendance_status === 'online');

  const handlePrint = () => window.print();

  const exportHTML = () => {
    const el = document.getElementById('signature-print-area');
    if (!el) return;
    const html = `<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8"><title>صورتجلسه</title>
    <style>
      body{font-family:Tahoma,Arial,sans-serif;padding:20px;max-width:800px;margin:0 auto;}
      table{width:100%;border-collapse:collapse;}td,th{border:1px solid #999;padding:6px;font-size:12px;}
      h1,h2,h3{margin:8px 0;}.info-row{display:flex;gap:8px;margin:4px 0;font-size:12px;}
      .sig-box{border:1px solid #999;padding:8px;text-align:center;min-height:70px;font-size:11px;}
      .sig-grid{display:grid;gap:8px;}
      @media print{.no-print{display:none;}}
    </style></head><body>${el.innerHTML}</body></html>`;
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  };

  const exportWord = () => {
    const el = document.getElementById('signature-print-area');
    if (!el) return;
    const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset="utf-8"><title>صورتجلسه</title></head><body dir="rtl" style="font-family:Tahoma,Arial,sans-serif;">`;
    const footer = '</body></html>';
    const source = header + el.innerHTML + footer;
    const blob = new Blob(['\ufeff', source], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `صورتجلسه-${minutes?.snapshot_title || ''}.doc`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUploadSigned = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !minutes) return;
    setUploading(true);
    const ext = file.name.split('.').pop();
    const path = `${minutes.id}/signed-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from('minutes-attachments').upload(path, file);
    if (upErr) {
      setUploading(false);
      alert('خطا در بارگذاری فایل');
      return;
    }
    const { data: pub } = supabase.storage.from('minutes-attachments').getPublicUrl(path);
    const { error } = await supabase.from('minutes').update({ signed_minutes_url: pub.publicUrl }).eq('id', minutes.id);
    setUploading(false);
    if (error) alert('خطا در ذخیره');
    else setSignedUrl(pub.publicUrl);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-white">
        <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }
  if (!minutes) return null;

  // Build the full signature list: all signatories + secretary + chairperson
  const secretaryName = secretary?.name || creator?.name || '';
  const chairpersonName = chairperson?.name || minutes.snapshot_representative || '';

  // All signatures in one row — if >8, split into 2 rows but keep same grid
  const allSigners = [
    ...signatories.map((p) => ({ name: p.name, position: p.position || '' })),
    { name: secretaryName, position: 'دبیر جلسه' },
    { name: chairpersonName, position: 'رئیس جلسه' },
  ].filter((s) => s.name);

  const sigCount = allSigners.length;
  const cols = sigCount > 8 ? Math.ceil(sigCount / 2) : Math.max(sigCount, 1);
  const gridCols = `repeat(${Math.min(cols, 8)}, 1fr)`;

  return (
    <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
      <input ref={fileInputRef} type="file" accept="image/*,.pdf,.doc,.docx" className="hidden" onChange={handleUploadSigned} />

      <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between print:hidden">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-slate-600" />
          <h2 className="text-sm font-bold text-slate-800">دریافت صورتجلسه جهت امضا</h2>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={exportWord} className="btn-secondary text-xs">
            <FileDown className="w-4 h-4" />
            خروجی Word
          </button>
          <button onClick={exportHTML} className="btn-secondary text-xs">
            <Printer className="w-4 h-4" />
            خروجی PDF
          </button>
          <button onClick={handlePrint} className="btn-primary text-xs">
            <Printer className="w-4 h-4" />
            چاپ
          </button>
          <button onClick={onClose} className="btn-secondary text-xs">
            <X className="w-4 h-4" />
            بستن
          </button>
        </div>
      </div>

      {/* Signed minutes upload section */}
      <div className="max-w-4xl mx-auto px-8 pt-4 print:hidden">
        <div className="card p-4 bg-slate-50 border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileSignature className="w-5 h-5 text-slate-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">ضمیمه صورتجلسه امضا‌شده</p>
              <p className="text-xs text-slate-500">فایل امضا‌شده را بارگذاری کنید</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {signedUrl && (
              <a
                href={signedUrl || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary text-xs text-green-600"
              >
                <FileText className="w-3.5 h-3.5" />
                مشاهده فایل
              </a>
            )}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="btn-primary text-xs"
            >
              <Upload className="w-3.5 h-3.5" />
              {uploading ? 'در حال بارگذاری...' : 'بارگذاری'}
            </button>
          </div>
        </div>
      </div>

      {/* Print content — standard A4 page layout */}
      <div id="signature-print-area" className="max-w-4xl mx-auto p-8 print:p-0" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        {/* Header */}
        <div className="text-center mb-6 pb-4 border-b-2 border-slate-800">
          <h1 className="text-lg font-bold text-slate-900">بسمه تعالی</h1>
          <h2 className="text-base font-bold text-slate-800 mt-3">صورتجلسه جلسه</h2>
          <p className="text-sm text-slate-700 mt-1">{minutes.snapshot_title}</p>
        </div>

        {/* Meeting info */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-3 mb-6 text-sm">
          <InfoRow label="عنوان جلسه" value={minutes.snapshot_title} />
          <InfoRow label="تاریخ جلسه" value={formatPersianDate(minutes.snapshot_date)} />
          <InfoRow label="ساعت" value={minutes.snapshot_time || '-'} />
          <InfoRow label="محل برگزاری" value={minutes.snapshot_location || '-'} />
          <InfoRow label="نماینده" value={minutes.snapshot_representative || '-'} />
          <InfoRow label="دبیر جلسه" value={secretaryName || '-'} />
          {/* Page number under secretary */}
          <div className="col-span-2 text-xs text-slate-500 mt-1">صفحه ۱ از ۱</div>
        </div>

        {/* Agenda items */}
        {agendaItems.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 mb-2 border-b border-slate-300 pb-1">دستور جلسه</h3>
            <table className="w-full text-xs border border-slate-300">
              <thead>
                <tr className="bg-slate-100">
                  <th className="border border-slate-300 px-2 py-1.5 text-right w-10">ردیف</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right">عنوان</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right w-32">ارائه‌دهنده</th>
                  <th className="border border-slate-300 px-2 py-1.5 text-right w-20">زمان</th>
                </tr>
              </thead>
              <tbody>
                {agendaItems.map((item) => (
                  <tr key={item.id}>
                    <td className="border border-slate-300 px-2 py-1.5 text-center">{item.number}</td>
                    <td className="border border-slate-300 px-2 py-1.5">{item.title}</td>
                    <td className="border border-slate-300 px-2 py-1.5">{item.presenter || '-'}</td>
                    <td className="border border-slate-300 px-2 py-1.5 text-center">{item.duration || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Decisions — text only, no title */}
        {decisions.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-bold text-slate-800 mb-2 border-b border-slate-300 pb-1">مصوبات جلسه</h3>
            <div className="space-y-3">
              {decisions.map((d) => (
                <div key={d.id} className="border border-slate-300 rounded p-3">
                  <div className="flex items-start gap-2 mb-1">
                    <span className="text-xs font-bold bg-slate-200 px-1.5 py-0.5 rounded shrink-0">بند {d.number}</span>
                    <p className="text-xs text-slate-700 leading-relaxed flex-1">{d.content}</p>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600 mt-2">
                    <span>مسئول: {d.owner_name || '-'}</span>
                    {d.deadline && <span>مهلت: {formatPersianDate(d.deadline)}</span>}
                    <span>اولویت: {d.priority}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Signatures section — always at the bottom of the page */}
        <div className="mt-auto pt-8">
          <h3 className="text-sm font-bold text-slate-800 mb-3 border-b border-slate-300 pb-1">حاضرین و امضای آنان</h3>
          <div
            className="grid gap-3"
            style={{ gridTemplateColumns: gridCols }}
          >
            {allSigners.map((s, i) => (
              <div
                key={i}
                className="border border-slate-300 rounded-lg p-2 text-center"
                style={{ minHeight: sigCount > 8 ? '80px' : '100px' }}
              >
                <p className="text-xs font-bold text-slate-800 truncate">{s.name}</p>
                <p className="text-[10px] text-slate-500 truncate">{s.position}</p>
                <div
                  className="border-b border-slate-400 mt-2"
                  style={{ height: sigCount > 8 ? '30px' : '45px' }}
                >
                  <span className="text-[10px] text-slate-400">محل امضا</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs font-medium text-slate-500 min-w-[80px]">{label}:</span>
      <span className="text-xs text-slate-800 font-medium">{value}</span>
    </div>
  );
}
