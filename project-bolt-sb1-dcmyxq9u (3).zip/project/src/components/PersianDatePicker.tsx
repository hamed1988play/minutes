import { useState, useRef, useEffect } from 'react';
import { Calendar } from 'lucide-react';
import {
  gregorianToJalali,
  jalaliToGregorian,
  getDaysInJalaliMonth,
  isJalaliDate,
  toPersianDigits,
  fromPersianDigits,
  PERSIAN_MONTH_NAMES,
  PERSIAN_WEEKDAYS,
} from '../lib/persianCalendar';

interface PersianDatePickerProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function PersianDatePicker({ value, onChange, placeholder = 'مثال: ۱۴۰۳/۰۳/۱۵' }: PersianDatePickerProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Parse current value or default to today
  const getInitialJalali = (): [number, number, number] => {
    if (value && isJalaliDate(value)) {
      const parts = value.split('/').map((p) => Number(fromPersianDigits(p.trim())));
      return [parts[0], parts[1], parts[2]];
    }
    const now = new Date();
    return gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  };

  const initial = getInitialJalali();
  const [viewYear, setViewYear] = useState(initial[0]);
  const [viewMonth, setViewMonth] = useState(initial[1]);
  const [selectedDay, setSelectedDay] = useState(initial[2]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const daysInMonth = getDaysInJalaliMonth(viewYear, viewMonth);

  // Get the weekday of the first day of the Jalali month
  // Jalali week starts on Saturday (index 0)
  const firstDayWeekday = () => {
    const [gy, gm, gd] = jalaliToGregorian(viewYear, viewMonth, 1);
    const d = new Date(gy, gm - 1, gd);
    // JS: 0=Sunday, 6=Saturday
    // Persian: 0=Saturday, 6=Friday
    return (d.getDay() + 1) % 7;
  };

  const firstWeekday = firstDayWeekday();

  const handleSelect = (day: number) => {
    setSelectedDay(day);
    const jalaliStr = `${toPersianDigits(viewYear)}/${toPersianDigits(viewMonth).padStart(2, '۰')}/${toPersianDigits(day).padStart(2, '۰')}`;
    onChange(jalaliStr);
    setOpen(false);
  };

  const prevMonth = () => {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear(viewYear - 1);
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const nextMonth = () => {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear(viewYear + 1);
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  // Build calendar grid
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const todayJalali = gregorianToJalali(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate());

  return (
    <div className="relative" ref={ref}>
      <div className="relative">
        <input
          type="text"
          className="input pl-10"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
        />
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="absolute left-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"
        >
          <Calendar className="w-4 h-4" />
        </button>
      </div>

      {open && (
        <div className="absolute z-50 mt-1 bg-white border border-slate-200 rounded-xl shadow-lg p-3 w-72 animate-fadeIn">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <button onClick={prevMonth} className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600">
              <span className="text-sm">›</span>
            </button>
            <span className="text-sm font-bold text-slate-800">
              {PERSIAN_MONTH_NAMES[viewMonth - 1]} {toPersianDigits(viewYear)}
            </span>
            <button onClick={nextMonth} className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600">
              <span className="text-sm">‹</span>
            </button>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {PERSIAN_WEEKDAYS.map((day, i) => (
              <div key={i} className="text-center text-[10px] text-slate-400 font-medium py-1">
                {day.slice(0, 2)}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, i) => {
              if (day === null) return <div key={i} />;
              const isToday = day === todayJalali[2] && viewMonth === todayJalali[1] && viewYear === todayJalali[0];
              const isSelected = day === selectedDay;
              return (
                <button
                  key={i}
                  onClick={() => handleSelect(day)}
                  className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                    isSelected
                      ? 'bg-slate-800 text-white'
                      : isToday
                      ? 'bg-blue-50 text-blue-600 border border-blue-200'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {toPersianDigits(day)}
                </button>
              );
            })}
          </div>

          {/* Today button */}
          <button
            onClick={() => {
              const [jy, jm, jd] = todayJalali;
              setViewYear(jy);
              setViewMonth(jm);
              setSelectedDay(jd);
              handleSelect(jd);
            }}
            className="w-full mt-2 py-1.5 text-xs text-blue-600 hover:bg-blue-50 rounded-lg font-medium"
          >
            امروز
          </button>
        </div>
      )}
    </div>
  );
}
