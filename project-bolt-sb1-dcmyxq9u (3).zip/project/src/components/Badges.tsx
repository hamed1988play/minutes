import {
  MINUTES_STATUS,
  DECISION_STATUS,
  PRIORITY,
  INVITE_STATUS,
  ATTENDANCE_STATUS,
  OBSTACLE_TYPES,
  RESULT_TYPES,
} from '../lib/constants';
import type {
  MinutesStatus,
  DecisionStatus,
  Priority,
  InviteStatus,
  AttendanceStatus,
  ObstacleType,
  ResultType,
} from '../lib/types';

export function MinutesStatusBadge({ status }: { status: MinutesStatus }) {
  const s = MINUTES_STATUS[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`}></span>
      {s.label}
    </span>
  );
}

export function DecisionStatusBadge({ status }: { status: DecisionStatus }) {
  const s = DECISION_STATUS[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`}></span>
      {s.label}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  const p = PRIORITY[priority];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${p.bg} ${p.text}`}>
      {p.label}
    </span>
  );
}

export function InviteStatusBadge({ status }: { status: InviteStatus }) {
  const s = INVITE_STATUS[status];
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${s.color}`}>
      <span>{s.icon}</span>
      {s.label}
    </span>
  );
}

export function AttendanceBadge({ status }: { status: AttendanceStatus }) {
  const s = ATTENDANCE_STATUS[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`}></span>
      {s.label}
    </span>
  );
}

export function ObstacleTypeBadge({ type }: { type: ObstacleType }) {
  const t = OBSTACLE_TYPES[type];
  return (
    <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-600">
      <span>{t.icon}</span>
      {t.label}
    </span>
  );
}

export function ResultTypeBadge({ type }: { type: ResultType }) {
  const r = RESULT_TYPES[type];
  return (
    <span className={`text-xs font-medium ${r.color}`}>{r.label}</span>
  );
}
