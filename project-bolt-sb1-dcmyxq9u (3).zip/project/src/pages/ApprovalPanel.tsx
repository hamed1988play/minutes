import { useState, useEffect, useCallback } from 'react';
import {
  CheckCircle,
  XCircle,
  Eye,
  MessageSquare,
  Search,
  RefreshCw,
  Inbox,
  AlertCircle,
  FileText,
  Calendar,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { logMinutesEvent } from '../lib/eventLogger';
import type { Minutes, Decision, Profile } from '../lib/types';
import { MinutesStatusBadge } from '../components/Badges';
import Modal from '../components/Modal';
import { CURRENT_USER_ID } from '../lib/constants';

interface ApprovalPanelProps {
  onView: (id: string) => void;
}

interface ApprovalItem extends Minutes {
  creator_name: string;
  decision_count: number;
}

export default function ApprovalPanel({ onView }: ApprovalPanelProps) {
  const [items, setItems] = useState<ApprovalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusTab, setStatusTab] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [approvalModal, setApprovalModal] = useState<ApprovalItem | null>(null);
  const [decisionComments, setDecisionComments] = useState<Record<string, string>>({});
  const [generalComment, setGeneralComment] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchItems = useCallback(async () => {
    setLoading(true);
    const { data: mins } = await supabase
      .from('minutes')
      .select('*')
      .in('status', ['pending', 'approved', 'rejected'])
      .order('created_at', { ascending: false });

    if (!mins) {
      setLoading(false);
      return;
    }

    const creatorIds = Array.from(new Set((mins as Minutes[]).map((m) => m.created_by)));
    const { data: profs } = await supabase
      .from('profiles')
      .select('user_id, name')
      .in('user_id', creatorIds);
    const profMap = new Map<string, string>();
    (profs as Profile[] | null)?.forEach((p) => profMap.set(p.user_id, p.name));

    const { data: decs } = await supabase
      .from('decisions')
      .select('minutes_id');
    const decCounts = new Map<string, number>();
    (decs as { minutes_id: string }[] | null)?.forEach((d) => {
      decCounts.set(d.minutes_id, (decCounts.get(d.minutes_id) || 0) + 1);
    });

    const enriched: ApprovalItem[] = (mins as Minutes[]).map((m) => ({
      ...m,
      creator_name: profMap.get(m.created_by) || 'نامشخص',
      decision_count: decCounts.get(m.id) || 0,
    }));

    setItems(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const filtered = items.filter((m) => {
    if (statusTab !== 'all' && m.status !== statusTab) return false;
    if (search) {
      const q = search.toLowerCase();
      return m.title.toLowerCase().includes(q) || m.creator_name.toLowerCase().includes(q);
    }
    return true;
  });

  const stats = {
    pending: items.filter((m) => m.status === 'pending').length,
    approved: items.filter((m) => m.status === 'approved').length,
    rejected: items.filter((m) => m.status === 'rejected').length,
  };

  const handleApprove = async () => {
    if (!approvalModal) return;
    const reviewData = {
      action: 'approved',
      general_comment: generalComment,
      decision_comments: decisionComments,
      reviewed_at: new Date().toISOString(),
      reviewer_id: CURRENT_USER_ID,
    };
    await supabase
      .from('minutes')
      .update({
        status: 'approved',
        approved_at: new Date().toISOString(),
        metadata: { ...((approvalModal as unknown as Record<string, unknown>).metadata as Record<string, unknown> || {}), reviews: [reviewData] },
      })
      .eq('id', approvalModal.id);
    showToast('صورتجلسه تأیید شد');
    await logMinutesEvent(approvalModal.id, 'approved', 'تأیید صورتجلسه', generalComment || 'صورتجلسه تأیید شد');
    setApprovalModal(null);
    setGeneralComment('');
    setDecisionComments({});
    fetchItems();
  };

  const handleReject = async () => {
    if (!approvalModal) return;
    const reviewData = {
      action: 'rejected',
      general_comment: generalComment,
      decision_comments: decisionComments,
      reviewed_at: new Date().toISOString(),
      reviewer_id: CURRENT_USER_ID,
    };
    await supabase
      .from('minutes')
      .update({
        status: 'rejected',
        metadata: { ...((approvalModal as unknown as Record<string, unknown>).metadata as Record<string, unknown> || {}), reviews: [reviewData] },
      })
      .eq('id', approvalModal.id);
    showToast('صورتجلسه رد شد');
    await logMinutesEvent(approvalModal.id, 'rejected', 'رد صورتجلسه', generalComment || 'صورتجلسه رد شد');
    setApprovalModal(null);
    setGeneralComment('');
    setDecisionComments({});
    fetchItems();
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('fa-IR');
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-4">
      {/* Toast */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg bg-green-600 text-white text-sm font-medium animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            {toast}
          </div>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-800">کارتابل تأیید صورتجلسات</h1>
        <p className="text-sm text-slate-500 mt-0.5">تأیید و بررسی صورتجلسات ارسال‌شده</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="card p-4">
          <div className="flex items-center gap-2 text-yellow-600 mb-1">
            <AlertCircle className="w-4 h-4" />
            <span className="text-xs font-medium">در انتظار</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.pending}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-green-600 mb-1">
            <CheckCircle className="w-4 h-4" />
            <span className="text-xs font-medium">تأییدشده</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.approved}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <XCircle className="w-4 h-4" />
            <span className="text-xs font-medium">ردشده</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.rejected}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو در عنوان..."
              className="input pr-10"
            />
          </div>
          <button onClick={fetchItems} className="btn-secondary">
            <RefreshCw className="w-4 h-4" />
            بروزرسانی
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'all', label: 'همه' },
            { key: 'pending', label: 'در انتظار' },
            { key: 'approved', label: 'تأییدشده' },
            { key: 'rejected', label: 'ردشده' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setStatusTab(tab.key as typeof statusTab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                statusTab === tab.key ? 'tab-active' : 'tab-inactive bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-6 h-6 text-slate-400 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 flex flex-col items-center text-center">
          <Inbox className="w-12 h-12 text-slate-300 mb-3" />
          <p className="text-sm text-slate-500">موردی برای تأیید وجود ندارد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {filtered.map((m) => (
            <div key={m.id} className="card p-4 hover:shadow-md transition-shadow animate-fadeIn">
              <div className="flex flex-col gap-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5 text-slate-600" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">{m.title}</h3>
                      <div className="flex flex-wrap items-center gap-x-3 mt-1 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {formatDate(m.snapshot_date)}
                        </span>
                        <span>ارسال‌کننده: {m.creator_name}</span>
                        <span>{m.decision_count} مصوبه</span>
                      </div>
                    </div>
                  </div>
                  <MinutesStatusBadge status={m.status} />
                </div>
                <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                  {m.status === 'pending' && (
                    <>
                      <button
                        onClick={() => setApprovalModal(m)}
                        className="btn-ghost text-xs text-green-600 hover:bg-green-50"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        تأیید
                      </button>
                      <button
                        onClick={() => setApprovalModal(m)}
                        className="btn-ghost text-xs text-red-600 hover:bg-red-50"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        رد
                      </button>
                      <button
                        onClick={() => setApprovalModal(m)}
                        className="btn-ghost text-xs"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        نظر
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => onView(m.id)}
                    className="btn-ghost text-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    مشاهده
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Approval modal */}
      {approvalModal && (
        <ApprovalModal
          item={approvalModal}
          onClose={() => {
            setApprovalModal(null);
            setGeneralComment('');
            setDecisionComments({});
          }}
          onApprove={handleApprove}
          onReject={handleReject}
          decisionComments={decisionComments}
          setDecisionComments={setDecisionComments}
          generalComment={generalComment}
          setGeneralComment={setGeneralComment}
        />
      )}
    </div>
  );
}

function ApprovalModal({
  item,
  onClose,
  onApprove,
  onReject,
  decisionComments,
  setDecisionComments,
  generalComment,
  setGeneralComment,
}: {
  item: ApprovalItem;
  onClose: () => void;
  onApprove: () => void;
  onReject: () => void;
  decisionComments: Record<string, string>;
  setDecisionComments: (fn: (prev: Record<string, string>) => Record<string, string>) => void;
  generalComment: string;
  setGeneralComment: (v: string) => void;
}) {
  const [decisions, setDecisions] = useState<Decision[]>([]);

  useEffect(() => {
    supabase
      .from('decisions')
      .select('*')
      .eq('minutes_id', item.id)
      .order('number')
      .then(({ data }) => setDecisions((data as Decision[]) || []));
  }, [item.id]);

  return (
    <Modal open={true} onClose={onClose} title="تأیید صورتجلسه" size="lg">
      <div className="space-y-4">
        <div className="bg-slate-50 rounded-lg p-4">
          <h3 className="text-sm font-bold text-slate-800">{item.title}</h3>
          <p className="text-xs text-slate-500 mt-1">
            تاریخ جلسه: {new Date(item.snapshot_date).toLocaleDateString('fa-IR')} | ارسال‌کننده: {item.creator_name}
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-slate-700 mb-2">بررسی دقیق مصوبات</h4>
          {decisions.length > 0 ? (
            <div className="space-y-2">
              {decisions.map((d) => (
                <div key={d.id} className="border border-slate-200 rounded-lg p-3">
                  <div className="flex items-start gap-2 mb-2">
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">بند {d.number}</span>
                    <p className="text-sm font-medium text-slate-800">{d.title}</p>
                  </div>
                  <p className="text-xs text-slate-600 mb-2">{d.content}</p>
                  <input
                    type="text"
                    placeholder="نظر شما درباره این مصوبه..."
                    value={decisionComments[d.id] || ''}
                    onChange={(e) =>
                      setDecisionComments((prev) => ({ ...prev, [d.id]: e.target.value }))
                    }
                    className="input text-xs"
                  />
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400">مصوبه‌ای ثبت نشده است</p>
          )}
        </div>

        <div>
          <label className="label">نظر کلی شما</label>
          <textarea
            className="input"
            rows={3}
            value={generalComment}
            onChange={(e) => setGeneralComment(e.target.value)}
            placeholder="نظر کلی درباره صورتجلسه..."
          />
        </div>

        {/* Review history */}
        {(() => {
          const meta = (item as unknown as Record<string, unknown>).metadata as Record<string, unknown> | null;
          const reviews = (meta?.reviews as Array<Record<string, unknown>>) || [];
          if (reviews.length === 0) return null;
          return (
            <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
              <h4 className="text-sm font-semibold text-slate-700 mb-2">تاریخچه نظرات</h4>
              <div className="space-y-2">
                {reviews.map((r, idx) => (
                  <div key={idx} className="text-xs border-r-2 border-slate-300 pr-2 py-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`font-medium ${r.action === 'approved' ? 'text-green-600' : 'text-red-600'}`}>
                        {r.action === 'approved' ? 'تأیید شده' : 'رد شده'}
                      </span>
                      <span className="text-slate-400">
                        {r.reviewed_at ? new Date(r.reviewed_at as string).toLocaleDateString('fa-IR') : ''}
                      </span>
                    </div>
                    {r.general_comment ? (
                      <p className="text-slate-600">{r.general_comment as string}</p>
                    ) : (
                      <p className="text-slate-400 italic">بدون نظر</p>
                    )}
                    {Boolean(r.decision_comments && Object.keys(r.decision_comments as Record<string, unknown>).length > 0) && (
                      <div className="mt-1 space-y-0.5">
                        {Object.entries(r.decision_comments as Record<string, string>).map(([decId, comment]) => {
                          const dec = decisions.find((d) => d.id === decId);
                          return (
                            <div key={decId} className="text-slate-500">
                              <span className="font-medium">بند {dec?.number || '?'}:</span> {comment}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        <div className="flex gap-3 justify-end pt-2">
          <button onClick={onClose} className="btn-secondary">انصراف</button>
          <button onClick={onReject} className="btn-danger">
            <XCircle className="w-4 h-4" />
            رد
          </button>
          <button onClick={onApprove} className="btn-success">
            <CheckCircle className="w-4 h-4" />
            تأیید
          </button>
        </div>
      </div>
    </Modal>
  );
}
