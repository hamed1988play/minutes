import { useState, useEffect, useCallback } from 'react';
import {
  Search,
  RefreshCw,
  FileText,
  FileDown,
  Printer,
  Filter,
  CheckSquare,
  Square,
  BarChart3,
  Eye,
  EyeOff,
  Layers,
  Calendar,
  Users,
  Inbox,
  X,
  CheckCircle,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPersianDate } from '../lib/persianCalendar';
import type { Decision, DecisionStatus, Priority, Profile, OrgUnit } from '../lib/types';
import { DECISION_STATUS, PRIORITY } from '../lib/constants';
import { DecisionStatusBadge, PriorityBadge } from '../components/Badges';
import ProgressBar from '../components/ProgressBar';

interface ReportDecision extends Decision {
  minutes_title: string;
  owner_profile: Profile | null;
  owner_unit: OrgUnit | null;
  followup_count: number;
  obstacle_count: number;
}

type ColumnKey =
  | 'number'
  | 'title'
  | 'content'
  | 'status'
  | 'priority'
  | 'progress'
  | 'deadline'
  | 'owner'
  | 'unit'
  | 'minutes_title'
  | 'followups'
  | 'obstacles'
  | 'created_at';

const ALL_COLUMNS: { key: ColumnKey; label: string; default: boolean }[] = [
  { key: 'number', label: 'شماره بند', default: true },
  { key: 'title', label: 'عنوان مصوبه', default: true },
  { key: 'content', label: 'متن مصوبه', default: true },
  { key: 'status', label: 'وضعیت', default: true },
  { key: 'priority', label: 'اولویت', default: true },
  { key: 'progress', label: 'درصد پیشرفت', default: true },
  { key: 'deadline', label: 'مهلت اجرا', default: true },
  { key: 'owner', label: 'مسئول اجرا', default: true },
  { key: 'unit', label: 'واحد مسئول', default: false },
  { key: 'minutes_title', label: 'صورتجلسه', default: true },
  { key: 'followups', label: 'تعداد پیگیری', default: false },
  { key: 'obstacles', label: 'تعداد موانع', default: false },
  { key: 'created_at', label: 'تاریخ ثبت', default: false },
];

export default function ReportsPage() {
  const [allDecisions, setAllDecisions] = useState<ReportDecision[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<DecisionStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'all'>('all');
  const [ownerFilter, setOwnerFilter] = useState<string>('all');
  const [minutesFilter, setMinutesFilter] = useState<string>('all');
  const [columns, setColumns] = useState<Set<ColumnKey>>(new Set(ALL_COLUMNS.filter((c) => c.default).map((c) => c.key)));
  const [showColumnPicker, setShowColumnPicker] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [minutesList, setMinutesList] = useState<{ id: string; title: string }[]>([]);

  const fetchData = useCallback(async () => {
    setLoading(true);

    const { data: decs } = await supabase.from('decisions').select('*').order('created_at', { ascending: false });
    const { data: profs } = await supabase.from('profiles').select('*');
    const { data: mins } = await supabase.from('minutes').select('id, title').is('deleted_at', null).order('created_at', { ascending: false });
    const { data: uts } = await supabase.from('org_units').select('*');
    const { data: followups } = await supabase.from('decision_followups').select('decision_id');
    const { data: obstacles } = await supabase.from('decision_obstacles').select('decision_id');

    const profMap = new Map<string, Profile>();
    (profs as Profile[] | null)?.forEach((p) => profMap.set(p.user_id, p));
    setProfiles((profs as Profile[]) || []);

    const unitMap = new Map<string, OrgUnit>();
    (uts as OrgUnit[] | null)?.forEach((u) => unitMap.set(u.id, u));

    setMinutesList((mins as { id: string; title: string }[]) || []);

    const minMap = new Map<string, string>();
    (mins as { id: string; title: string }[] | null)?.forEach((m) => minMap.set(m.id, m.title));

    const followupCounts = new Map<string, number>();
    (followups as { decision_id: string }[] | null)?.forEach((f) => {
      followupCounts.set(f.decision_id, (followupCounts.get(f.decision_id) || 0) + 1);
    });

    const obstacleCounts = new Map<string, number>();
    (obstacles as { decision_id: string }[] | null)?.forEach((o) => {
      obstacleCounts.set(o.decision_id, (obstacleCounts.get(o.decision_id) || 0) + 1);
    });

    const enriched: ReportDecision[] = ((decs as Decision[]) || []).map((d) => ({
      ...d,
      minutes_title: minMap.get(d.minutes_id) || 'نامشخص',
      owner_profile: d.owner_user_id ? profMap.get(d.owner_user_id) || null : null,
      owner_unit: d.owner_unit_id ? unitMap.get(d.owner_unit_id) || null : null,
      followup_count: followupCounts.get(d.id) || 0,
      obstacle_count: obstacleCounts.get(d.id) || 0,
    }));

    setAllDecisions(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Filtered list based on search + filters
  const filtered = allDecisions.filter((d) => {
    if (statusFilter !== 'all' && d.status !== statusFilter) return false;
    if (priorityFilter !== 'all' && d.priority !== priorityFilter) return false;
    if (ownerFilter !== 'all' && d.owner_user_id !== ownerFilter) return false;
    if (minutesFilter !== 'all' && d.minutes_id !== minutesFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return d.title.toLowerCase().includes(q) || d.content.toLowerCase().includes(q);
    }
    return true;
  });

  const selectedDecisions = allDecisions.filter((d) => selectedIds.has(d.id));

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const selectAllFiltered = () => {
    const next = new Set(selectedIds);
    filtered.forEach((d) => next.add(d.id));
    setSelectedIds(next);
  };

  const deselectAll = () => setSelectedIds(new Set());

  const toggleColumn = (key: ColumnKey) => {
    const next = new Set(columns);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    setColumns(next);
  };

  const formatDate = (dateStr: string | null) => formatPersianDate(dateStr);

  const getCellValue = (d: ReportDecision, key: ColumnKey): string => {
    switch (key) {
      case 'number': return d.number;
      case 'title': return d.title;
      case 'content': return d.content;
      case 'status': return DECISION_STATUS[d.status].label;
      case 'priority': return PRIORITY[d.priority].label;
      case 'progress': return `${d.progress}%`;
      case 'deadline': return formatDate(d.deadline);
      case 'owner': return d.owner_name || d.owner_profile?.name || '-';
      case 'unit': return d.owner_unit?.name || '-';
      case 'minutes_title': return d.minutes_title;
      case 'followups': return String(d.followup_count);
      case 'obstacles': return String(d.obstacle_count);
      case 'created_at': return formatDate(d.created_at);
      default: return '';
    }
  };

  const activeColumns = ALL_COLUMNS.filter((c) => columns.has(c.key));

  // ===== Export functions =====
  const exportWord = () => {
    const rows = selectedDecisions.length > 0 ? selectedDecisions : filtered;
    if (rows.length === 0) return;

    const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset="utf-8"><title>گزارش مصوبات</title></head><body dir="rtl" style="font-family:Tahoma,Arial,sans-serif;">`;
    let html = `<h2 style="text-align:center;">گزارش مصوبات</h2>`;
    html += `<p style="text-align:center;font-size:12px;color:#666;">تاریخ گزارش: ${formatPersianDate(new Date().toISOString())}</p>`;
    html += `<table border="1" cellpadding="6" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:11px;">`;
    html += `<thead><tr style="background:#f0f0f0;">`;
    activeColumns.forEach((c) => { html += `<th style="border:1px solid #999;">${c.label}</th>`; });
    html += `</tr></thead><tbody>`;
    rows.forEach((d) => {
      html += `<tr>`;
      activeColumns.forEach((c) => {
        html += `<td style="border:1px solid #999;">${getCellValue(d, c.key)}</td>`;
      });
      html += `</tr>`;
    });
    html += `</tbody></table>`;
    html += `<p style="font-size:11px;color:#999;margin-top:10px;">تعداد رکوردها: ${rows.length}</p>`;
    const footer = '</body></html>';
    const blob = new Blob(['\ufeff', header + html + footer], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `گزارش-مصوبات-${Date.now()}.doc`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportExcel = () => {
    const rows = selectedDecisions.length > 0 ? selectedDecisions : filtered;
    if (rows.length === 0) return;

    const headers = activeColumns.map((c) => c.label).join('\t');
    const lines = rows.map((d) =>
      activeColumns.map((c) => getCellValue(d, c.key).replace(/\t/g, ' ')).join('\t')
    );
    const csv = '\ufeff' + [headers, ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `گزارش-مصوبات-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportPrint = () => {
    const rows = selectedDecisions.length > 0 ? selectedDecisions : filtered;
    if (rows.length === 0) return;

    const html = `<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8"><title>گزارش مصوبات</title>
    <style>
      body{font-family:Tahoma,Arial,sans-serif;padding:20px;max-width:1000px;margin:0 auto;}
      h2{text-align:center;margin-bottom:5px;}
      .meta{text-align:center;font-size:12px;color:#666;margin-bottom:15px;}
      table{width:100%;border-collapse:collapse;font-size:11px;}
      th{background:#f0f0f0;border:1px solid #999;padding:6px;}
      td{border:1px solid #999;padding:6px;}
      tr:nth-child(even){background:#fafafa;}
      .footer{margin-top:10px;font-size:11px;color:#999;}
      @media print{.no-print{display:none;}}
    </style></head><body>
    <h2>گزارش مصوبات</h2>
    <p class="meta">تاریخ گزارش: ${formatPersianDate(new Date().toISOString())} — تعداد رکوردها: ${rows.length}</p>
    <table><thead><tr>${activeColumns.map((c) => `<th>${c.label}</th>`).join('')}</tr></thead>
    <tbody>${rows.map((d) => `<tr>${activeColumns.map((c) => `<td>${getCellValue(d, c.key)}</td>`).join('')}</tr>`).join('')}</tbody></table>
    <p class="footer">تعداد رکوردها: ${rows.length}</p>
    </body></html>`;
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-800">گزارش‌ساز مصوبات</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            انتخاب مصوبات دلخواه، فیلتر، تعیین ستون‌های گزارش و خروجی Word / Excel / چاپ
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchData} className="btn-secondary">
            <RefreshCw className="w-4 h-4" />
            بروزرسانی
          </button>
        </div>
      </div>

      {/* Step 1: Filters */}
      <div className="card p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          <Filter className="w-4 h-4 text-slate-500" />
          مرحله ۱ — فیلتر و جستجوی مصوبات
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو در عنوان و متن..."
              className="input pr-10"
            />
          </div>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as DecisionStatus | 'all')} className="input">
            <option value="all">همه وضعیت‌ها</option>
            {Object.entries(DECISION_STATUS).map(([key, val]) => (
              <option key={key} value={key}>{val.label}</option>
            ))}
          </select>
          <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value as Priority | 'all')} className="input">
            <option value="all">همه اولویت‌ها</option>
            {Object.entries(PRIORITY).map(([key, val]) => (
              <option key={key} value={key}>{val.label}</option>
            ))}
          </select>
          <select value={ownerFilter} onChange={(e) => setOwnerFilter(e.target.value)} className="input">
            <option value="all">همه مسئولین</option>
            {profiles.filter((p) => p.user_id).map((p) => (
              <option key={p.user_id} value={p.user_id}>{p.name}</option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <select value={minutesFilter} onChange={(e) => setMinutesFilter(e.target.value)} className="input">
            <option value="all">همه صورتجلسات</option>
            {minutesList.map((m) => (
              <option key={m.id} value={m.id}>{m.title}</option>
            ))}
          </select>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <BarChart3 className="w-4 h-4" />
            نتایج فیلتر: {filtered.length} مصوبه
          </div>
        </div>
      </div>

      {/* Step 2: Select decisions */}
      <div className="card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Layers className="w-4 h-4 text-slate-500" />
            مرحله ۲ — انتخاب مصوبات برای گزارش
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">
              {selectedIds.size > 0
                ? `${selectedIds.size} مصوبه انتخاب شده`
                : 'در صورت عدم انتخاب، همه نتایج فیلتر در گزارش قرار می‌گیرند'}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={selectAllFiltered} className="btn-ghost text-xs text-blue-600 hover:bg-blue-50">
            <CheckSquare className="w-3.5 h-3.5" />
            انتخاب همه نتایج فیلتر
          </button>
          <button onClick={deselectAll} className="btn-ghost text-xs text-slate-500 hover:bg-slate-100">
            <Square className="w-3.5 h-3.5" />
            لغو همه انتخاب‌ها
          </button>
        </div>

        {/* Decision list */}
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="w-5 h-5 text-slate-400 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center py-8 text-center">
            <Inbox className="w-10 h-10 text-slate-300 mb-2" />
            <p className="text-sm text-slate-500">مصوبه‌ای با این فیلترها یافت نشد</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {filtered.map((d) => {
              const isSelected = selectedIds.has(d.id);
              return (
                <div
                  key={d.id}
                  className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected ? 'border-slate-800 bg-slate-50' : 'border-slate-200 hover:bg-slate-50'
                  }`}
                  onClick={() => toggleSelect(d.id)}
                >
                  {isSelected ? (
                    <CheckSquare className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-300 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">بند {d.number}</span>
                      <h4 className="text-sm font-semibold text-slate-800 truncate">{d.title}</h4>
                    </div>
                    <p className="text-xs text-slate-500 line-clamp-2">{d.content}</p>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs text-slate-500">
                      <span className="flex items-center gap-1"><FileText className="w-3 h-3" />{d.minutes_title}</span>
                      <span className="flex items-center gap-1"><Users className="w-3 h-3" />{d.owner_name || '-'}</span>
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{formatDate(d.deadline)}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <PriorityBadge priority={d.priority} />
                    <DecisionStatusBadge status={d.status} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Step 3: Column selection */}
      <div className="card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Layers className="w-4 h-4 text-slate-500" />
            مرحله ۳ — انتخاب ستون‌های گزارش
          </div>
          <button
            onClick={() => setShowColumnPicker(!showColumnPicker)}
            className="btn-ghost text-xs"
          >
            {showColumnPicker ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            {showColumnPicker ? 'بستن' : 'مدیریت ستون‌ها'}
          </button>
        </div>

        {showColumnPicker && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 animate-fadeIn">
            {ALL_COLUMNS.map((col) => {
              const checked = columns.has(col.key);
              return (
                <button
                  key={col.key}
                  onClick={() => toggleColumn(col.key)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                    checked ? 'border-slate-800 bg-slate-800 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {checked ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
                  {col.label}
                </button>
              );
            })}
          </div>
        )}

        {!showColumnPicker && (
          <div className="flex flex-wrap gap-1.5">
            {activeColumns.map((c) => (
              <span key={c.key} className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
                {c.label}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Step 4: Export */}
      <div className="card p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          <FileDown className="w-4 h-4 text-slate-500" />
          مرحله ۴ — تولید و خروجی گزارش
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={exportWord} className="btn-primary text-sm">
            <FileDown className="w-4 h-4" />
            خروجی Word
          </button>
          <button onClick={exportExcel} className="btn-secondary text-sm">
            <FileDown className="w-4 h-4" />
            خروجی Excel (CSV)
          </button>
          <button onClick={exportPrint} className="btn-secondary text-sm">
            <Printer className="w-4 h-4" />
            چاپ / PDF
          </button>
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="btn-ghost text-sm"
          >
            {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showPreview ? 'بستن پیش‌نمایش' : 'پیش‌نمایش گزارش'}
          </button>
        </div>

        {/* Summary */}
        <div className="flex items-center gap-4 text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span className="flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
            رکوردهای گزارش: {selectedDecisions.length > 0 ? selectedDecisions.length : filtered.length}
          </span>
          <span>ستون‌ها: {activeColumns.length}</span>
        </div>
      </div>

      {/* Preview */}
      {showPreview && (
        <div className="card p-4 animate-fadeIn">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-800">پیش‌نمایش گزارش</h3>
            <button onClick={() => setShowPreview(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border border-slate-200">
              <thead>
                <tr className="bg-slate-100">
                  {activeColumns.map((c) => (
                    <th key={c.key} className="border border-slate-200 px-2 py-1.5 text-right font-semibold text-slate-700">
                      {c.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(selectedDecisions.length > 0 ? selectedDecisions : filtered).slice(0, 20).map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50">
                    {activeColumns.map((c) => (
                      <td key={c.key} className="border border-slate-200 px-2 py-1.5 text-slate-600">
                        {c.key === 'progress' ? (
                          <div className="flex items-center gap-1">
                            <ProgressBar value={d.progress} size="sm" />
                            <span className="text-xs">{d.progress}%</span>
                          </div>
                        ) : c.key === 'status' ? (
                          <DecisionStatusBadge status={d.status} />
                        ) : c.key === 'priority' ? (
                          <PriorityBadge priority={d.priority} />
                        ) : (
                          getCellValue(d, c.key)
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {(selectedDecisions.length > 0 ? selectedDecisions : filtered).length > 20 && (
              <p className="text-xs text-slate-400 text-center mt-2">
                نمایش ۲۰ رکورد اول از {(selectedDecisions.length > 0 ? selectedDecisions.length : filtered.length)} رکورد — برای مشاهده کامل، خروجی دریافت کنید
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
