import { useState, useEffect, useCallback } from 'react';
import {
  Search,
  RefreshCw,
  Inbox,
  Eye,
  ClipboardList,
  AlertTriangle,
  CheckCircle,
  Clock,
  Upload,
  AlertCircle,
  Plus,
  ChevronDown,
  ChevronUp,
  FileText,
  Calendar,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Decision, DecisionStatus, DecisionFollowup, DecisionObstacle, ProgressStatus, ObstacleType } from '../lib/types';
import { CURRENT_USER_ID } from '../lib/constants';
import { formatPersianDate } from '../lib/persianCalendar';
import { PROGRESS_STATUS, OBSTACLE_TYPES } from '../lib/constants';
import { DecisionStatusBadge, PriorityBadge, ObstacleTypeBadge } from '../components/Badges';
import ProgressBar from '../components/ProgressBar';
import Modal from '../components/Modal';
import PersianDatePicker from '../components/PersianDatePicker';

interface MyDecisionsProps {
  onView: (minutesId: string) => void;
}

interface MyDecision extends Decision {
  minutes_title: string;
  followups: DecisionFollowup[];
  obstacles: DecisionObstacle[];
}

interface MinutesGroup {
  minutesId: string;
  minutesTitle: string;
  snapshotDate: string;
  decisions: MyDecision[];
}

export default function MyDecisions({ onView }: MyDecisionsProps) {
  const [decisions, setDecisions] = useState<MyDecision[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusTab, setStatusTab] = useState<DecisionStatus | 'all'>('all');
  const [toast, setToast] = useState<string | null>(null);
  const [completeModal, setCompleteModal] = useState<MyDecision | null>(null);
  const [progressModal, setProgressModal] = useState<MyDecision | null>(null);
  const [obstacleModal, setObstacleModal] = useState<MyDecision | null>(null);
  const [expandedMinutes, setExpandedMinutes] = useState<Set<string>>(new Set());
  const [expandedDecision, setExpandedDecision] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchDecisions = useCallback(async () => {
    setLoading(true);
    const { data: decs } = await supabase
      .from('decisions')
      .select('*')
      .or(`owner_user_id.eq.${CURRENT_USER_ID}`)
      .order('created_at', { ascending: false });

    if (!decs) {
      setLoading(false);
      return;
    }

    const minutesIds = Array.from(new Set((decs as Decision[]).map((d) => d.minutes_id)));
    const { data: mins } = await supabase.from('minutes').select('id, title, snapshot_date').in('id', minutesIds);
    const minMap = new Map<string, { title: string; snapshot_date: string }>();
    (mins as { id: string; title: string; snapshot_date: string }[] | null)?.forEach((m) =>
      minMap.set(m.id, { title: m.title, snapshot_date: m.snapshot_date })
    );

    const decisionIds = (decs as Decision[]).map((d) => d.id);
    const { data: followups } = await supabase
      .from('decision_followups')
      .select('*')
      .in('decision_id', decisionIds)
      .order('created_at', { ascending: false });
    const followupMap = new Map<string, DecisionFollowup[]>();
    (followups as DecisionFollowup[] | null)?.forEach((f) => {
      if (!followupMap.has(f.decision_id)) followupMap.set(f.decision_id, []);
      followupMap.get(f.decision_id)!.push(f);
    });

    const { data: obstacles } = await supabase
      .from('decision_obstacles')
      .select('*')
      .in('decision_id', decisionIds)
      .order('created_at', { ascending: false });
    const obstacleMap = new Map<string, DecisionObstacle[]>();
    (obstacles as DecisionObstacle[] | null)?.forEach((o) => {
      if (!obstacleMap.has(o.decision_id)) obstacleMap.set(o.decision_id, []);
      obstacleMap.get(o.decision_id)!.push(o);
    });

    const enriched: MyDecision[] = (decs as Decision[]).map((d) => ({
      ...d,
      minutes_title: minMap.get(d.minutes_id)?.title || 'نامشخص',
      followups: followupMap.get(d.id) || [],
      obstacles: obstacleMap.get(d.id) || [],
    }));

    setDecisions(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchDecisions();
  }, [fetchDecisions]);

  // Group decisions by minutes
  const groups: MinutesGroup[] = (() => {
    const filtered = decisions.filter((d) => {
      if (statusTab !== 'all' && d.status !== statusTab) return false;
      if (search) {
        const q = search.toLowerCase();
        return d.title.toLowerCase().includes(q) || d.content.toLowerCase().includes(q) || d.minutes_title.toLowerCase().includes(q);
      }
      return true;
    });

    const map = new Map<string, MinutesGroup>();
    filtered.forEach((d) => {
      if (!map.has(d.minutes_id)) {
        map.set(d.minutes_id, {
          minutesId: d.minutes_id,
          minutesTitle: d.minutes_title,
          snapshotDate: d.created_at,
          decisions: [],
        });
      }
      map.get(d.minutes_id)!.decisions.push(d);
    });

    return Array.from(map.values());
  })();

  const stats = {
    in_progress: decisions.filter((d) => d.status === 'in_progress').length,
    completed: decisions.filter((d) => d.status === 'completed').length,
    overdue: decisions.filter((d) => d.status === 'overdue').length,
    pending: decisions.filter((d) => d.status === 'pending').length,
  };

  const handleRequestComplete = async () => {
    if (!completeModal) return;
    await supabase
      .from('decisions')
      .update({ progress: 100, progress_status: 'completed', status: 'completed', completed_at: new Date().toISOString() })
      .eq('id', completeModal.id);
    showToast('درخواست تکمیل ثبت شد');
    setCompleteModal(null);
    fetchDecisions();
  };

  const formatDate = (dateStr: string | null) => formatPersianDate(dateStr);

  const toggleMinutes = (id: string) => {
    setExpandedMinutes((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const STATUS_TABS: { key: DecisionStatus | 'all'; label: string; icon: typeof Clock }[] = [
    { key: 'all', label: 'همه', icon: ClipboardList },
    { key: 'in_progress', label: 'در حال انجام', icon: Clock },
    { key: 'pending', label: 'در انتظار', icon: AlertCircle },
    { key: 'completed', label: 'تکمیل‌شده', icon: CheckCircle },
    { key: 'overdue', label: 'معوق', icon: AlertTriangle },
  ];

  return (
    <div className="space-y-4">
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg bg-green-600 text-white text-sm font-medium animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            {toast}
          </div>
        </div>
      )}

      <div>
        <h1 className="text-xl font-bold text-slate-800">کارتابل مصوبات من</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          مصوبات محوله به شما — به تفکیک صورتجلسه
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-4">
          <div className="flex items-center gap-2 text-blue-600 mb-1">
            <Clock className="w-4 h-4" />
            <span className="text-xs font-medium">در حال انجام</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.in_progress}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-green-600 mb-1">
            <CheckCircle className="w-4 h-4" />
            <span className="text-xs font-medium">تکمیل‌شده</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.completed}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-xs font-medium">معوق</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.overdue}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-yellow-600 mb-1">
            <AlertCircle className="w-4 h-4" />
            <span className="text-xs font-medium">در انتظار</span>
          </div>
          <p className="text-2xl font-bold text-slate-800">{stats.pending}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو در مصوبات یا صورتجلسه..."
              className="input pr-10"
            />
          </div>
          <button onClick={fetchDecisions} className="btn-secondary">
            <RefreshCw className="w-4 h-4" />
            بروزرسانی
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {STATUS_TABS.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.key}
                onClick={() => setStatusTab(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  statusTab === tab.key ? 'tab-active' : 'tab-inactive bg-slate-50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* List grouped by minutes */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-6 h-6 text-slate-400 animate-spin" />
        </div>
      ) : groups.length === 0 ? (
        <div className="card p-12 flex flex-col items-center text-center">
          <Inbox className="w-12 h-12 text-slate-300 mb-3" />
          <p className="text-sm text-slate-500">مصوبه‌ای یافت نشد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {groups.map((group) => {
            const isExpanded = expandedMinutes.has(group.minutesId);
            const groupStats = {
              total: group.decisions.length,
              completed: group.decisions.filter((d) => d.status === 'completed').length,
              inProgress: group.decisions.filter((d) => d.status === 'in_progress').length,
              overdue: group.decisions.filter((d) => d.status === 'overdue').length,
              avgProgress: group.decisions.length > 0
                ? Math.round(group.decisions.reduce((s, d) => s + (d.progress || 0), 0) / group.decisions.length)
                : 0,
            };

            return (
              <div key={group.minutesId} className="card overflow-hidden animate-fadeIn">
                {/* Minutes header - clickable */}
                <button
                  onClick={() => toggleMinutes(group.minutesId)}
                  className="w-full flex items-center justify-between gap-3 p-4 hover:bg-slate-50 transition-colors text-right"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5 text-slate-600" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">{group.minutesTitle}</h3>
                      <div className="flex items-center gap-3 mt-0.5 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(group.snapshotDate)}
                        </span>
                        <span>{groupStats.total} مصوبه</span>
                        {groupStats.completed > 0 && <span className="text-green-600">{groupStats.completed} تکمیل‌شده</span>}
                        {groupStats.overdue > 0 && <span className="text-red-600">{groupStats.overdue} معوق</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="hidden sm:block w-24">
                      <ProgressBar value={groupStats.avgProgress} size="sm" />
                    </div>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </button>

                {/* Decisions list - collapsible */}
                {isExpanded && (
                  <div className="border-t border-slate-200 bg-slate-50 p-3 space-y-3 animate-fadeIn">
                    {group.decisions.map((d) => (
                      <div key={d.id} className="bg-white border border-slate-200 rounded-lg p-4">
                        <div className="flex flex-col gap-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3">
                              <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded">بند {d.number}</span>
                              <div>
                                <h3 className="text-sm font-bold text-slate-800">{d.title}</h3>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <PriorityBadge priority={d.priority} />
                              <DecisionStatusBadge status={d.status} />
                            </div>
                          </div>

                          <p className="text-xs text-slate-600 leading-relaxed">{d.content}</p>

                          <div className="grid grid-cols-2 gap-4 text-xs text-slate-500">
                            <div>مهلت: {formatDate(d.deadline)}</div>
                            <div>مسئول: {d.owner_name}</div>
                          </div>

                          <div className="pt-2">
                            <ProgressBar value={d.progress} size="sm" />
                          </div>

                          {/* Badges for followups/obstacles */}
                          <div className="flex gap-2">
                            {d.followups.length > 0 && (
                              <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full flex items-center gap-1">
                                <ClipboardList className="w-3 h-3" />
                                {d.followups.length} پیگیری
                              </span>
                            )}
                            {d.obstacles.length > 0 && (
                              <span className="text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded-full flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                {d.obstacles.length} مانع
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                            {(d.status === 'in_progress' || d.status === 'overdue' || d.status === 'pending') && (
                              <>
                                <button
                                  onClick={() => setProgressModal(d)}
                                  className="btn-ghost text-xs text-blue-600 hover:bg-blue-50"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                  ثبت پیشرفت
                                </button>
                                <button
                                  onClick={() => setObstacleModal(d)}
                                  className="btn-ghost text-xs text-orange-600 hover:bg-orange-50"
                                >
                                  <AlertTriangle className="w-3.5 h-3.5" />
                                  ثبت مانع
                                </button>
                                <button
                                  onClick={() => setCompleteModal(d)}
                                  className="btn-ghost text-xs text-green-600 hover:bg-green-50"
                                >
                                  <Upload className="w-3.5 h-3.5" />
                                  درخواست تکمیل
                                </button>
                              </>
                            )}
                            <button
                              onClick={() => setExpandedDecision(expandedDecision === d.id ? null : d.id)}
                              className="btn-ghost text-xs"
                            >
                              {expandedDecision === d.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                              {expandedDecision === d.id ? 'بستن جزئیات' : 'جزئیات'}
                            </button>
                            <button
                              onClick={() => onView(d.minutes_id)}
                              className="btn-ghost text-xs"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              مشاهده صورتجلسه
                            </button>
                          </div>

                          {/* Expanded details */}
                          {expandedDecision === d.id && (
                            <div className="border-t border-slate-200 bg-slate-50 p-3 space-y-3 animate-fadeIn rounded-lg">
                              <div>
                                <h4 className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                                  <ClipboardList className="w-3.5 h-3.5" />
                                  تاریخچه پیگیری‌ها ({d.followups.length})
                                </h4>
                                {d.followups.length > 0 ? (
                                  <div className="space-y-2">
                                    {d.followups.map((f) => (
                                      <div key={f.id} className="bg-white border border-slate-200 rounded-lg p-2.5">
                                        <div className="flex items-center justify-between mb-1">
                                          <span className="text-xs text-slate-500">{formatDate(f.created_at)}</span>
                                          <span className="text-xs font-medium text-blue-600">{f.progress}%</span>
                                        </div>
                                        <p className="text-xs text-slate-700">{f.content}</p>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <p className="text-xs text-slate-400">پیگیری‌ای ثبت نشده است</p>
                                )}
                              </div>

                              <div>
                                <h4 className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                                  <AlertTriangle className="w-3.5 h-3.5" />
                                  موانع ({d.obstacles.length})
                                </h4>
                                {d.obstacles.length > 0 ? (
                                  <div className="space-y-2">
                                    {d.obstacles.map((o) => (
                                      <div key={o.id} className="bg-white border border-slate-200 rounded-lg p-2.5">
                                        <div className="flex items-start justify-between gap-2 mb-1">
                                          <p className="text-xs font-medium text-slate-800">{o.title}</p>
                                          <ObstacleTypeBadge type={o.obstacle_type} />
                                        </div>
                                        <p className="text-xs text-slate-600">{o.description}</p>
                                        <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-500">
                                          {o.due_date && <span>مهلت رفع: {formatDate(o.due_date)}</span>}
                                          <span className={`px-1.5 py-0.5 rounded-full ${
                                            o.status === 'open' ? 'bg-red-100 text-red-700' :
                                            o.status === 'in_progress' ? 'bg-yellow-100 text-yellow-700' :
                                            'bg-green-100 text-green-700'
                                          }`}>
                                            {o.status === 'open' ? 'باز' : o.status === 'in_progress' ? 'در حال رفع' : 'رفع شده'}
                                          </span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <p className="text-xs text-slate-400">مانعی ثبت نشده است</p>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Complete modal */}
      {completeModal && (
        <Modal open={true} onClose={() => setCompleteModal(null)} title="درخواست تأیید تکمیل" size="sm">
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-sm font-bold text-slate-800">{completeModal.title}</p>
              <p className="text-xs text-slate-500 mt-1">بند {completeModal.number}</p>
            </div>
            <p className="text-sm text-slate-600">
              با تأیید این درخواست، مصوبه به وضعیت «تکمیل‌شده» تغییر می‌کند و برای تأیید نهایی به ناظر ارسال می‌شود.
            </p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setCompleteModal(null)} className="btn-secondary">انصراف</button>
              <button onClick={handleRequestComplete} className="btn-success">
                <CheckCircle className="w-4 h-4" />
                تأیید تکمیل
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Progress modal */}
      {progressModal && (
        <ProgressFormModal
          decision={progressModal}
          onClose={() => setProgressModal(null)}
          onSaved={() => {
            showToast('پیشرفت ثبت شد');
            setProgressModal(null);
            fetchDecisions();
          }}
        />
      )}

      {/* Obstacle modal */}
      {obstacleModal && (
        <ObstacleFormModal
          decision={obstacleModal}
          onClose={() => setObstacleModal(null)}
          onSaved={() => {
            showToast('مانع ثبت شد');
            setObstacleModal(null);
            fetchDecisions();
          }}
        />
      )}
    </div>
  );
}

// ===== Progress Form Modal =====
function ProgressFormModal({
  decision,
  onClose,
  onSaved,
}: {
  decision: MyDecision;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [content, setContent] = useState('');
  const [progress, setProgress] = useState(decision.progress);
  const [progressStatus, setProgressStatus] = useState<ProgressStatus>(decision.progress_status as ProgressStatus);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!content.trim()) return;
    setSaving(true);
    await supabase.from('decision_followups').insert({
      decision_id: decision.id,
      user_id: CURRENT_USER_ID,
      content,
      progress,
      status: 'in_progress',
    });

    await supabase
      .from('decisions')
      .update({
        progress,
        progress_status: progressStatus,
        status: progress >= 100 ? 'completed' : 'in_progress',
        updated_at: new Date().toISOString(),
      })
      .eq('id', decision.id);

    setSaving(false);
    onSaved();
  };

  return (
    <Modal open={true} onClose={onClose} title="ثبت پیشرفت مرحله‌ای" size="md">
      <div className="space-y-4">
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-sm font-bold text-slate-800">{decision.title}</p>
          <p className="text-xs text-slate-500 mt-1">بند {decision.number} — مسئول: {decision.owner_name}</p>
        </div>

        <div>
          <label className="label">شرح پیشرفت کار</label>
          <textarea
            className="input"
            rows={4}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="شرح پیشرفت کار در این مرحله..."
          />
        </div>

        <div>
          <label className="label">درصد پیشرفت: {progress}%</label>
          <input
            type="range"
            min="0"
            max="100"
            value={progress}
            onChange={(e) => setProgress(Number(e.target.value))}
            className="w-full accent-slate-700"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>۰%</span>
            <span>۵۰%</span>
            <span>۱۰۰%</span>
          </div>
        </div>

        <div>
          <label className="label">وضعیت پیشرفت</label>
          <select
            className="input"
            value={progressStatus}
            onChange={(e) => setProgressStatus(e.target.value as ProgressStatus)}
          >
            {Object.entries(PROGRESS_STATUS).map(([key, val]) => (
              <option key={key} value={key}>{val.label}</option>
            ))}
          </select>
        </div>

        <div className="flex gap-3 justify-end">
          <button onClick={onClose} className="btn-secondary">انصراف</button>
          <button onClick={handleSubmit} disabled={saving} className="btn-primary">
            <CheckCircle className="w-4 h-4" />
            ثبت پیشرفت
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ===== Obstacle Form Modal =====
function ObstacleFormModal({
  decision,
  onClose,
  onSaved,
}: {
  decision: MyDecision;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [obstacleType, setObstacleType] = useState<ObstacleType>('budget');
  const [dueDate, setDueDate] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!title.trim() || !description.trim()) return;
    setSaving(true);
    await supabase.from('decision_obstacles').insert({
      decision_id: decision.id,
      title,
      description,
      obstacle_type: obstacleType,
      status: 'open',
      due_date: dueDate || null,
      created_by: CURRENT_USER_ID,
    });
    setSaving(false);
    onSaved();
  };

  return (
    <Modal open={true} onClose={onClose} title="ثبت مانع در اجرای مصوبه" size="md">
      <div className="space-y-4">
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-sm font-bold text-slate-800">{decision.title}</p>
          <p className="text-xs text-slate-500 mt-1">بند {decision.number}</p>
        </div>

        <div>
          <label className="label">عنوان مانع</label>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان مانع..." />
        </div>

        <div>
          <label className="label">توضیحات</label>
          <textarea className="input" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="شرح مانع..." />
        </div>

        <div>
          <label className="label">نوع مانع</label>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(OBSTACLE_TYPES).map(([key, val]) => (
              <button
                key={key}
                onClick={() => setObstacleType(key as ObstacleType)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                  obstacleType === key ? 'border-slate-800 bg-slate-800 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span>{val.icon}</span>
                {val.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label">مهلت رفع (تقویم شمسی)</label>
          <PersianDatePicker value={dueDate} onChange={setDueDate} />
        </div>

        <div className="flex gap-3 justify-end">
          <button onClick={onClose} className="btn-secondary">انصراف</button>
          <button onClick={handleSubmit} disabled={saving} className="btn-primary">
            <AlertTriangle className="w-4 h-4" />
            ثبت مانع
          </button>
        </div>
      </div>
    </Modal>
  );
}
