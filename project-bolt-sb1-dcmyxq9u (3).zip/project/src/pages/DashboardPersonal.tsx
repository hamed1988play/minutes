import { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Eye,
  Bell,
  TrendingUp,
  ClipboardList,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Minutes, Decision, DecisionStatus } from '../lib/types';
import { CURRENT_USER_ID, CURRENT_USER_NAME, DECISION_STATUS } from '../lib/constants';
import { MinutesStatusBadge } from '../components/Badges';

interface DashboardPersonalProps {
  onView: (id: string) => void;
}

interface DashboardData {
  myMinutes: Minutes[];
  myDecisions: Decision[];
  decisionStatusCounts: Record<string, number>;
  overdueCount: number;
  upcomingDeadlineCount: number;
  pendingApprovalCount: number;
  completedAwaitingApproval: number;
}

export default function DashboardPersonal({ onView }: DashboardPersonalProps) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = useCallback(async () => {
    const { data: mins } = await supabase
      .from('minutes')
      .select('*')
      .eq('created_by', CURRENT_USER_ID)
      .is('deleted_at', null)
      .order('created_at', { ascending: false })
      .limit(5);

    const { data: decs } = await supabase
      .from('decisions')
      .select('*')
      .or(`owner_user_id.eq.${CURRENT_USER_ID}`)
      .order('created_at', { ascending: false });

    const myDecisions = (decs as Decision[]) || [];
    const myMinutes = (mins as Minutes[]) || [];

    const decisionStatusCounts: Record<string, number> = {};
    myDecisions.forEach((d) => {
      decisionStatusCounts[d.status] = (decisionStatusCounts[d.status] || 0) + 1;
    });

    const now = new Date();
    const threeDaysLater = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

    const overdueCount = myDecisions.filter((d) => {
      if (d.status === 'overdue') return true;
      if (d.deadline && d.status !== 'completed' && new Date(d.deadline) < now) return true;
      return false;
    }).length;

    const upcomingDeadlineCount = myDecisions.filter((d) => {
      if (!d.deadline || d.status === 'completed') return false;
      const dl = new Date(d.deadline);
      return dl >= now && dl <= threeDaysLater;
    }).length;

    const pendingApprovalCount = myMinutes.filter((m) => m.status === 'pending').length;
    const completedAwaitingApproval = myDecisions.filter((d) => d.status === 'completed' && d.progress >= 100).length;

    setData({
      myMinutes,
      myDecisions,
      decisionStatusCounts,
      overdueCount,
      upcomingDeadlineCount,
      pendingApprovalCount,
      completedAwaitingApproval,
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  const totalDecisions = data.myDecisions.length;
  const inProgressCount = data.decisionStatusCounts['in_progress'] || 0;
  const completedCount = data.decisionStatusCounts['completed'] || 0;
  const totalMeetings = data.myMinutes.length;

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('fa-IR');
    } catch {
      return dateStr;
    }
  };

  // Bar chart data
  const statusOrder: DecisionStatus[] = ['pending', 'in_progress', 'completed', 'overdue', 'rejected', 'cancelled'];
  const maxCount = Math.max(...statusOrder.map((s) => data.decisionStatusCounts[s] || 0), 1);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-800">داشبورد شخصی - {CURRENT_USER_NAME}</h1>
        <p className="text-sm text-slate-500 mt-0.5">خلاصه وضعیت جلسات و مصوبات</p>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard
          icon={Calendar}
          label="جلسات من"
          value={totalMeetings}
          color="text-blue-600"
          bg="bg-blue-50"
        />
        <StatCard
          icon={ClipboardList}
          label="مصوبات"
          value={totalDecisions}
          color="text-slate-700"
          bg="bg-slate-100"
        />
        <StatCard
          icon={Clock}
          label="در حال انجام"
          value={inProgressCount}
          color="text-blue-600"
          bg="bg-blue-50"
        />
        <StatCard
          icon={CheckCircle}
          label="تکمیل‌شده"
          value={completedCount}
          color="text-green-600"
          bg="bg-green-50"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent meetings */}
        <div className="card p-5">
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-500" />
            آخرین جلسات من
          </h3>
          {data.myMinutes.length > 0 ? (
            <div className="space-y-2">
              {data.myMinutes.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between gap-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
                  onClick={() => onView(m.id)}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">{m.title}</p>
                      <p className="text-xs text-slate-500">{formatDate(m.snapshot_date)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <MinutesStatusBadge status={m.status} />
                    <Eye className="w-4 h-4 text-slate-300" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400 text-center py-6">جلسه‌ای ثبت نشده است</p>
          )}
        </div>

        {/* Decision status chart */}
        <div className="card p-5">
          <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-slate-500" />
            وضعیت مصوبات من
          </h3>
          <div className="space-y-3">
            {statusOrder.map((status) => {
              const count = data.decisionStatusCounts[status] || 0;
              const widthPct = (count / maxCount) * 100;
              const s = DECISION_STATUS[status];

              return (
                <div key={status} className="flex items-center gap-3">
                  <span className="text-xs font-medium text-slate-600 w-20 shrink-0">{s.label}</span>
                  <div className="flex-1 h-6 bg-slate-100 rounded-lg overflow-hidden">
                    <div
                      className={`h-full ${s.dot} rounded-lg transition-all duration-500`}
                      style={{ width: `${Math.max(widthPct, count > 0 ? 8 : 0)}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-700 w-8 text-left">{count}</span>
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between text-xs text-slate-500">
            <span>مجموع:</span>
            <span className="font-bold text-slate-700">{totalDecisions} مصوبه</span>
          </div>
        </div>
      </div>

      {/* Alerts */}
      <div className="card p-5">
        <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <Bell className="w-4 h-4 text-slate-500" />
          هشدارها و اعلان‌ها
        </h3>
        <div className="space-y-2">
          {data.overdueCount > 0 && (
            <AlertItem
              color="red"
              icon={AlertTriangle}
              text={`${data.overdueCount} مصوبه معوق نیاز به اقدام فوری دارند`}
            />
          )}
          {data.upcomingDeadlineCount > 0 && (
            <AlertItem
              color="yellow"
              icon={Clock}
              text={`${data.upcomingDeadlineCount} مصوبه در ۳ روز آینده مهلت دارند`}
            />
          )}
          {data.pendingApprovalCount > 0 && (
            <AlertItem
              color="blue"
              icon={FileText}
              text={`${data.pendingApprovalCount} صورتجلسه در انتظار تأیید شما هستند`}
            />
          )}
          {data.completedAwaitingApproval > 0 && (
            <AlertItem
              color="green"
              icon={CheckCircle}
              text={`${data.completedAwaitingApproval} مصوبه تکمیل‌شده نیاز به تأیید نهایی دارد`}
            />
          )}
          {data.overdueCount === 0 && data.upcomingDeadlineCount === 0 && data.pendingApprovalCount === 0 && data.completedAwaitingApproval === 0 && (
            <p className="text-sm text-slate-400 text-center py-4">هشداری وجود ندارد</p>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
  bg,
}: {
  icon: typeof Calendar;
  label: string;
  value: number;
  color: string;
  bg: string;
}) {
  return (
    <div className="card p-4">
      <div className={`w-10 h-10 rounded-lg ${bg} flex items-center justify-center mb-2`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      <p className="text-xs text-slate-500 mt-0.5">{label}</p>
    </div>
  );
}

function AlertItem({
  color,
  icon: Icon,
  text,
}: {
  color: 'red' | 'yellow' | 'blue' | 'green';
  icon: typeof Bell;
  text: string;
}) {
  const colors = {
    red: 'bg-red-50 border-red-200 text-red-700',
    yellow: 'bg-yellow-50 border-yellow-200 text-yellow-700',
    blue: 'bg-blue-50 border-blue-200 text-blue-700',
    green: 'bg-green-50 border-green-200 text-green-700',
  };
  return (
    <div className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border ${colors[color]} text-sm`}>
      <Icon className="w-4 h-4 shrink-0" />
      <span>{text}</span>
    </div>
  );
}
