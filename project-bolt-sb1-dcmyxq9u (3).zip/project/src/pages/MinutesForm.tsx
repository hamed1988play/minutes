import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Save,
  Send,
  X,
  Calendar,
  Users,
  ClipboardList,
  CheckSquare,
  Paperclip,
  Plus,
  Trash2,
  AlertCircle,
  CheckCircle,
  Pencil,
  Upload,
  FileText,
  Download,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { logMinutesEvent } from '../lib/eventLogger';
import PersianDatePicker from '../components/PersianDatePicker';
import { formatPersianDate } from '../lib/persianCalendar';
import type {
  Minutes,
  MinutesParticipant,
  MinutesAttachment,
  Decision,
  MeetingAgendaItem,
  Meeting,
  Profile,
  OrgUnit,
  InviteStatus,
  AttendanceStatus,
  Priority,
} from '../lib/types';
import {
  INVITE_STATUS,
  ATTENDANCE_STATUS,
  PRIORITY,
  CURRENT_USER_ID,
} from '../lib/constants';
import { PriorityBadge } from '../components/Badges';
import Modal from '../components/Modal';

interface MinutesFormProps {
  minutesId: string | null;
  onSaved: () => void;
  onCancel: () => void;
}

type TabKey = 'info' | 'participants' | 'agenda' | 'decisions' | 'attachments';

const TABS: { key: TabKey; label: string; icon: typeof Calendar }[] = [
  { key: 'info', label: 'اطلاعات جلسه', icon: Calendar },
  { key: 'participants', label: 'شرکت‌کنندگان', icon: Users },
  { key: 'agenda', label: 'دستور جلسه', icon: ClipboardList },
  { key: 'decisions', label: 'مصوبات', icon: CheckSquare },
  { key: 'attachments', label: 'پیوست‌ها', icon: Paperclip },
];

export default function MinutesForm({ minutesId, onSaved, onCancel }: MinutesFormProps) {
  const [activeTab, setActiveTab] = useState<TabKey>('info');
  const [loading, setLoading] = useState(!!minutesId);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  const [minutes, setMinutes] = useState<Minutes | null>(null);
  const [participants, setParticipants] = useState<MinutesParticipant[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [agendaItems, setAgendaItems] = useState<MeetingAgendaItem[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [orgUnits, setOrgUnits] = useState<OrgUnit[]>([]);

  // New minutes: meeting selection
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [selectedMeetingId, setSelectedMeetingId] = useState<string>('');
  const [showMeetingSelect, setShowMeetingSelect] = useState(!minutesId);

  const [decisionModalOpen, setDecisionModalOpen] = useState(false);
  const [editingDecision, setEditingDecision] = useState<Decision | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchMeetings = useCallback(async () => {
    const { data: mtgs } = await supabase.from('meetings').select('*').order('meeting_date', { ascending: false });
    setMeetings((mtgs as Meeting[]) || []);
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);

    const { data: profs } = await supabase.from('profiles').select('*');
    setProfiles((profs as Profile[]) || []);

    const { data: units } = await supabase.from('org_units').select('*');
    setOrgUnits((units as OrgUnit[]) || []);

    if (minutesId) {
      const { data: min } = await supabase.from('minutes').select('*').eq('id', minutesId).maybeSingle();
      if (min) {
        setMinutes(min as Minutes);

        const { data: agenda } = await supabase
          .from('meeting_agenda_items')
          .select('*')
          .eq('meeting_id', (min as Minutes).meeting_id)
          .order('number');
        setAgendaItems((agenda as MeetingAgendaItem[]) || []);

        const { data: parts } = await supabase
          .from('minutes_participants')
          .select('*')
          .eq('minutes_id', minutesId)
          .order('created_at');
        setParticipants((parts as MinutesParticipant[]) || []);

        const { data: decs } = await supabase
          .from('decisions')
          .select('*')
          .eq('minutes_id', minutesId)
          .order('number');
        setDecisions((decs as Decision[]) || []);
      }
    }
    setLoading(false);
  }, [minutesId]);

  useEffect(() => {
    if (minutesId) {
      fetchData();
    } else {
      fetchMeetings();
      // Load profiles and orgUnits for new minutes too
      supabase.from('profiles').select('*').then(({ data }) => setProfiles((data as Profile[]) || []));
      supabase.from('org_units').select('*').then(({ data }) => setOrgUnits((data as OrgUnit[]) || []));
      setLoading(false);
    }
  }, [minutesId, fetchData, fetchMeetings]);

  // ===== Create new minutes from meeting =====
  const handleCreateFromMeeting = async () => {
    if (!selectedMeetingId) {
      showToast('لطفاً یک جلسه انتخاب کنید', 'error');
      return;
    }

    const meeting = meetings.find((m) => m.id === selectedMeetingId);
    if (!meeting) return;

    setSaving(true);
    const { data: existing } = await supabase
      .from('minutes')
      .select('id')
      .eq('meeting_id', selectedMeetingId)
      .is('deleted_at', null)
      .maybeSingle();

    if (existing) {
      showToast('برای این جلسه قبلاً صورتجلسه ثبت شده است', 'error');
      setSaving(false);
      return;
    }

    const { data: newMin, error } = await supabase
      .from('minutes')
      .insert({
        meeting_id: selectedMeetingId,
        snapshot_title: meeting.title,
        snapshot_date: meeting.meeting_date,
        snapshot_time: meeting.meeting_time,
        snapshot_location: meeting.location,
        snapshot_representative: meeting.representative,
        snapshot_phone: meeting.phone,
        snapshot_notes: meeting.notes,
        snapshot_organizer_id: meeting.organizer_id,
        title: `صورتجلسه: ${meeting.title}`,
        status: 'draft',
        approval_type: 'systemic',
        version: 1,
        created_by: CURRENT_USER_ID,
      })
      .select('*')
      .single();

    if (error) {
      showToast('خطا در ایجاد صورتجلسه', 'error');
      setSaving(false);
      return;
    }

    // Fetch agenda items for the meeting
    const { data: agenda } = await supabase
      .from('meeting_agenda_items')
      .select('*')
      .eq('meeting_id', selectedMeetingId)
      .order('number');
    setAgendaItems((agenda as MeetingAgendaItem[]) || []);

    setMinutes(newMin as Minutes);
    setShowMeetingSelect(false);
    setSaving(false);
    await logMinutesEvent((newMin as Minutes).id, 'created', 'ایجاد صورتجلسه', `صورتجلسه «${meeting.title}» ایجاد شد`);
    showToast('صورتجلسه جدید ایجاد شد');
  };

  // ===== Save handlers =====
  const handleSaveDraft = async () => {
    if (!minutes) return;
    setSaving(true);
    const { error } = await supabase
      .from('minutes')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', minutes.id);
    setSaving(false);
    if (error) showToast('خطا در ذخیره', 'error');
    else {
      await logMinutesEvent(minutes.id, 'updated', 'ذخیره پیش‌نویس', 'پیش‌نویس صورتجلسه بروزرسانی شد');
      showToast('پیش‌نویس ذخیره شد');
    }
  };

  const handleSendForApproval = async () => {
    if (!minutes) return;
    setSaving(true);
    const { error } = await supabase
      .from('minutes')
      .update({ status: 'pending', updated_at: new Date().toISOString() })
      .eq('id', minutes.id);
    setSaving(false);
    if (error) showToast('خطا در ارسال', 'error');
    else {
      await logMinutesEvent(minutes.id, 'sent_for_approval', 'ارسال برای تأیید', 'صورتجلسه برای تأیید ارسال شد');
      showToast('صورتجلسه برای تأیید ارسال شد');
      onSaved();
    }
  };

  // ===== Participant handlers =====
  const updateParticipant = async (id: string, updates: Partial<MinutesParticipant>) => {
    const { error } = await supabase
      .from('minutes_participants')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) showToast('خطا در بروزرسانی', 'error');
    else setParticipants((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
  };

  const handleAddParticipant = async (name: string, position: string, isExternal: boolean) => {
    if (!minutes || !name.trim()) return;
    const { data, error } = await supabase
      .from('minutes_participants')
      .insert({
        minutes_id: minutes.id,
        name: name.trim(),
        position: position.trim() || null,
        is_external: isExternal,
        invite_status: 'invited',
        attendance_status: 'unknown',
        approval_status: 'pending',
      })
      .select('*')
      .single();
    if (error) showToast('خطا در افزودن شرکت‌کننده', 'error');
    else {
      setParticipants((prev) => [...prev, data as MinutesParticipant]);
      await logMinutesEvent(minutes.id, 'participant_added', 'افزودن شرکت‌کننده', `${name}${position ? ` (${position})` : ''}${isExternal ? ' — خارج سازمان' : ''}`);
    }
  };

  const handleDeleteParticipant = async (id: string) => {
    const p = participants.find((x) => x.id === id);
    const { error } = await supabase.from('minutes_participants').delete().eq('id', id);
    if (error) showToast('خطا در حذف', 'error');
    else {
      setParticipants((prev) => prev.filter((p) => p.id !== id));
      if (p) await logMinutesEvent(minutes!.id, 'participant_removed', 'حذف شرکت‌کننده', p.name);
    }
  };

  const handleUpdateMinutes = async (updates: Partial<Minutes>) => {
    if (!minutes) return;
    const changes: string[] = [];
    if (updates.secretary_id !== undefined && updates.secretary_id !== minutes.secretary_id) {
      const secName = participants.find((p) => p.user_id === updates.secretary_id)?.name || '';
      changes.push(`دبیر: ${secName || 'حذف شد'}`);
    }
    if (updates.chairperson_id !== undefined && updates.chairperson_id !== minutes.chairperson_id) {
      const chName = participants.find((p) => p.user_id === updates.chairperson_id)?.name || '';
      changes.push(`رئیس: ${chName || 'حذف شد'}`);
    }
    const { error } = await supabase.from('minutes').update(updates).eq('id', minutes.id);
    if (error) showToast('خطا در بروزرسانی', 'error');
    else {
      setMinutes((prev) => (prev ? { ...prev, ...updates } : prev));
      if (changes.length > 0) {
        await logMinutesEvent(minutes.id, 'updated', 'تغییر مسئولیت‌های جلسه', changes.join('، '));
      }
    }
  };

  // ===== Decision handlers =====
  const handleSaveDecision = async (decision: Partial<Decision>) => {
    if (!minutes) return;

    if (editingDecision) {
      const existing = decisions.find((d) => d.id === editingDecision.id);
      const changes: string[] = [];
      if (existing && decision.title && decision.title !== existing.title) changes.push(`عنوان: «${existing.title}» → «${decision.title}»`);
      if (existing && decision.content && decision.content !== existing.content) changes.push('متن مصوبه ویرایش شد');
      if (existing && decision.status && decision.status !== existing.status) changes.push(`وضعیت: ${existing.status} → ${decision.status}`);
      if (existing && decision.progress !== undefined && decision.progress !== existing.progress) changes.push(`پیشرفت: ${existing.progress}% → ${decision.progress}%`);
      if (existing && decision.owner_name && decision.owner_name !== existing.owner_name) changes.push(`مسئول: ${existing.owner_name || '-'} → ${decision.owner_name}`);
      if (existing && decision.deadline !== undefined && decision.deadline !== existing.deadline) changes.push(`مهلت: ${formatPersianDate(existing.deadline)} → ${formatPersianDate(decision.deadline)}`);
      const { error } = await supabase
        .from('decisions')
        .update({ ...decision, updated_at: new Date().toISOString() })
        .eq('id', editingDecision.id);
      if (error) showToast('خطا در ویرایش مصوبه', 'error');
      else {
        showToast('مصوبه ویرایش شد');
        setDecisions((prev) => prev.map((d) => (d.id === editingDecision.id ? { ...d, ...decision } as Decision : d)));
        await logMinutesEvent(minutes.id, 'decision_updated', 'ویرایش مصوبه', `بند ${editingDecision.number}: ${changes.join('، ') || 'تغییرات جزئی'}`);
      }
    } else {
      const maxNum = decisions.length + 1;
      const { data, error } = await supabase
        .from('decisions')
        .insert({
          minutes_id: minutes.id,
          number: decision.number || String(maxNum),
          title: decision.title,
          content: decision.content,
          status: 'pending',
          priority: decision.priority || 'medium',
          progress: 0,
          progress_status: 'not_started',
          deadline: decision.deadline,
          owner_user_id: decision.owner_user_id,
          owner_name: decision.owner_name,
          owner_unit_id: decision.owner_unit_id,
          created_by: CURRENT_USER_ID,
        })
        .select('*')
        .single();
      if (error) showToast('خطا در ثبت مصوبه', 'error');
      else {
        showToast('مصوبه ثبت شد');
        setDecisions((prev) => [...prev, data as Decision]);
        await logMinutesEvent(minutes.id, 'decision_added', 'افزودن مصوبه', `بند ${decision.number || maxNum}: ${decision.title}`);
      }
    }
    setDecisionModalOpen(false);
    setEditingDecision(null);
  };

  const handleDeleteDecision = async (id: string) => {
    const d = decisions.find((x) => x.id === id);
    const { error } = await supabase.from('decisions').delete().eq('id', id);
    if (error) showToast('خطا در حذف مصوبه', 'error');
    else {
      showToast('مصوبه حذف شد');
      setDecisions((prev) => prev.filter((d) => d.id !== id));
      if (d) await logMinutesEvent(minutes!.id, 'decision_updated', 'حذف مصوبه', `بند ${d.number}: ${d.title}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  // ===== Meeting selection screen for new minutes =====
  if (showMeetingSelect && !minutes) {
    return (
      <div className="space-y-4">
        {toast && (
          <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg animate-fadeIn ${toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'} text-white text-sm font-medium`}>
            <div className="flex items-center gap-2">
              {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              {toast.msg}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-800">ثبت صورتجلسه جدید</h1>
            <p className="text-sm text-slate-500 mt-0.5">جلسه مورد نظر را انتخاب کنید</p>
          </div>
          <button onClick={onCancel} className="btn-ghost">
            <X className="w-4 h-4" />
            انصراف
          </button>
        </div>

        <div className="card p-6">
          {meetings.length === 0 ? (
            <div className="text-center py-8 text-sm text-slate-400">جلسه‌ای برای انتخاب وجود ندارد</div>
          ) : (
            <div className="space-y-2">
              {meetings.map((m) => (
                <label
                  key={m.id}
                  className={`flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedMeetingId === m.id ? 'border-slate-800 bg-slate-50' : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="meeting"
                    value={m.id}
                    checked={selectedMeetingId === m.id}
                    onChange={(e) => setSelectedMeetingId(e.target.value)}
                    className="accent-slate-800"
                  />
                  <div className="flex-1">
                    <p className="text-sm font-bold text-slate-800">{m.title}</p>
                    <div className="flex flex-wrap gap-x-3 mt-1 text-xs text-slate-500">
                      <span>تاریخ: {formatPersianDate(m.meeting_date)}</span>
                      <span>ساعت: {m.meeting_time || '-'}</span>
                      <span>محل: {m.location || '-'}</span>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="card p-4 flex gap-3 justify-end">
          <button onClick={onCancel} className="btn-secondary">انصراف</button>
          <button onClick={handleCreateFromMeeting} disabled={saving || !selectedMeetingId} className="btn-primary">
            <Plus className="w-4 h-4" />
            ایجاد صورتجلسه
          </button>
        </div>
      </div>
    );
  }

  if (!minutes) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-500">صورتجلسه یافت نشد</p>
        <button onClick={onCancel} className="btn-secondary mt-4">بازگشت</button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {toast && (
        <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg animate-fadeIn ${toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'} text-white text-sm font-medium`}>
          <div className="flex items-center gap-2">
            {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {toast.msg}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-800">{minutes.title}</h1>
          <p className="text-sm text-slate-500 mt-0.5">ثبت و ویرایش صورتجلسه</p>
        </div>
        <button onClick={onCancel} className="btn-ghost">
          <X className="w-4 h-4" />
          انصراف
        </button>
      </div>

      <div className="card p-1.5 flex gap-1 overflow-x-auto">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.key ? 'tab-active' : 'tab-inactive'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="card p-6">
        {activeTab === 'info' && <InfoTab minutes={minutes} />}
        {activeTab === 'participants' && (
          <ParticipantsTab
            participants={participants}
            onUpdate={updateParticipant}
            onAdd={handleAddParticipant}
            onDelete={handleDeleteParticipant}
            minutes={minutes}
            onUpdateMinutes={handleUpdateMinutes}
          />
        )}
        {activeTab === 'agenda' && (
          <AgendaTab
            agendaItems={agendaItems}
            minutesId={minutes.id}
            onChange={fetchData}
            participants={participants}
          />
        )}
        {activeTab === 'decisions' && (
          <DecisionsTab
            decisions={decisions}
            onAdd={() => { setEditingDecision(null); setDecisionModalOpen(true); }}
            onEdit={(d) => { setEditingDecision(d); setDecisionModalOpen(true); }}
            onDelete={handleDeleteDecision}
          />
        )}
        {activeTab === 'attachments' && <AttachmentsTab minutesId={minutes.id} />}
      </div>

      <div className="card p-4 flex gap-3 justify-end">
        <button onClick={onCancel} className="btn-secondary">
          <X className="w-4 h-4" />
          انصراف
        </button>
        <button onClick={handleSaveDraft} disabled={saving} className="btn-secondary">
          <Save className="w-4 h-4" />
          ذخیره پیش‌نویس
        </button>
        <button onClick={handleSendForApproval} disabled={saving} className="btn-primary">
          <Send className="w-4 h-4" />
          ارسال برای تأیید
        </button>
      </div>

      {decisionModalOpen && (
        <DecisionFormModal
          open={decisionModalOpen}
          onClose={() => { setDecisionModalOpen(false); setEditingDecision(null); }}
          onSave={handleSaveDecision}
          decision={editingDecision}
          agendaItems={agendaItems}
          profiles={profiles}
          orgUnits={orgUnits}
          nextNumber={String(decisions.length + 1)}
        />
      )}
    </div>
  );
}

// ===== Tab 1: Info =====
function InfoTab({ minutes }: { minutes: Minutes }) {
  return (
    <div className="space-y-4 max-w-2xl">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2">
        <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
        <p className="text-xs text-blue-700">
          این اطلاعات به‌صورت Snapshot ذخیره می‌شود و تغییرات بعدی جلسه روی آن تأثیری ندارد.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="label">عنوان جلسه</label>
          <input className="input bg-slate-50" defaultValue={minutes.snapshot_title} readOnly />
        </div>
        <div>
          <label className="label">تاریخ جلسه</label>
          <input className="input bg-slate-50" defaultValue={formatPersianDate(minutes.snapshot_date)} readOnly />
        </div>
        <div>
          <label className="label">ساعت جلسه</label>
          <input className="input bg-slate-50" defaultValue={minutes.snapshot_time || ''} readOnly />
        </div>
        <div>
          <label className="label">محل برگزاری</label>
          <input className="input bg-slate-50" defaultValue={minutes.snapshot_location || ''} readOnly />
        </div>
        <div>
          <label className="label">نماینده</label>
          <input className="input bg-slate-50" defaultValue={minutes.snapshot_representative || ''} readOnly />
        </div>
        <div>
          <label className="label">شماره تماس</label>
          <input className="input bg-slate-50" defaultValue={minutes.snapshot_phone || ''} readOnly />
        </div>
        <div className="md:col-span-2">
          <label className="label">یادداشت‌ها</label>
          <textarea className="input bg-slate-50" rows={3} defaultValue={minutes.snapshot_notes || ''} readOnly />
        </div>
      </div>
    </div>
  );
}

// ===== Tab 2: Participants =====
function ParticipantsTab({
  participants,
  onUpdate,
  onAdd,
  onDelete,
  minutes,
  onUpdateMinutes,
}: {
  participants: MinutesParticipant[];
  onUpdate: (id: string, updates: Partial<MinutesParticipant>) => void;
  onAdd: (name: string, position: string, isExternal: boolean) => void;
  onDelete: (id: string) => void;
  minutes: Minutes;
  onUpdateMinutes: (updates: Partial<Minutes>) => void;
}) {
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPosition, setNewPosition] = useState('');
  const [newIsExternal, setNewIsExternal] = useState(false);

  const internal = participants.filter((p) => !p.is_external);
  const external = participants.filter((p) => p.is_external);

  const secretaryOptions = internal.filter((p) => p.user_id);
  const chairpersonOptions = internal.filter((p) => p.user_id);

  const secretaryName = secretaryOptions.find((p) => p.user_id === minutes.secretary_id)?.name || '';
  const chairpersonName = chairpersonOptions.find((p) => p.user_id === minutes.chairperson_id)?.name || '';

  const handleAdd = () => {
    if (!newName.trim()) return;
    onAdd(newName, newPosition, newIsExternal);
    setNewName('');
    setNewPosition('');
    setNewIsExternal(false);
    setAdding(false);
  };

  const renderTable = (list: MinutesParticipant[], isExternal: boolean) => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-200">
            <th className="text-right py-2 px-3 font-medium text-slate-600">نام</th>
            <th className="text-right py-2 px-3 font-medium text-slate-600">{isExternal ? 'شرکت' : 'سمت'}</th>
            <th className="text-right py-2 px-3 font-medium text-slate-600">وضعیت دعوت</th>
            <th className="text-right py-2 px-3 font-medium text-slate-600">حضور</th>
            <th className="text-right py-2 px-3 font-medium text-slate-600">عملیات</th>
          </tr>
        </thead>
        <tbody>
          {list.map((p) => (
            <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="py-2.5 px-3 font-medium text-slate-800">
                <input
                  className="bg-transparent border-0 outline-none font-medium text-slate-800 w-32"
                  value={p.name}
                  onChange={(e) => onUpdate(p.id, { name: e.target.value })}
                />
              </td>
              <td className="py-2.5 px-3 text-slate-600">{isExternal ? p.company : p.position}</td>
              <td className="py-2.5 px-3">
                <select
                  value={p.invite_status}
                  onChange={(e) => onUpdate(p.id, { invite_status: e.target.value as InviteStatus })}
                  className="text-xs bg-transparent border-0 outline-none cursor-pointer"
                >
                  {Object.entries(INVITE_STATUS).map(([key, val]) => (
                    <option key={key} value={key}>{val.icon} {val.label}</option>
                  ))}
                </select>
              </td>
              <td className="py-2.5 px-3">
                <select
                  value={p.attendance_status}
                  onChange={(e) => onUpdate(p.id, { attendance_status: e.target.value as AttendanceStatus })}
                  className="text-xs bg-transparent border-0 outline-none cursor-pointer"
                >
                  {Object.entries(ATTENDANCE_STATUS).map(([key, val]) => (
                    <option key={key} value={key}>{val.label}</option>
                  ))}
                </select>
              </td>
              <td className="py-2.5 px-3">
                <button
                  onClick={() => onDelete(p.id)}
                  className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Secretary & Chairperson selection */}
      <div className="card p-4 bg-slate-50 border-slate-200">
        <h3 className="text-sm font-semibold text-slate-700 mb-3">مسئولیت‌های جلسه</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="label flex items-center gap-1.5">
              <ClipboardList className="w-3.5 h-3.5 text-blue-600" />
              دبیر جلسه (مسئول پیگیری مصوبات)
            </label>
            <select
              className="input"
              value={minutes.secretary_id || ''}
              onChange={(e) => onUpdateMinutes({ secretary_id: e.target.value || null })}
            >
              <option value="">— انتخاب دبیر —</option>
              {secretaryOptions.map((p) => (
                <option key={p.id} value={p.user_id!}>
                  {p.name} {p.position ? `(${p.position})` : ''}
                </option>
              ))}
            </select>
            {secretaryName && (
              <p className="text-xs text-slate-500 mt-1">دبیر فعلی: {secretaryName}</p>
            )}
          </div>
          <div>
            <label className="label flex items-center gap-1.5">
              <CheckSquare className="w-3.5 h-3.5 text-green-600" />
              رئیس جلسه (مسئول تأیید و بستن مصوبات)
            </label>
            <select
              className="input"
              value={minutes.chairperson_id || ''}
              onChange={(e) => onUpdateMinutes({ chairperson_id: e.target.value || null })}
            >
              <option value="">— انتخاب رئیس —</option>
              {chairpersonOptions.map((p) => (
                <option key={p.id} value={p.user_id!}>
                  {p.name} {p.position ? `(${p.position})` : ''}
                </option>
              ))}
            </select>
            {chairpersonName && (
              <p className="text-xs text-slate-500 mt-1">رئیس فعلی: {chairpersonName}</p>
            )}
          </div>
        </div>
      </div>

      {/* Add participant */}
      <div className="flex gap-2">
        <button onClick={() => setAdding(!adding)} className="btn-secondary text-xs">
          <Plus className="w-3.5 h-3.5" />
          افزودن شرکت‌کننده
        </button>
      </div>

      {adding && (
        <div className="card p-4 space-y-3 bg-slate-50">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="label">نام و نام خانوادگی</label>
              <input className="input" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="نام شرکت‌کننده" />
            </div>
            <div>
              <label className="label">سمت / جایگاه</label>
              <input className="input" value={newPosition} onChange={(e) => setNewPosition(e.target.value)} placeholder="سمت" />
            </div>
            <div>
              <label className="label">نوع شرکت‌کننده</label>
              <select className="input" value={newIsExternal ? 'external' : 'internal'} onChange={(e) => setNewIsExternal(e.target.value === 'external')}>
                <option value="internal">داخلی</option>
                <option value="external">خارج سازمان</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setAdding(false)} className="btn-secondary text-xs">انصراف</button>
            <button onClick={handleAdd} className="btn-primary text-xs">ثبت</button>
          </div>
        </div>
      )}

      {internal.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-700 mb-2">شرکت‌کنندگان داخلی ({internal.length} نفر)</h3>
          <div className="card p-0 overflow-hidden">{renderTable(internal, false)}</div>
        </div>
      )}

      {external.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-700 mb-2">افراد خارج سازمان ({external.length} نفر)</h3>
          <div className="card p-0 overflow-hidden">{renderTable(external, true)}</div>
        </div>
      )}

      {participants.length === 0 && !adding && (
        <div className="text-center py-8 text-sm text-slate-400">شرکت‌کننده‌ای ثبت نشده است</div>
      )}
    </div>
  );
}

// ===== Tab 3: Agenda =====
function AgendaTab({
  agendaItems,
  minutesId,
  onChange,
  participants,
}: {
  agendaItems: MeetingAgendaItem[];
  minutesId: string;
  onChange: () => void;
  participants: MinutesParticipant[];
}) {
  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPresenter, setNewPresenter] = useState('');
  const [newDuration, setNewDuration] = useState('');
  const [savingId, setSavingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<Record<string, { title: string; presenter: string; duration: string }>>({});

  const presenterOptions = participants;

  const handleAdd = async () => {
    if (!newTitle.trim()) return;
    const meetingRes = await supabase.from('minutes').select('meeting_id').eq('id', minutesId).single();
    if (!meetingRes.data) return;
    const meetingId = meetingRes.data.meeting_id;
    const nextNum = String(agendaItems.length + 1);
    const { error } = await supabase.from('meeting_agenda_items').insert({
      meeting_id: meetingId,
      number: nextNum,
      title: newTitle,
      presenter: newPresenter || null,
      duration: newDuration || null,
    });
    if (error) {
      console.error(error);
    } else {
      setNewTitle('');
      setNewPresenter('');
      setNewDuration('');
      setAdding(false);
      onChange();
    }
  };

  const handleDelete = async (id: string) => {
    await supabase.from('meeting_agenda_items').delete().eq('id', id);
    onChange();
  };

  const startEdit = (item: MeetingAgendaItem) => {
    setSavingId(item.id);
    setEditValues({
      [item.id]: { title: item.title, presenter: item.presenter || '', duration: item.duration || '' },
    });
  };

  const handleSaveEdit = async (id: string) => {
    const vals = editValues[id];
    if (!vals) return;
    await supabase.from('meeting_agenda_items').update({
      title: vals.title,
      presenter: vals.presenter || null,
      duration: vals.duration || null,
    }).eq('id', id);
    setSavingId(null);
    setEditValues({});
    onChange();
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button onClick={() => setAdding(!adding)} className="btn-primary text-xs">
          <Plus className="w-3.5 h-3.5" />
          افزودن دستور جلسه
        </button>
      </div>

      {adding && (
        <div className="card p-4 space-y-3 bg-slate-50">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="label">عنوان</label>
              <input className="input" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="عنوان آیتم" />
            </div>
            <div>
              <label className="label">ارائه‌دهنده</label>
              <select className="input" value={newPresenter} onChange={(e) => setNewPresenter(e.target.value)}>
                <option value="">— انتخاب —</option>
                {presenterOptions.map((p) => (
                  <option key={p.id} value={p.name}>{p.name}{p.position ? ` (${p.position})` : ''}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">زمان</label>
              <input className="input" value={newDuration} onChange={(e) => setNewDuration(e.target.value)} placeholder="مثلاً ۱۵ دقیقه" />
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setAdding(false)} className="btn-secondary text-xs">انصراف</button>
            <button onClick={handleAdd} className="btn-primary text-xs">ثبت</button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200">
              <th className="text-right py-2 px-3 font-medium text-slate-600 w-12">#</th>
              <th className="text-right py-2 px-3 font-medium text-slate-600">عنوان</th>
              <th className="text-right py-2 px-3 font-medium text-slate-600">ارائه‌دهنده</th>
              <th className="text-right py-2 px-3 font-medium text-slate-600">زمان</th>
              <th className="text-right py-2 px-3 font-medium text-slate-600 w-20">عملیات</th>
            </tr>
          </thead>
          <tbody>
            {agendaItems.map((item) => (
              <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2.5 px-3 text-slate-500">{item.number}</td>
                {savingId === item.id ? (
                  <>
                    <td className="py-2 px-3">
                      <input
                        className="input text-xs"
                        value={editValues[item.id]?.title || ''}
                        onChange={(e) => setEditValues((prev) => ({ ...prev, [item.id]: { ...prev[item.id], title: e.target.value } }))}
                      />
                    </td>
                    <td className="py-2 px-3">
                      <select
                        className="input text-xs"
                        value={editValues[item.id]?.presenter || ''}
                        onChange={(e) => setEditValues((prev) => ({ ...prev, [item.id]: { ...prev[item.id], presenter: e.target.value } }))}
                      >
                        <option value="">— انتخاب —</option>
                        {presenterOptions.map((p) => (
                          <option key={p.id} value={p.name}>{p.name}{p.position ? ` (${p.position})` : ''}</option>
                        ))}
                      </select>
                    </td>
                    <td className="py-2 px-3">
                      <input
                        className="input text-xs"
                        value={editValues[item.id]?.duration || ''}
                        onChange={(e) => setEditValues((prev) => ({ ...prev, [item.id]: { ...prev[item.id], duration: e.target.value } }))}
                      />
                    </td>
                    <td className="py-2 px-3">
                      <div className="flex gap-1">
                        <button onClick={() => handleSaveEdit(item.id)} className="p-1 text-green-600 hover:bg-green-50 rounded">
                          <Save className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setSavingId(null)} className="p-1 text-slate-400 hover:bg-slate-100 rounded">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="py-2.5 px-3 font-medium text-slate-800">{item.title}</td>
                    <td className="py-2.5 px-3 text-slate-600">{item.presenter || '-'}</td>
                    <td className="py-2.5 px-3 text-slate-600">{item.duration || '-'}</td>
                    <td className="py-2.5 px-3">
                      <div className="flex gap-1">
                        <button onClick={() => startEdit(item)} className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded">
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleDelete(item.id)} className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {agendaItems.length === 0 && !adding && (
        <div className="text-center py-8 text-sm text-slate-400">آیتم دستور جلسه‌ای ثبت نشده است</div>
      )}
    </div>
  );
}

// ===== Tab 4: Decisions =====
function DecisionsTab({
  decisions,
  onAdd,
  onEdit,
  onDelete,
}: {
  decisions: Decision[];
  onAdd: () => void;
  onEdit: (d: Decision) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button onClick={onAdd} className="btn-primary text-xs">
          <Plus className="w-3.5 h-3.5" />
          افزودن مصوبه
        </button>
      </div>

      {decisions.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-right py-2 px-3 font-medium text-slate-600 w-12">بند</th>
                <th className="text-right py-2 px-3 font-medium text-slate-600">عنوان</th>
                <th className="text-right py-2 px-3 font-medium text-slate-600">مسئول</th>
                <th className="text-right py-2 px-3 font-medium text-slate-600">اولویت</th>
                <th className="text-right py-2 px-3 font-medium text-slate-600">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {decisions.map((d) => (
                <tr key={d.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2.5 px-3 text-slate-500">{d.number}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{d.title}</td>
                  <td className="py-2.5 px-3 text-slate-600">{d.owner_name}</td>
                  <td className="py-2.5 px-3"><PriorityBadge priority={d.priority} /></td>
                  <td className="py-2.5 px-3">
                    <div className="flex gap-1">
                      <button onClick={() => onEdit(d)} className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <CheckSquare className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => onDelete(d.id)} className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-8 text-sm text-slate-400">مصوبه‌ای ثبت نشده است</div>
      )}
    </div>
  );
}

// ===== Tab 5: Attachments =====
function AttachmentsTab({ minutesId }: { minutesId: string }) {
  const [attachments, setAttachments] = useState<MinutesAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchAttachments = async () => {
    const { data } = await supabase.from('minutes_attachments').select('*').eq('minutes_id', minutesId).order('created_at', { ascending: false });
    setAttachments((data as MinutesAttachment[]) || []);
  };

  useEffect(() => {
    fetchAttachments();
  }, [minutesId]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setUploading(true);
    for (const file of Array.from(files)) {
      const ext = file.name.split('.').pop();
      const path = `${minutesId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error: upErr } = await supabase.storage.from('minutes-attachments').upload(path, file);
      if (upErr) { console.error(upErr); continue; }
      const { data: pub } = supabase.storage.from('minutes-attachments').getPublicUrl(path);
      const isImage = file.type.startsWith('image/');
      await supabase.from('minutes_attachments').insert({
        minutes_id: minutesId,
        file_url: pub.publicUrl,
        file_name: file.name,
        file_type: isImage ? 'image' : ext || 'file',
        file_size: file.size,
        mime_type: file.type,
      });
      await logMinutesEvent(minutesId, 'attachment_added', 'افزودن پیوست', file.name);
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    fetchAttachments();
  };

  const handleDelete = async (id: string, fileUrl: string) => {
    const path = fileUrl.split('/minutes-attachments/')[1];
    if (path) await supabase.storage.from('minutes-attachments').remove([path]);
    await supabase.from('minutes_attachments').delete().eq('id', id);
    fetchAttachments();
  };

  const formatSize = (bytes: number | null) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      <input ref={fileInputRef} type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt" className="hidden" onChange={handleUpload} />
      <div className="flex gap-2">
        <button onClick={() => fileInputRef.current?.click()} disabled={uploading} className="btn-primary text-xs">
          {uploading ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              در حال بارگذاری...
            </>
          ) : (
            <>
              <Upload className="w-3.5 h-3.5" />
              آپلود فایل یا تصویر
            </>
          )}
        </button>
      </div>

      {attachments.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {attachments.map((att) => (
            <div key={att.id} className="card p-3 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  {att.file_type === 'image' ? (
                    <img src={att.file_url} alt={att.file_name} className="w-10 h-10 rounded object-cover shrink-0" />
                  ) : (
                    <div className="w-10 h-10 rounded bg-slate-100 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5 text-slate-500" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-slate-800 truncate">{att.file_name}</p>
                    {att.file_size && <p className="text-[10px] text-slate-400">{formatSize(att.file_size)}</p>}
                  </div>
                </div>
                <button onClick={() => handleDelete(att.id, att.file_url)} className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded shrink-0">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <a href={att.file_url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline flex items-center gap-1">
                <Download className="w-3 h-3" />
                دانلود / مشاهده
              </a>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-sm text-slate-400">پیوستی برای این صورتجلسه ثبت نشده است</div>
      )}
    </div>
  );
}

// ===== Decision Form Modal =====
function DecisionFormModal({
  open,
  onClose,
  onSave,
  decision,
  agendaItems,
  profiles,
  orgUnits,
  nextNumber,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (d: Partial<Decision>) => void;
  decision: Decision | null;
  agendaItems: MeetingAgendaItem[];
  profiles: Profile[];
  orgUnits: OrgUnit[];
  nextNumber: string;
}) {
  const [number, setNumber] = useState(decision?.number || nextNumber);
  const [title, setTitle] = useState(decision?.title || '');
  const [content, setContent] = useState(decision?.content || '');
  const [agendaItemId, setAgendaItemId] = useState(decision?.agenda_item_id || '');
  const [ownerUnitId, setOwnerUnitId] = useState(decision?.owner_unit_id || '');
  const [ownerUserId, setOwnerUserId] = useState(decision?.owner_user_id || '');
  const [priority, setPriority] = useState<Priority>(decision?.priority || 'medium');
  const [deadline, setDeadline] = useState(decision?.deadline || '');
  const [showAgendaPicker, setShowAgendaPicker] = useState(false);

  const handleSubmit = () => {
    if (!title.trim() || !content.trim()) return;
    const ownerProfile = profiles.find((p) => p.user_id === ownerUserId);
    onSave({
      number,
      title,
      content,
      agenda_item_id: agendaItemId || null,
      owner_unit_id: ownerUnitId || null,
      owner_user_id: ownerUserId || null,
      owner_name: ownerProfile?.name || null,
      priority,
      deadline: deadline || null,
    });
  };

  const handleSelectAgenda = (item: MeetingAgendaItem) => {
    setAgendaItemId(item.id);
    setTitle(item.title);
    setShowAgendaPicker(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={decision ? 'ویرایش مصوبه' : 'ثبت مصوبه جدید'} size="lg">
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="label">شماره بند</label>
            <input className="input" value={number} onChange={(e) => setNumber(e.target.value)} />
          </div>
          <div>
            <label className="label">اولویت</label>
            <select className="input" value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
              {Object.entries(PRIORITY).map(([key, val]) => (
                <option key={key} value={key}>{val.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="label">عنوان مصوبه</label>
          <div className="relative">
            <input className="input pl-10" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان مختصر مصوبه" />
            <button
              type="button"
              onClick={() => setShowAgendaPicker(true)}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              title="انتخاب از دستور جلسه"
            >
              <ClipboardList className="w-4 h-4" />
            </button>
          </div>
          {agendaItemId && (
            <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
              مرتبط با دستور جلسه: {agendaItems.find((a) => a.id === agendaItemId)?.number}. {agendaItems.find((a) => a.id === agendaItemId)?.title}
            </p>
          )}
        </div>

        {/* Agenda picker popover */}
        {showAgendaPicker && (
          <div className="border border-slate-200 rounded-lg bg-slate-50 p-3 animate-fadeIn">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-slate-700">انتخاب از دستور جلسه</span>
              <button onClick={() => setShowAgendaPicker(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            {agendaItems.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">دستور جلسه‌ای ثبت نشده است</p>
            ) : (
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {agendaItems.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => handleSelectAgenda(a)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-right text-sm transition-all ${
                      agendaItemId === a.id ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xs font-bold shrink-0">{a.number}</span>
                    <span className="flex-1 truncate">{a.title}</span>
                    {a.presenter && <span className="text-xs opacity-60 shrink-0">{a.presenter}</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div>
          <label className="label">متن مصوبه</label>
          <textarea className="input" rows={5} value={content} onChange={(e) => setContent(e.target.value)} placeholder="متن مصوبه را وارد کنید" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="label">واحد اقدام‌کننده</label>
            <select className="input" value={ownerUnitId} onChange={(e) => setOwnerUnitId(e.target.value)}>
              <option value="">انتخاب واحد</option>
              {orgUnits.map((u) => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">شخص اقدام‌کننده</label>
            <select className="input" value={ownerUserId} onChange={(e) => setOwnerUserId(e.target.value)}>
              <option value="">انتخاب کاربر</option>
              {profiles.map((p) => (
                <option key={p.user_id} value={p.user_id}>{p.name} - {p.position}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="label">مهلت اجرا (تقویم شمسی)</label>
          <PersianDatePicker value={deadline} onChange={setDeadline} />
        </div>

        <div className="flex gap-3 justify-end pt-2">
          <button onClick={onClose} className="btn-secondary">انصراف</button>
          <button onClick={handleSubmit} className="btn-primary">
            <Save className="w-4 h-4" />
            {decision ? 'ثبت ویرایش' : 'ثبت مصوبه'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
