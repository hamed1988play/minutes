import { useState, useEffect, useCallback } from 'react';
import {
  Plus,
  RefreshCw,
  Search,
  Eye,
  Pencil,
  Trash2,
  Send,
  FileText,
  BarChart3,
  RotateCcw,
  Calendar,
  Users,
  CheckCircle,
  AlertCircle,
  Inbox,
  ClipboardList,
  CheckSquare,
  Share2,
  MessageSquare,
  GitBranch,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { logMinutesEvent } from '../lib/eventLogger';
import type { Minutes, MinutesStatus, Profile } from '../lib/types';
import { formatPersianDate } from '../lib/persianCalendar';
import { MinutesStatusBadge } from '../components/Badges';
import ConfirmDialog from '../components/ConfirmDialog';
import Modal from '../components/Modal';
import WorkflowModal from '../components/WorkflowModal';
import MeetingReportPage from '../pages/MeetingReportPage';

interface MinutesWithCounts extends Minutes {
  participant_count: number;
  decision_count: number;
  creator_name: string;
  secretary_name: string | null;
  chairperson_name: string | null;
  review_count: number;
  reviews: ReviewData[];
}

interface ReviewData {
  action: string;
  general_comment: string | null;
  decision_comments: Record<string, string> | null;
  reviewed_at: string | null;
  reviewer_id: string | null;
  reviewer_name?: string;
}

interface MinutesPageProps {
  onView: (id: string) => void;
  onEdit: (id: string) => void;
  onNew: () => void;
}

const STATUS_TABS: { key: MinutesStatus | 'all'; label: string }[] = [
  { key: 'all', label: 'همه' },
  { key: 'draft', label: 'پیش‌نویس' },
  { key: 'pending', label: 'در انتظار تأیید' },
  { key: 'approved', label: 'تأییدشده' },
  { key: 'rejected', label: 'ردشده' },
  { key: 'published', label: 'منتشرشده' },
];

export default function MinutesPage({ onView, onEdit, onNew }: MinutesPageProps) {
  const [minutes, setMinutes] = useState<MinutesWithCounts[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<MinutesStatus | 'all'>('all');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [reviewsModal, setReviewsModal] = useState<MinutesWithCounts | null>(null);
  const [workflowModal, setWorkflowModal] = useState<MinutesWithCounts | null>(null);
  const [reportModal, setReportModal] = useState<MinutesWithCounts | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchMinutes = useCallback(async () => {
    setLoading(true);
    const { data: mins } = await supabase
      .from('minutes')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (!mins) {
      setLoading(false);
      return;
    }

    const { data: participants } = await supabase
      .from('minutes_participants')
      .select('minutes_id');

    const { data: decisions } = await supabase
      .from('decisions')
      .select('minutes_id');

    const { data: profiles } = await supabase.from('profiles').select('user_id, name');

    const profileMap = new Map<string, string>();
    (profiles as Profile[] | null)?.forEach((p) => profileMap.set(p.user_id, p.name));

    const participantCounts = new Map<string, number>();
    (participants as { minutes_id: string }[] | null)?.forEach((p) => {
      participantCounts.set(p.minutes_id, (participantCounts.get(p.minutes_id) || 0) + 1);
    });

    const decisionCounts = new Map<string, number>();
    (decisions as { minutes_id: string }[] | null)?.forEach((d) => {
      decisionCounts.set(d.minutes_id, (decisionCounts.get(d.minutes_id) || 0) + 1);
    });

    const enriched: MinutesWithCounts[] = (mins as Minutes[]).map((m) => {
      const meta = (m as unknown as Record<string, unknown>).metadata as Record<string, unknown> | null;
      const rawReviews = (meta?.reviews as unknown[]) || [];
      const reviews: ReviewData[] = rawReviews.map((r) => {
        const rv = r as ReviewData;
        return {
          ...rv,
          reviewer_name: rv.reviewer_id ? profileMap.get(rv.reviewer_id) || 'نامشخص' : 'نامشخص',
        };
      });
      return {
        ...m,
        participant_count: participantCounts.get(m.id) || 0,
        decision_count: decisionCounts.get(m.id) || 0,
        creator_name: profileMap.get(m.created_by) || 'نامشخص',
        secretary_name: m.secretary_id ? profileMap.get(m.secretary_id) || null : null,
        chairperson_name: m.chairperson_id ? profileMap.get(m.chairperson_id) || null : null,
        review_count: reviews.length,
        reviews,
      };
    });

    setMinutes(enriched);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMinutes();
  }, [fetchMinutes]);

  const filtered = minutes.filter((m) => {
    if (statusFilter !== 'all' && m.status !== statusFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        m.title.toLowerCase().includes(q) ||
        m.creator_name.toLowerCase().includes(q) ||
        m.snapshot_representative?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleDelete = async () => {
    if (!deleteTarget) return;
    const { error } = await supabase
      .from('minutes')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', deleteTarget);
    if (error) {
      showToast('خطا در حذف صورتجلسه', 'error');
    } else {
      showToast('صورتجلسه با موفقیت حذف شد');
      fetchMinutes();
    }
  };

  const handleSendForApproval = async (id: string) => {
    const { error } = await supabase
      .from('minutes')
      .update({ status: 'pending' as MinutesStatus })
      .eq('id', id);
    if (error) {
      showToast('خطا در ارسال برای تأیید', 'error');
    } else {
      await logMinutesEvent(id, 'sent_for_approval', 'ارسال برای تأیید', 'صورتجلسه برای تأیید ارسال شد');
      showToast('صورتجلسه برای تأیید ارسال شد');
      fetchMinutes();
    }
  };

  const handleShare = async (id: string) => {
    const url = `${window.location.origin}/?minutes=${id}`;
    try {
      await navigator.clipboard.writeText(url);
      await logMinutesEvent(id, 'shared', 'اشتراک‌گذاری', 'لینک صورتجلسه کپی و به اشتراک گذاشته شد');
      showToast('لینک صورتجلسه کپی شد — می‌توانید برای دیگران ارسال کنید');
    } catch {
      showToast('امکان کپی لینک نبود', 'error');
    }
  };

  const formatDate = (dateStr: string) => formatPersianDate(dateStr);

  const canEdit = (m: MinutesWithCounts) => m.status === 'draft' || m.status === 'rejected';
  const canDelete = (m: MinutesWithCounts) => m.status === 'draft';
  const canSend = (m: MinutesWithCounts) => m.status === 'draft';
  const canResend = (m: MinutesWithCounts) => m.status === 'rejected';
  const canReport = (m: MinutesWithCounts) => m.status === 'published';

  return (
    <div className="space-y-4">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg animate-fadeIn ${
            toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
          } text-white text-sm font-medium`}
        >
          <div className="flex items-center gap-2">
            {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {toast.msg}
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-800">لیست صورتجلسات</h1>
          <p className="text-sm text-slate-500 mt-0.5">مدیریت و مشاهده همه صورتجلسات</p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchMinutes} className="btn-secondary">
            <RefreshCw className="w-4 h-4" />
            بروزرسانی
          </button>
          <button onClick={onNew} className="btn-primary">
            <Plus className="w-4 h-4" />
            صورتجلسه جدید
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو در عنوان، دبیر، شرکت‌کنندگان..."
              className="input pr-10"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as MinutesStatus | 'all')}
            className="input w-auto min-w-[140px]"
          >
            {STATUS_TABS.map((t) => (
              <option key={t.key} value={t.key}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        {/* Status tabs */}
        <div className="flex flex-wrap gap-2">
          {STATUS_TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setStatusFilter(tab.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                statusFilter === tab.key ? 'tab-active' : 'tab-inactive bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-6 h-6 text-slate-400 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 flex flex-col items-center text-center">
          <Inbox className="w-12 h-12 text-slate-300 mb-3" />
          <p className="text-sm text-slate-500">صورتجلسه‌ای یافت نشد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((m) => (
            <div
              key={m.id}
              className="card p-4 hover:shadow-md transition-shadow duration-200 animate-fadeIn flex flex-col"
            >
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex items-start gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                    <FileText className="w-4.5 h-4.5 text-slate-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-800 truncate">{m.title}</h3>
                    <div className="flex items-center gap-1 mt-1 text-xs text-slate-500">
                      <Calendar className="w-3.5 h-3.5" />
                      {formatDate(m.snapshot_date)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {m.review_count > 0 && (
                    <button
                      onClick={() => setReviewsModal(m)}
                      className="flex items-center gap-0.5 text-xs text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full hover:bg-amber-100 transition-colors cursor-pointer"
                      title={`${m.review_count} نظر — کلیک برای مشاهده`}
                    >
                      <MessageSquare className="w-3 h-3" />
                      {m.review_count}
                    </button>
                  )}
                  <button
                    onClick={() => setWorkflowModal(m)}
                    className="flex items-center gap-0.5 text-xs text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-full hover:bg-slate-200 transition-colors cursor-pointer"
                    title="گردش کار صورتجلسه"
                  >
                    <GitBranch className="w-3 h-3" />
                  </button>
                  <MinutesStatusBadge status={m.status} />
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-500 mb-3 flex-1">
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5" />
                  {m.participant_count} شرکت‌کننده
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" />
                  {m.decision_count} مصوبه
                </div>
                <div className="flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  دبیر: {m.creator_name}
                </div>
                {m.secretary_name && (
                  <div className="flex items-center gap-1.5 text-blue-600">
                    <ClipboardList className="w-3.5 h-3.5" />
                    دبیر جلسه: {m.secretary_name}
                  </div>
                )}
                {m.chairperson_name && (
                  <div className="flex items-center gap-1.5 text-green-600">
                    <CheckSquare className="w-3.5 h-3.5" />
                    رئیس جلسه: {m.chairperson_name}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => onView(m.id)}
                  className="btn-ghost text-xs"
                >
                  <Eye className="w-3.5 h-3.5" />
                  مشاهده
                </button>
                {canEdit(m) && (
                  <button
                    onClick={() => onEdit(m.id)}
                    className="btn-ghost text-xs"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    ویرایش
                  </button>
                )}
                {canSend(m) && (
                  <button
                    onClick={() => handleSendForApproval(m.id)}
                    className="btn-ghost text-xs text-blue-600 hover:bg-blue-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    ارسال برای تأیید
                  </button>
                )}
                {canResend(m) && (
                  <button
                    onClick={() => handleSendForApproval(m.id)}
                    className="btn-ghost text-xs text-blue-600 hover:bg-blue-50"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    ارسال مجدد
                  </button>
                )}
                {canReport(m) && (
                  <button
                    onClick={() => setReportModal(m)}
                    className="btn-ghost text-xs text-green-600 hover:bg-green-50"
                  >
                    <BarChart3 className="w-3.5 h-3.5" />
                    گزارش
                  </button>
                )}
                {(m.status === 'published' || m.status === 'approved') && (
                  <button
                    onClick={() => handleShare(m.id)}
                    className="btn-ghost text-xs text-purple-600 hover:bg-purple-50"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    ارسال به دیگران
                  </button>
                )}
                {canDelete(m) && (
                  <button
                    onClick={() => setDeleteTarget(m.id)}
                    className="btn-ghost text-xs text-red-600 hover:bg-red-50 mr-auto"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    حذف
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="حذف صورتجلسه"
        message="آیا از حذف این صورتجلسه اطمینان دارید؟ این عمل قابل بازگشت نیست."
        confirmText="حذف"
      />

      {/* Reviews modal */}
      {reviewsModal && (
        <ReviewsModal minutes={reviewsModal} onClose={() => setReviewsModal(null)} />
      )}

      {/* Workflow modal */}
      {workflowModal && (
        <WorkflowModal
          minutesId={workflowModal.id}
          minutesTitle={workflowModal.title}
          open={true}
          onClose={() => setWorkflowModal(null)}
        />
      )}

      {/* Report modal */}
      {reportModal && (
        <Modal open={true} onClose={() => setReportModal(null)} title={`گزارش اجمالی: ${reportModal.title}`} size="xl">
          <MeetingReportPage minutesId={reportModal.id} onClose={() => setReportModal(null)} />
        </Modal>
      )}
    </div>
  );
}

// ===== Reviews Modal =====
function ReviewsModal({ minutes, onClose }: { minutes: MinutesWithCounts; onClose: () => void }) {
  return (
    <Modal open={true} onClose={onClose} title={`نظرات صورتجلسه: ${minutes.title}`} size="lg">
      <div className="space-y-3">
        {minutes.reviews.length === 0 ? (
          <div className="flex flex-col items-center py-8 text-center">
            <MessageSquare className="w-10 h-10 text-slate-300 mb-2" />
            <p className="text-sm text-slate-500">نظری ثبت نشده است</p>
          </div>
        ) : (
          minutes.reviews.map((r, idx) => (
            <div key={idx} className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    r.action === 'approved' ? 'bg-green-100 text-green-700' :
                    r.action === 'rejected' ? 'bg-red-100 text-red-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {r.action === 'approved' ? 'تأیید شده' : r.action === 'rejected' ? 'رد شده' : 'در انتظار'}
                  </span>
                  <span className="text-xs text-slate-500">{r.reviewer_name || 'نامشخص'}</span>
                </div>
                <span className="text-xs text-slate-400">
                  {r.reviewed_at ? formatPersianDate(r.reviewed_at) : ''}
                </span>
              </div>

              {r.general_comment && (
                <div className="mb-2">
                  <p className="text-xs font-semibold text-slate-600 mb-1">نظر کلی:</p>
                  <p className="text-sm text-slate-700 bg-white rounded-lg p-2 border border-slate-200">{r.general_comment}</p>
                </div>
              )}

              {r.decision_comments && Object.keys(r.decision_comments).length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-600 mb-1">نظرات مصوبات:</p>
                  <div className="space-y-1.5">
                    {Object.entries(r.decision_comments).map(([decisionId, comment]) => (
                      <div key={decisionId} className="bg-white rounded-lg p-2 border border-slate-200">
                        <p className="text-xs text-slate-500 mb-0.5">مصوبه: {decisionId}</p>
                        <p className="text-sm text-slate-700">{comment}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </Modal>
  );
}
