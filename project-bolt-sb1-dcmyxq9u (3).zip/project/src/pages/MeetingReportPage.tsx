import { useState, useEffect } from 'react';
import {
  RefreshCw,
  Users,
  ClipboardList,
  CheckSquare,
  Calendar,
  Clock,
  MapPin,
  FileText,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  X,
  Printer,
  User,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPersianDate } from '../lib/persianCalendar';
import type { Minutes, MinutesParticipant, Decision, MeetingAgendaItem, Profile } from '../lib/types';
import { DecisionStatusBadge, PriorityBadge } from '../components/Badges';
import ProgressBar from '../components/ProgressBar';

interface MeetingReportPageProps {
  minutesId: string;
  onClose: () => void;
}

export default function MeetingReportPage({ minutesId, onClose }: MeetingReportPageProps) {
  const [minutes, setMinutes] = useState<Minutes | null>(null);
  const [participants, setParticipants] = useState<MinutesParticipant[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [agendaItems, setAgendaItems] = useState<MeetingAgendaItem[]>([]);
  const [profiles, setProfiles] = useState<Map<string, Profile>>(new Map());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!minutesId) return;
    setLoading(true);

    (async () => {
      const { data: min } = await supabase.from('minutes').select('*').eq('id', minutesId).maybeSingle();
      if (!min) { setLoading(false); return; }
      setMinutes(min as Minutes);

      const { data: parts } = await supabase.from('minutes_participants').select('*').eq('minutes_id', minutesId).order('created_at');
      setParticipants((parts as MinutesParticipant[]) || []);

      const { data: decs } = await supabase.from('decisions').select('*').eq('minutes_id', minutesId).order('number');
      setDecisions((decs as Decision[]) || []);

      const { data: profs } = await supabase.from('profiles').select('*');
      const pm = new Map<string, Profile>();
      (profs as Profile[] | null)?.forEach((p) => pm.set(p.user_id, p));
      setProfiles(pm);

      if ((min as Minutes).meeting_id) {
        const { data: agenda } = await supabase.from('meeting_agenda_items').select('*').eq('meeting_id', (min as Minutes).meeting_id).order('number');
        setAgendaItems((agenda as MeetingAgendaItem[]) || []);
      }

      setLoading(false);
    })();
  }, [minutesId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <RefreshCw className="w-6 h-6 text-slate-400 animate-spin" />
      </div>
    );
  }

  if (!minutes) {
    return (
      <div className="card p-12 text-center">
        <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-500">صورتجلسه یافت نشد</p>
        <button onClick={onClose} className="btn-secondary mt-4">بازگشت</button>
      </div>
    );
  }

  const secretaryName = minutes.secretary_id ? profiles.get(minutes.secretary_id)?.name || '-' : '-';
  const chairpersonName = minutes.chairperson_id ? profiles.get(minutes.chairperson_id)?.name || '-' : '-';

  const stats = {
    total: decisions.length,
    completed: decisions.filter((d) => d.status === 'completed').length,
    inProgress: decisions.filter((d) => d.status === 'in_progress').length,
    overdue: decisions.filter((d) => d.status === 'overdue' || (d.deadline && new Date(d.deadline) < new Date() && d.status !== 'completed')).length,
    avgProgress: decisions.length > 0 ? Math.round(decisions.reduce((sum, d) => sum + (d.progress || 0), 0) / decisions.length) : 0,
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Header - no-print for close button */}
      <div className="flex items-center justify-between gap-3 no-print">
        <div>
          <h1 className="text-xl font-bold text-slate-800">گزارش اجمالی جلسه</h1>
          <p className="text-sm text-slate-500 mt-0.5">{minutes.title}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={handlePrint} className="btn-secondary">
            <Printer className="w-4 h-4" />
            چاپ
          </button>
          <button onClick={onClose} className="btn-ghost">
            <X className="w-4 h-4" />
            بستن
          </button>
        </div>
      </div>

      {/* Meeting Info */}
      <div className="card p-5">
        <h2 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <FileText className="w-4 h-4 text-slate-500" />
          اطلاعات جلسه
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center gap-2 text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>تاریخ: {formatPersianDate(minutes.snapshot_date)}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-600">
            <Clock className="w-4 h-4 text-slate-400" />
            <span>ساعت: {minutes.snapshot_time || '-'}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-600">
            <MapPin className="w-4 h-4 text-slate-400" />
            <span>محل: {minutes.snapshot_location || '-'}</span>
          </div>
          <div className="flex items-center gap-2 text-blue-600">
            <User className="w-4 h-4" />
            <span>دبیر: {secretaryName}</span>
          </div>
          <div className="flex items-center gap-2 text-green-600">
            <User className="w-4 h-4" />
            <span>رئیس: {chairpersonName}</span>
          </div>
          {minutes.snapshot_representative && (
            <div className="flex items-center gap-2 text-slate-600">
              <Users className="w-4 h-4 text-slate-400" />
              <span>نماینده: {minutes.snapshot_representative}</span>
            </div>
          )}
        </div>
        {minutes.snapshot_notes && (
          <div className="mt-3 pt-3 border-t border-slate-100">
            <p className="text-xs text-slate-500">{minutes.snapshot_notes}</p>
          </div>
        )}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="card p-3 text-center">
          <CheckSquare className="w-5 h-5 text-slate-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-slate-800">{stats.total}</p>
          <p className="text-xs text-slate-500">کل مصوبات</p>
        </div>
        <div className="card p-3 text-center">
          <CheckCircle className="w-5 h-5 text-green-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
          <p className="text-xs text-slate-500">تکمیل‌شده</p>
        </div>
        <div className="card p-3 text-center">
          <TrendingUp className="w-5 h-5 text-blue-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-blue-600">{stats.inProgress}</p>
          <p className="text-xs text-slate-500">در حال انجام</p>
        </div>
        <div className="card p-3 text-center">
          <AlertTriangle className="w-5 h-5 text-red-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-red-600">{stats.overdue}</p>
          <p className="text-xs text-slate-500">معوق</p>
        </div>
        <div className="card p-3 text-center">
          <div className="w-5 h-5 mx-auto mb-1">
            <ProgressBar value={stats.avgProgress} size="sm" />
          </div>
          <p className="text-2xl font-bold text-slate-800 mt-1">{stats.avgProgress}%</p>
          <p className="text-xs text-slate-500">میانگین پیشرفت</p>
        </div>
      </div>

      {/* Participants */}
      <div className="card p-5">
        <h2 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <Users className="w-4 h-4 text-slate-500" />
          شرکت‌کنندگان ({participants.length} نفر)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {participants.map((p) => (
            <div key={p.id} className="flex items-center gap-2 bg-slate-50 rounded-lg p-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600 shrink-0">
                {p.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-slate-800 truncate">{p.name}</p>
                <p className="text-xs text-slate-500 truncate">
                  {p.is_external ? p.company || 'خارج سازمان' : p.position || '-'}
                </p>
              </div>
            </div>
          ))}
          {participants.length === 0 && (
            <p className="text-sm text-slate-400 col-span-full text-center py-4">شرکت‌کننده‌ای ثبت نشده است</p>
          )}
        </div>
      </div>

      {/* Agenda */}
      {agendaItems.length > 0 && (
        <div className="card p-5">
          <h2 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-slate-500" />
            دستور جلسه ({agendaItems.length} آیتم)
          </h2>
          <div className="space-y-2">
            {agendaItems.map((a) => (
              <div key={a.id} className="flex items-start gap-3 bg-slate-50 rounded-lg p-3">
                <span className="text-xs font-bold text-slate-400 bg-slate-200 px-2 py-1 rounded shrink-0">{a.number}</span>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">{a.title}</p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                    {a.presenter && <span>ارائه‌دهنده: {a.presenter}</span>}
                    {a.duration && <span>زمان: {a.duration}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Decisions */}
      <div className="card p-5">
        <h2 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <CheckSquare className="w-4 h-4 text-slate-500" />
          مصوبات و وضعیت اجرا ({decisions.length} مورد)
        </h2>
        {decisions.length > 0 ? (
          <div className="space-y-3">
            {decisions.map((d) => (
              <div key={d.id} className="border border-slate-200 rounded-lg p-3">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-start gap-2">
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded shrink-0">بند {d.number}</span>
                    <div>
                      <h4 className="text-sm font-semibold text-slate-800">{d.title}</h4>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">{d.content}</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <PriorityBadge priority={d.priority} />
                    <DecisionStatusBadge status={d.status} />
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2 text-xs text-slate-500">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    {d.owner_name || '-'}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    مهلت: {formatPersianDate(d.deadline)}
                  </div>
                  <div className="col-span-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs shrink-0">پیشرفت:</span>
                      <ProgressBar value={d.progress} size="sm" />
                      <span className="text-xs font-medium text-slate-600 shrink-0">{d.progress}%</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-400 text-center py-4">مصوبه‌ای ثبت نشده است</p>
        )}
      </div>
    </div>
  );
}
