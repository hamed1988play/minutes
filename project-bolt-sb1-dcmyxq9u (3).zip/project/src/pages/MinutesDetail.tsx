import { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  Users,
  ClipboardList,
  CheckSquare,
  Paperclip,
  Pencil,
  Send,
  CheckCircle,
  XCircle,
  Upload,
  FileText,
  AlertCircle,
  RotateCcw,
  Plus,
  Printer,
  CheckCircle as Check,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatPersianDate } from '../lib/persianCalendar';
import type {
  Minutes,
  MinutesParticipant,
  Decision,
  MeetingAgendaItem,
  AgendaResult,
  Profile,
} from '../lib/types';
import {
  MinutesStatusBadge,
  DecisionStatusBadge,
  PriorityBadge,
  InviteStatusBadge,
  AttendanceBadge,
  ResultTypeBadge,
} from '../components/Badges';
import SignatureView from '../components/SignatureView';

interface MinutesDetailProps {
  minutesId: string;
  onEdit: (id: string) => void;
  onBack: () => void;
}

type TabKey = 'info' | 'participants' | 'agenda' | 'decisions' | 'attachments';

const TABS: { key: TabKey; label: string; icon: typeof Calendar }[] = [
  { key: 'info', label: 'اطلاعات جلسه', icon: Calendar },
  { key: 'participants', label: 'شرکت‌کنندگان', icon: Users },
  { key: 'agenda', label: 'دستور جلسه', icon: ClipboardList },
  { key: 'decisions', label: 'مصوبات', icon: CheckSquare },
  { key: 'attachments', label: 'پیوست‌ها', icon: Paperclip },
];

export default function MinutesDetail({ minutesId, onEdit, onBack }: MinutesDetailProps) {
  const [activeTab, setActiveTab] = useState<TabKey>('info');
  const [loading, setLoading] = useState(true);
  const [minutes, setMinutes] = useState<Minutes | null>(null);
  const [participants, setParticipants] = useState<MinutesParticipant[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [agendaItems, setAgendaItems] = useState<MeetingAgendaItem[]>([]);
  const [agendaResults, setAgendaResults] = useState<AgendaResult[]>([]);
  const [creator, setCreator] = useState<Profile | null>(null);
  const [showSignature, setShowSignature] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchDetail = useCallback(async () => {
    setLoading(true);
    const { data: min } = await supabase.from('minutes').select('*').eq('id', minutesId).maybeSingle();
    if (!min) { setLoading(false); return; }
    setMinutes(min as Minutes);

    const { data: prof } = await supabase.from('profiles').select('*').eq('user_id', (min as Minutes).created_by).maybeSingle();
    setCreator(prof as Profile);

    const { data: parts } = await supabase.from('minutes_participants').select('*').eq('minutes_id', minutesId).order('created_at');
    setParticipants((parts as MinutesParticipant[]) || []);

    const { data: decs } = await supabase.from('decisions').select('*').eq('minutes_id', minutesId).order('number');
    setDecisions((decs as Decision[]) || []);

    const { data: meeting } = await supabase.from('meetings').select('*').eq('id', (min as Minutes).meeting_id).maybeSingle();
    if (meeting) {
      const { data: agenda } = await supabase.from('meeting_agenda_items').select('*').eq('meeting_id', (meeting as { id: string }).id).order('number');
      setAgendaItems((agenda as MeetingAgendaItem[]) || []);
    }

    const { data: results } = await supabase.from('agenda_results').select('*').eq('minutes_id', minutesId);
    setAgendaResults((results as AgendaResult[]) || []);

    setLoading(false);
  }, [minutesId]);

  useEffect(() => { fetchDetail(); }, [fetchDetail]);

  const handleApprove = async () => {
    await supabase.from('minutes').update({ status: 'approved', approved_by: minutes?.created_by, approved_at: new Date().toISOString() }).eq('id', minutesId);
    showToast('صورتجلسه تأیید شد');
    fetchDetail();
  };

  const handleReject = async () => {
    await supabase.from('minutes').update({ status: 'rejected' }).eq('id', minutesId);
    showToast('صورتجلسه رد شد');
    fetchDetail();
  };

  const handlePublish = async () => {
    await supabase.from('minutes').update({ status: 'published', published_at: new Date().toISOString() }).eq('id', minutesId);
    showToast('صورتجلسه منتشر شد');
    fetchDetail();
  };

  const handleSendForApproval = async () => {
    await supabase.from('minutes').update({ status: 'pending', updated_at: new Date().toISOString() }).eq('id', minutesId);
    showToast('صورتجلسه برای تأیید ارسال شد');
    fetchDetail();
  };

  const handleNewVersion = async () => {
    if (!minutes) return;
    const { data: newMin } = await supabase
      .from('minutes')
      .insert({
        meeting_id: minutes.meeting_id,
        snapshot_title: minutes.snapshot_title,
        snapshot_date: minutes.snapshot_date,
        snapshot_time: minutes.snapshot_time,
        snapshot_location: minutes.snapshot_location,
        snapshot_representative: minutes.snapshot_representative,
        snapshot_phone: minutes.snapshot_phone,
        snapshot_notes: minutes.snapshot_notes,
        snapshot_organizer_id: minutes.snapshot_organizer_id,
        title: minutes.title,
        status: 'draft',
        approval_type: minutes.approval_type,
        version: minutes.version + 1,
        previous_version_id: minutes.id,
        change_reason: 'اصلاح صورتجلسه',
        created_by: minutes.created_by,
      })
      .select('*')
      .single();
    if (newMin) {
      showToast('نسخه جدید ایجاد شد');
      onEdit((newMin as Minutes).id);
    }
  };

  const formatDate = (dateStr: string) => formatPersianDate(dateStr);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  if (!minutes) {
    return (
      <div className="card p-12 text-center">
        <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-500">صورتجلسه یافت نشد</p>
        <button onClick={onBack} className="btn-secondary mt-4">بازگشت</button>
      </div>
    );
  }

  const status = minutes.status;

  return (
    <div className="space-y-4">
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg bg-green-600 text-white text-sm font-medium animate-fadeIn">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4" />
            {toast}
          </div>
        </div>
      )}

      {/* Header */}
      <div className="card p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-800">{minutes.title}</h1>
              <div className="flex flex-wrap items-center gap-x-3 mt-1 text-xs text-slate-500">
                <MinutesStatusBadge status={status} />
                <span>نسخه: {minutes.version}</span>
                <span>تاریخ ثبت: {formatDate(minutes.created_at)}</span>
                <span>دبیر: {creator?.name || 'نامشخص'}</span>
              </div>
            </div>
          </div>
          <button onClick={onBack} className="btn-ghost text-xs">بازگشت</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="card p-1.5 flex gap-1 overflow-x-auto">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.key ? 'tab-active' : 'tab-inactive'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="card p-6">
        {activeTab === 'info' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl">
            <InfoField label="عنوان جلسه" value={minutes.snapshot_title} />
            <InfoField label="تاریخ جلسه" value={formatDate(minutes.snapshot_date)} />
            <InfoField label="ساعت جلسه" value={minutes.snapshot_time} />
            <InfoField label="محل برگزاری" value={minutes.snapshot_location} />
            <InfoField label="نماینده" value={minutes.snapshot_representative} />
            <InfoField label="شماره تماس" value={minutes.snapshot_phone} />
            <div className="md:col-span-2">
              <InfoField label="یادداشت‌ها" value={minutes.snapshot_notes} textarea />
            </div>
          </div>
        )}

        {activeTab === 'participants' && (
          <div className="space-y-4">
            {participants.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="text-right py-2 px-3 font-medium text-slate-600">نام</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">سمت</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">وضعیت دعوت</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">حضور</th>
                    </tr>
                  </thead>
                  <tbody>
                    {participants.map((p) => (
                      <tr key={p.id} className="border-b border-slate-100">
                        <td className="py-2.5 px-3 font-medium text-slate-800">{p.name}</td>
                        <td className="py-2.5 px-3 text-slate-600">{p.position}</td>
                        <td className="py-2.5 px-3"><InviteStatusBadge status={p.invite_status} /></td>
                        <td className="py-2.5 px-3"><AttendanceBadge status={p.attendance_status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-slate-400">شرکت‌کننده‌ای ثبت نشده است</div>
            )}
          </div>
        )}

        {activeTab === 'agenda' && (
          <div className="space-y-4">
            {agendaItems.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="text-right py-2 px-3 font-medium text-slate-600 w-12">#</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">عنوان</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">ارائه‌دهنده</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">زمان</th>
                      <th className="text-right py-2 px-3 font-medium text-slate-600">نتیجه</th>
                    </tr>
                  </thead>
                  <tbody>
                    {agendaItems.map((item) => {
                      const result = agendaResults.find((r) => r.agenda_item_id === item.id);
                      return (
                        <tr key={item.id} className="border-b border-slate-100">
                          <td className="py-2.5 px-3 text-slate-500">{item.number}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-800">{item.title}</td>
                          <td className="py-2.5 px-3 text-slate-600">{item.presenter}</td>
                          <td className="py-2.5 px-3 text-slate-600">{item.duration}</td>
                          <td className="py-2.5 px-3">
                            {result ? <ResultTypeBadge type={result.result_type} /> : <span className="text-xs text-slate-400">-</span>}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-slate-400">آیتم دستور جلسه‌ای ثبت نشده است</div>
            )}
          </div>
        )}

        {activeTab === 'decisions' && (
          <div className="space-y-3">
            {decisions.length > 0 ? (
              decisions.map((d) => (
                <div key={d.id} className="border border-slate-200 rounded-lg p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-start gap-2">
                      <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">بند {d.number}</span>
                      <h4 className="text-sm font-bold text-slate-800">{d.title}</h4>
                    </div>
                    <div className="flex gap-2">
                      <PriorityBadge priority={d.priority} />
                      <DecisionStatusBadge status={d.status} />
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{d.content}</p>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3 text-xs text-slate-500">
                    <span>مسئول: {d.owner_name}</span>
                    {d.deadline && <span>مهلت: {formatDate(d.deadline)}</span>}
                    <span>پیشرفت: {d.progress}%</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-sm text-slate-400">مصوبه‌ای ثبت نشده است</div>
            )}
          </div>
        )}

        {activeTab === 'attachments' && (
          <div className="text-center py-8 text-sm text-slate-400">پیوستی برای این صورتجلسه ثبت نشده است</div>
        )}
      </div>

      {/* Action buttons based on status */}
      <div className="card p-4 flex flex-wrap gap-2 justify-end">
        {status === 'draft' && (
          <>
            <button onClick={() => onEdit(minutesId)} className="btn-secondary">
              <Pencil className="w-4 h-4" />
              ویرایش
            </button>
            <button onClick={handleSendForApproval} className="btn-primary">
              <Send className="w-4 h-4" />
              ارسال برای تأیید
            </button>
          </>
        )}
        {status === 'pending' && (
          <>
            <button onClick={handleApprove} className="btn-success">
              <CheckCircle className="w-4 h-4" />
              تأیید
            </button>
            <button onClick={handleReject} className="btn-danger">
              <XCircle className="w-4 h-4" />
              رد
            </button>
          </>
        )}
        {status === 'approved' && (
          <button onClick={handlePublish} className="btn-primary">
            <Upload className="w-4 h-4" />
            انتشار
          </button>
        )}
        {status === 'rejected' && (
          <>
            <button onClick={() => onEdit(minutesId)} className="btn-secondary">
              <Pencil className="w-4 h-4" />
              ویرایش
            </button>
            <button onClick={handleSendForApproval} className="btn-primary">
              <RotateCcw className="w-4 h-4" />
              ارسال مجدد
            </button>
          </>
        )}
        {status === 'published' && (
          <>
            <button onClick={() => setShowSignature(true)} className="btn-primary">
              <Printer className="w-4 h-4" />
              دریافت جهت امضا
            </button>
            <button onClick={handleNewVersion} className="btn-secondary">
              <Plus className="w-4 h-4" />
              نسخه جدید
            </button>
          </>
        )}
      </div>

      {showSignature && (
        <SignatureView minutesId={minutesId} onClose={() => setShowSignature(false)} />
      )}
    </div>
  );
}

function InfoField({ label, value, textarea }: { label: string; value: string | null; textarea?: boolean }) {
  return (
    <div>
      <label className="label">{label}</label>
      {textarea ? (
        <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm text-slate-700 min-h-[60px]">{value || '-'}</div>
      ) : (
        <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm text-slate-700">{value || '-'}</div>
      )}
    </div>
  );
}
